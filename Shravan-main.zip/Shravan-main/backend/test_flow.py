"""End-to-end check of the demo story. Run: pytest -q  (or python test_flow.py)"""
import io

from fastapi.testclient import TestClient
from PIL import Image

from main import G, app

c = TestClient(app)


def jpeg():
    b = io.BytesIO()
    Image.new("RGB", (32, 32), "gray").save(b, "JPEG")
    return b.getvalue()


def test_demo_story():
    assert c.post("/admin/reset").status_code == 200
    user = c.post("/login/demo", json={"role": "USER"}).json()
    helper = c.post("/login/demo", json={"role": "HELPER"}).json()
    assert user["userId"] == "u_01" and helper["userId"] == "cg_01"

    a = c.get("/search", params={"q": "bus"}).json()[0]
    b = c.get("/search", params={"q": "metro"}).json()[0]
    body = {"from": {"lat": a["lat"], "lon": a["lon"]}, "to": {"lat": b["lat"], "lon": b["lon"]}, "userId": "u_01"}

    r = c.post("/route", json=body).json()
    base_types = {x["type"] for x in r["baseline"]["barriers"]}
    assert {"STEPS", "MISSING_KERB_RAMP"} <= base_types, "normal route must hit the seeded barriers"
    assert r["safe"]["barriers"] == [], "safe route must avoid known barriers"
    assert r["extraDistanceM"] >= 0 and r["safe"]["steps"][-1]["text"] == "You have arrived"

    req = c.post("/route-requests", json={"userId": "u_01", **{k: body[k] for k in ("from", "to")}}).json()
    assert [x["id"] for x in c.get("/route-requests", params={"open": True}).json()] == [req["id"]]

    # helper reports a broken footpath on a segment of the user's SAFE route
    mid = r["safe"]["polyline"][len(r["safe"]["polyline"]) // 2]
    nxt = r["safe"]["polyline"][len(r["safe"]["polyline"]) // 2 + 1]
    lat, lon = (mid[0] + nxt[0]) / 2, (mid[1] + nxt[1]) / 2
    resp = c.post("/reports", data={"lat": lat, "lon": lon, "status": "STEPS", "reporterId": "cg_01",
                                    "requestId": req["id"]}, files={"photo": ("p.jpg", jpeg(), "image/jpeg")})
    assert resp.status_code == 200, resp.text
    j = resp.json()
    assert j["verified"] and j["notifiedUsers"] == ["u_01"] and j["barrier"]["imageUrl"].startswith("/uploads/")

    n = c.get("/notifications", params={"userId": "u_01"}).json()
    assert n[0]["type"] == "ROUTE_ISSUE" and "steps" in n[0]["message"] and n[0]["reroute"]["newDistanceM"] > 0

    r2 = c.post("/route", json=body).json()
    assert r2["safe"]["polyline"] != r["safe"]["polyline"], "route must redraw around the new barrier"
    assert all(x["type"] != "STEPS" or x["id"] != j["barrier"]["id"] for x in r2["safe"]["barriers"])

    c.post(f"/route-requests/{req['id']}/complete", json={"helperId": "cg_01"})
    n = c.get("/notifications", params={"userId": "u_01"}).json()
    assert any(x["type"] == "ROUTE_CHECKED" and "1 issue found" in x["message"] for x in n)
    assert c.get("/route-requests", params={"open": True}).json() == []
    assert c.get(j["barrier"]["imageUrl"]).status_code == 200


def test_validation_and_clear():
    c.post("/admin/reset")
    assert c.post("/reports", data={"lat": 26.85, "lon": 75.80, "status": "NOPE", "reporterId": "cg_01"}).status_code == 400
    bad = c.post("/reports", data={"lat": 26.85}); assert bad.status_code == 400 and bad.json()["message"]
    far = c.post("/reports", data={"lat": 27.5, "lon": 76.5, "status": "STEPS", "reporterId": "cg_01"})
    assert far.status_code == 400 and "footpath" in far.json()["message"]
    seg = next(iter(G.segments))
    lat, lon = G.segment_midpoint(seg)
    c.post("/reports", data={"lat": lat, "lon": lon, "status": "BROKEN_SURFACE", "reporterId": "cg_01"})
    before = len(c.get("/barriers").json())
    c.post("/reports", data={"lat": lat, "lon": lon, "status": "CLEAR", "reporterId": "cg_01"})
    assert len(c.get("/barriers").json()) == before - 1


if __name__ == "__main__":
    test_demo_story(); test_validation_and_clear(); print("all good")
