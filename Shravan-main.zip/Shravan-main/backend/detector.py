"""Optional AI suggestion for a street photo.

Returns {"type": <one of the six classes or CLEAR>, "confidence": 0..1} or None.
Off by default. Set ANTHROPIC_API_KEY to turn on a zero-shot vision suggestion (UNTESTED here - no
network in the build sandbox). The helper always confirms or corrects the label, so a wrong or missing
suggestion never breaks the demo. Swap this function for a YOLO model later if you train one.
"""
import base64
import json
import os

import httpx

CLASSES = ["MISSING_KERB_RAMP", "STEPS", "BROKEN_SURFACE", "MISSING_FOOTPATH", "POLE_OBSTRUCTION",
           "PARKED_VEHICLE", "CLEAR"]


def suggest(image_bytes: bytes, content_type: str = "image/jpeg"):
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key or not image_bytes:
        return None
    prompt = ("You review street photos for wheelchair accessibility in India. Pick the single most "
              f"relevant label from {CLASSES}. Reply with JSON only: "
              '{"type": "<label>", "confidence": <0..1>}.')
    body = {
        "model": os.environ.get("DETECTOR_MODEL", "claude-sonnet-5-5"),
        "max_tokens": 100,
        "messages": [{"role": "user", "content": [
            {"type": "image", "source": {"type": "base64", "media_type": content_type,
                                         "data": base64.b64encode(image_bytes).decode()}},
            {"type": "text", "text": prompt}]}],
    }
    try:
        r = httpx.post("https://api.anthropic.com/v1/messages", json=body, timeout=20,
                       headers={"x-api-key": key, "anthropic-version": "2023-06-01"})
        text = r.json()["content"][0]["text"]
        out = json.loads(text[text.index("{"): text.rindex("}") + 1])
        if out.get("type") in CLASSES:
            return {"type": out["type"], "confidence": float(out.get("confidence", 0.5))}
    except Exception:
        return None
    return None
