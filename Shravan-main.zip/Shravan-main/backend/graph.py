"""Footpath graph + barrier-cost routing.

Default: a synthetic 7x7 footpath grid around DEMO_CENTER so everything runs offline.
Real data: run `python build_graph.py LAT LON 600` on a machine with internet (needs osmnx).
It writes graph.json, which this module loads automatically instead of the grid.
"""
import heapq
import json
import math
import os
import random

CENTER = tuple(float(x) for x in os.environ.get("DEMO_CENTER", "26.8505,75.8043").split(","))
GRAPH_FILE = os.path.join(os.path.dirname(__file__), "graph.json")

# Extra metres of "cost" added to an edge per barrier type (STEPS ~ blocked for a wheelchair).
BARRIER_PENALTY_M = {
    "STEPS": 2000, "TEMP_BLOCKED": 2000, "MISSING_FOOTPATH": 1500, "MISSING_KERB_RAMP": 800,
    "BROKEN_SURFACE": 150, "POLE_OBSTRUCTION": 120, "PARKED_VEHICLE": 100,
    "HEAVY_TRAFFIC": 80, "CROWDED": 40,
}


def haversine(a, b):
    r = 6371000.0
    p1, p2 = math.radians(a[0]), math.radians(b[0])
    dp, dl = p2 - p1, math.radians(b[1] - a[1])
    h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(h))


def bearing(a, b):
    p1, p2 = math.radians(a[0]), math.radians(b[0])
    dl = math.radians(b[1] - a[1])
    y = math.sin(dl) * math.cos(p2)
    x = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl)
    return (math.degrees(math.atan2(y, x)) + 360) % 360


def compass(deg):
    return ["north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"][int((deg + 22.5) // 45) % 8]


def seg_id(u, v):
    a, b = sorted((u, v))
    return f"s_{a}_{b}"


class Graph:
    def __init__(self, nodes, edges, places):
        self.nodes = nodes            # {id: (lat, lon)}
        self.places = places          # [{name, lat, lon}]
        self.adj = {n: [] for n in nodes}
        self.segments = {}            # segId -> (u, v, length)
        for u, v in edges:
            length = haversine(nodes[u], nodes[v])
            self.adj[u].append((v, length))
            self.adj[v].append((u, length))
            self.segments[seg_id(u, v)] = (u, v, length)

    # ---- geometry helpers -------------------------------------------------
    def nearest_node(self, lat, lon):
        return min(self.nodes, key=lambda n: haversine(self.nodes[n], (lat, lon)))

    def snap(self, lat, lon):
        """Nearest footpath segment to a point. Returns (segment_id, distance_m, (lat, lon) on segment)."""
        best = (None, 1e12, None)
        k = 111320.0
        cos = math.cos(math.radians(lat))
        for sid, (u, v, _) in self.segments.items():
            ax, ay = self.nodes[u][1] * k * cos, self.nodes[u][0] * k
            bx, by = self.nodes[v][1] * k * cos, self.nodes[v][0] * k
            px, py = lon * k * cos, lat * k
            dx, dy = bx - ax, by - ay
            t = 0 if dx == dy == 0 else max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)))
            qx, qy = ax + t * dx, ay + t * dy
            d = math.hypot(px - qx, py - qy)
            if d < best[1]:
                best = (sid, d, (qy / k, qx / (k * cos)))
        return best

    def segment_midpoint(self, sid):
        u, v, _ = self.segments[sid]
        return ((self.nodes[u][0] + self.nodes[v][0]) / 2, (self.nodes[u][1] + self.nodes[v][1]) / 2)

    # ---- routing ----------------------------------------------------------
    def shortest(self, src, dst, penalty=None):
        """Dijkstra. penalty: {segId: extra_metres}. Returns node path or None."""
        penalty = penalty or {}
        dist, prev, pq = {src: 0.0}, {}, [(0.0, src)]
        while pq:
            d, u = heapq.heappop(pq)
            if u == dst:
                break
            if d > dist.get(u, 1e18):
                continue
            for v, length in self.adj[u]:
                nd = d + length + penalty.get(seg_id(u, v), 0.0)
                if nd < dist.get(v, 1e18):
                    dist[v], prev[v] = nd, u
                    heapq.heappush(pq, (nd, v))
        if dst not in dist:
            return None
        path = [dst]
        while path[-1] != src:
            path.append(prev[path[-1]])
        return path[::-1]

    def path_segments(self, path):
        return [seg_id(path[i], path[i + 1]) for i in range(len(path) - 1)]

    def path_length(self, path):
        return sum(haversine(self.nodes[path[i]], self.nodes[path[i + 1]]) for i in range(len(path) - 1))

    def polyline(self, path):
        return [[round(self.nodes[n][0], 6), round(self.nodes[n][1], 6)] for n in path]

    def steps(self, path, barriers_by_seg):
        """Plain-language turn list. Merges consecutive segments heading the same way."""
        out, i = [], 0
        while i < len(path) - 1:
            head = compass(bearing(self.nodes[path[i]], self.nodes[path[i + 1]]))
            j, run = i, 0.0
            while j < len(path) - 1 and compass(bearing(self.nodes[path[j]], self.nodes[path[j + 1]])) == head:
                run += haversine(self.nodes[path[j]], self.nodes[path[j + 1]])
                j += 1
            warn = [b for s in self.path_segments(path[i:j + 1]) for b in barriers_by_seg.get(s, [])]
            text = f"Go {head} for {int(round(run, -1)) or int(run)} m"
            if warn:
                text += " - watch out: " + ", ".join(sorted({w['type'].replace('_', ' ').lower() for w in warn}))
            out.append({"text": text, "distanceM": int(run), "at": self.polyline([path[i]])[0]})
            i = j
        out.append({"text": "You have arrived", "distanceM": 0, "at": self.polyline([path[-1]])[0]})
        return out


def build_grid():
    rows = cols = 7
    step_lat, step_lon = 0.00075, 0.00085           # ~83 m x ~83 m blocks
    rnd = random.Random(7)                           # deterministic jitter -> no tied shortest paths
    nodes = {}
    for r in range(rows):
        for c in range(cols):
            nodes[f"n{r}{c}"] = (CENTER[0] + (r - 3) * step_lat + rnd.uniform(-0.00006, 0.00006),
                                 CENTER[1] + (c - 3) * step_lon + rnd.uniform(-0.00006, 0.00006))
    edges = []
    for r in range(rows):
        for c in range(cols):
            if c + 1 < cols:
                edges.append((f"n{r}{c}", f"n{r}{c+1}"))
            if r + 1 < rows:
                edges.append((f"n{r}{c}", f"n{r+1}{c}"))
    names = [("City Hospital", "n06"), ("Green Park Gate", "n60"), ("Metro Station", "n66"),
             ("Old Market", "n33"), ("Bus Stop 12", "n00"), ("Community Library", "n43"), ("Cafe Aroma", "n15")]
    places = [{"name": n, "lat": nodes[k][0], "lon": nodes[k][1]} for n, k in names]
    return Graph(nodes, edges, places)


def load_graph():
    if os.path.exists(GRAPH_FILE):
        d = json.load(open(GRAPH_FILE))
        nodes = {k: tuple(v) for k, v in d["nodes"].items()}
        return Graph(nodes, [tuple(e) for e in d["edges"]], d.get("places", []))
    return build_grid()
