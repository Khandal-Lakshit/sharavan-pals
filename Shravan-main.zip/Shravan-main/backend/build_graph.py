"""Download a real walkable footpath graph from OpenStreetMap and save it as graph.json.

Usage (needs internet + `pip install osmnx`):
    python build_graph.py 26.9124 75.7873 600        # lat lon radius_in_metres

Check the result by eye afterwards (open /barriers or the helper page): Indian footpath coverage in
OSM is patchy, so add/remove edges in graph.json by hand for the stretch you demo.
"""
import json
import sys

import osmnx as ox

lat, lon, dist = float(sys.argv[1]), float(sys.argv[2]), int(sys.argv[3]) if len(sys.argv) > 3 else 600
G = ox.graph_from_point((lat, lon), dist=dist, network_type="walk", simplify=False).to_undirected()
ids = {n: f"o{n}" for n in G.nodes}
nodes = {ids[n]: [d["y"], d["x"]] for n, d in G.nodes(data=True)}
edges = sorted({tuple(sorted((ids[u], ids[v]))) for u, v in G.edges() if u != v})
json.dump({"nodes": nodes, "edges": edges, "places": []}, open("graph.json", "w"))
print(f"saved graph.json: {len(nodes)} nodes, {len(edges)} edges")
