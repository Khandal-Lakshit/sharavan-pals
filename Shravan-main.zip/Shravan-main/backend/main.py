"""Raahi prototype backend (FastAPI, in-memory, no auth).

Run:  uvicorn main:app --host 0.0.0.0 --port 8000
Then expose it with:  ngrok http 8000   (put the https URL in the Android app's BASE_URL)
Helper web page (no install, any phone):  <base-url>/helper
Reset demo data any time:  POST /admin/reset
"""
import os
import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field

import detector
from graph import BARRIER_PENALTY_M, load_graph, seg_id

HERE = os.path.dirname(__file__)
UPLOADS = os.path.join(HERE, "uploads")
os.makedirs(UPLOADS, exist_ok=True)

STATUSES = ["CLEAR", "MISSING_KERB_RAMP", "STEPS", "BROKEN_SURFACE", "MISSING_FOOTPATH", "POLE_OBSTRUCTION",
            "PARKED_VEHICLE", "HEAVY_TRAFFIC", "TEMP_BLOCKED", "CROWDED"]
LABEL = {s: s.replace("_", " ").lower() for s in STATUSES}
TTL_HOURS = {"HEAVY_TRAFFIC": 2, "CROWDED": 2, "TEMP_BLOCKED": 6, "PARKED_VEHICLE": 6}   # others stay until re-verified
SNAP_MAX_M = 60.0
IST = timezone(timedelta(hours=5, minutes=30))

G = load_graph()
# Only verified helpers exist in the app: first drivers and NGO partners. The badge shows on every report they make.
USERS = {"u_01": {"userId": "u_01", "name": "Asha", "role": "USER", "badge": None},
         "cg_01": {"userId": "cg_01", "name": "Shravan", "role": "HELPER", "badge": "Verified driver"},
         "cg_02": {"userId": "cg_02", "name": "Meera", "role": "HELPER", "badge": "Verified NGO Helping Hand"}}

IMAGERY = {}                                            # segmentId -> age in days of the newest street photo (None = never photographed)
BARRIERS: dict = {}
NOTIFS: list = []
ACTIVE: dict = {}      # userId -> {"src","dst","segs":set,"length":float}
REQUESTS: dict = {}
REPORTS: dict = {}
SOS: list = []


def now():
    return datetime.now(timezone.utc)


def iso(dt):
    return dt.isoformat(timespec="seconds")


def new_id(prefix):
    return f"{prefix}_{uuid.uuid4().hex[:6]}"


def nearest_place(lat, lon):
    if not G.places:
        return "your route"
    return min(G.places, key=lambda p: (p["lat"] - lat) ** 2 + (p["lon"] - lon) ** 2)["name"]


def barrier_active(b):
    return b["active"] and (b["expiresAt"] is None or datetime.fromisoformat(b["expiresAt"]) > now())


def active_barriers():
    return [b for b in BARRIERS.values() if barrier_active(b)]


def penalty_map():
    pen = {}
    for b in active_barriers():
        w = 1.0 if b["verified"] else max(0.3, b["confidence"])
        pen[b["segmentId"]] = pen.get(b["segmentId"], 0.0) + BARRIER_PENALTY_M.get(b["type"], 0) * w
    return pen


def barriers_by_seg():
    out = {}
    for b in active_barriers():
        out.setdefault(b["segmentId"], []).append(b)
    return out


def add_barrier(lat, lon, type_, confidence, verified, reporter, image_url=None, note=None, report_id=None):
    sid, dist, snapped = G.snap(lat, lon)
    ttl = TTL_HOURS.get(type_)
    b = {"id": new_id("b"), "type": type_, "lat": round(snapped[0], 6), "lon": round(snapped[1], 6),
         "segmentId": sid, "confidence": confidence, "verified": verified, "reporterId": reporter,
         "reporterName": USERS.get(reporter, {}).get("name"), "reporterBadge": USERS.get(reporter, {}).get("badge"),
         "imageUrl": image_url, "note": note, "reportId": report_id, "createdAt": iso(now()),
         "expiresAt": iso(now() + timedelta(hours=ttl)) if ttl else None, "active": True,
         "snapDistanceM": round(dist, 1)}
    BARRIERS[b["id"]] = b
    return b


def seed():
    IMAGERY.clear()
    for i, sid_ in enumerate(sorted(G.segments)):              # demo spread: mostly fresh, some old, some never photographed
        IMAGERY[sid_] = (4, 12, 30, 75, None, 140, 9, 220, 45, None)[i % 10]
    BARRIERS.clear(); NOTIFS.clear(); ACTIVE.clear(); REQUESTS.clear(); REPORTS.clear(); SOS.clear()
    src, dst = G.nearest_node(*_place("Bus Stop 12")), G.nearest_node(*_place("Metro Station"))
    base = G.shortest(src, dst)
    segs = G.path_segments(base)
    pts = [G.segment_midpoint(s) for s in segs]
    if len(segs) >= 6:                                      # barriers that sit ON the normal route
        add_barrier(*pts[1], "STEPS", 0.86, True, "cg_01", note="Three steps at shop front")
        add_barrier(*pts[4], "MISSING_KERB_RAMP", 0.74, False, "ai")
    others = [s for s in G.segments if s not in segs]
    for i, t in ((3, "BROKEN_SURFACE"), (11, "POLE_OBSTRUCTION"), (19, "PARKED_VEHICLE")):
        if i < len(others):
            add_barrier(*G.segment_midpoint(others[i]), t, 0.7, t != "PARKED_VEHICLE", "cg_02" if i % 2 else "cg_01")


def _place(name):
    p = next((p for p in G.places if p["name"] == name), None) or G.places[0]
    return p["lat"], p["lon"]


def route_payload(path):
    bs = barriers_by_seg()
    segs = G.path_segments(path)
    on_route = [b for s in segs for b in bs.get(s, [])]
    length = G.path_length(path)
    return {"polyline": G.polyline(path), "distanceM": int(length), "durationMin": max(1, round(length / 60)),
            "barriers": on_route, "steps": G.steps(path, bs),
            "imagery": [{"segmentId": s, "ageDays": IMAGERY.get(s)} for s in segs]}


def compute_route(src, dst):
    base = G.shortest(src, dst)
    safe = G.shortest(src, dst, penalty_map())
    if not base or not safe:
        raise HTTPException(404, "No footpath route between those points")
    return base, safe


# ------------------------------------------------------------------ API
app = FastAPI(title="Raahi prototype")
@app.exception_handler(StarletteHTTPException)
async def http_error(request, exc):                      # the KMP client reads {"message": "..."} (ErrorResponse)
    return JSONResponse({"message": str(exc.detail), "detail": str(exc.detail)}, status_code=exc.status_code)


@app.exception_handler(RequestValidationError)
async def validation_error(request, exc):
    return JSONResponse({"message": "Invalid request", "detail": str(exc.errors())[:300]}, status_code=400)


app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
app.mount("/uploads", StaticFiles(directory=UPLOADS), name="uploads")
seed()


class Point(BaseModel):
    lat: float
    lon: float


class RouteIn(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    origin: Point = Field(alias="from")
    to: Point
    userId: Optional[str] = None


class RequestIn(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    userId: str
    origin: Point = Field(alias="from")
    to: Point
    title: Optional[str] = None


class CompleteIn(BaseModel):
    helperId: str


class LoginIn(BaseModel):
    role: str


class SosIn(BaseModel):
    userId: str
    lat: float
    lon: float


@app.get("/health")
def health():
    return {"ok": True, "segments": len(G.segments), "barriers": len(active_barriers())}


@app.post("/admin/reset")
def reset():
    seed()
    return {"ok": True}


@app.post("/login/demo")
def login(body: LoginIn):
    user = next((u for u in USERS.values() if u["role"] == body.role.upper()), None)
    if not user:
        raise HTTPException(400, "role must be USER or HELPER")
    return user


@app.get("/search")
def search(q: str = ""):
    q = q.strip().lower()
    return [p for p in G.places if q in p["name"].lower()]


@app.post("/route")
def route(body: RouteIn):
    src, dst = G.nearest_node(body.origin.lat, body.origin.lon), G.nearest_node(body.to.lat, body.to.lon)
    base, safe = compute_route(src, dst)
    if body.userId:
        ACTIVE[body.userId] = {"src": src, "dst": dst, "segs": set(G.path_segments(safe)),
                               "length": G.path_length(safe)}
    b, s = route_payload(base), route_payload(safe)
    return {"routeId": new_id("rt"), "baseline": b, "safe": s,
            "extraDistanceM": s["distanceM"] - b["distanceM"], "generatedAt": iso(now())}


@app.get("/barriers")
def barriers(minLat: float = -90, minLon: float = -180, maxLat: float = 90, maxLon: float = 180):
    return [b for b in active_barriers() if minLat <= b["lat"] <= maxLat and minLon <= b["lon"] <= maxLon]


@app.post("/route-requests")
def create_request(body: RequestIn):
    src, dst = G.nearest_node(body.origin.lat, body.origin.lon), G.nearest_node(body.to.lat, body.to.lon)
    _, safe = compute_route(src, dst)
    r = {"id": new_id("rq"), "userId": body.userId, "status": "OPEN", "title": body.title or "Please check my route",
         "polyline": G.polyline(safe), "createdAt": iso(now()), "completedAt": None, "reportIds": [],
         "userName": USERS.get(body.userId, {}).get("name", "User")}
    REQUESTS[r["id"]] = r
    return r


@app.get("/route-requests")
def list_requests(open: bool = False, userId: Optional[str] = None):
    out = [r for r in REQUESTS.values() if (not open or r["status"] == "OPEN") and (not userId or r["userId"] == userId)]
    return sorted(out, key=lambda r: r["createdAt"], reverse=True)


@app.post("/route-requests/{rid}/complete")
def complete_request(rid: str, body: CompleteIn):
    r = REQUESTS.get(rid)
    if not r:
        raise HTTPException(404, "Unknown request")
    r["status"], r["completedAt"] = "DONE", iso(now())
    n = len([x for x in r["reportIds"] if REPORTS[x]["status"] != "CLEAR"])
    NOTIFS.append({"id": new_id("n"), "userId": r["userId"], "type": "ROUTE_CHECKED", "segmentId": None,
                   "reportId": None, "createdAt": iso(now()), "read": False, "reroute": None,
                   "senderName": USERS.get(body.helperId, {}).get("name"),
                   "senderBadge": USERS.get(body.helperId, {}).get("badge"),
                   "placeLabel": f"Route: {r.get('title')}" if r.get("title") else None,
                   "message": f"Route checked at {datetime.now(IST).strftime('%I:%M %p')}, "
                              f"{n} issue{'s' if n != 1 else ''} found." if n else
                              f"Route checked at {datetime.now(IST).strftime('%I:%M %p')}, no issues found."})
    return r


@app.post("/reports")
async def create_report(lat: float = Form(...), lon: float = Form(...), status: str = Form(...),
                        reporterId: str = Form(...), heading: Optional[float] = Form(None),
                        note: Optional[str] = Form(None), requestId: Optional[str] = Form(None),
                        photo: Optional[UploadFile] = File(None)):
    status = status.upper()
    if status not in STATUSES:
        raise HTTPException(400, f"status must be one of {STATUSES}")
    image_url, ai = None, None
    if photo is not None:
        data = await photo.read()
        if data:
            fname = f"{uuid.uuid4().hex[:10]}.jpg"
            with open(os.path.join(UPLOADS, fname), "wb") as f:
                f.write(data)
            image_url = f"/uploads/{fname}"
            ai = detector.suggest(data, photo.content_type or "image/jpeg")
    sid, dist, snapped = G.snap(lat, lon)
    if dist > SNAP_MAX_M:
        raise HTTPException(400, f"Point is {int(dist)} m from the nearest footpath - move closer to the route")

    report_id = new_id("r")
    barrier, old_segs = None, {u: set(a["segs"]) for u, a in ACTIVE.items()}
    if status == "CLEAR":
        for b in active_barriers():
            if b["segmentId"] == sid:
                b["active"] = False
    else:
        for b in active_barriers():                       # replace any older report of the same type here
            if b["segmentId"] == sid and b["type"] == status:
                b["active"] = False
        barrier = add_barrier(lat, lon, status, 1.0, True, reporterId, image_url, note, report_id)
    IMAGERY[sid] = 0                                    # a helper just looked at this footpath
    REPORTS[report_id] = {"id": report_id, "status": status, "segmentId": sid}
    if requestId in REQUESTS:
        REQUESTS[requestId]["reportIds"].append(report_id)

    notified = _notify_affected(sid, status, report_id, snapped, old_segs, barrier) if status != "CLEAR" else []
    return {"reportId": report_id, "segmentId": sid, "snapDistanceM": round(dist, 1),
            "aiSuggestion": ai, "verified": True, "expiresAt": barrier["expiresAt"] if barrier else None,
            "barrier": barrier, "notifiedUsers": notified}


def _notify_affected(sid, status, report_id, snapped, old_segs, barrier=None):
    hit = []
    for uid, act in ACTIVE.items():
        if sid not in old_segs.get(uid, set()):
            continue
        _, new_safe = compute_route(act["src"], act["dst"])
        new_len = G.path_length(new_safe)
        extra = int(new_len - act["length"])
        act["segs"], act["length"] = set(G.path_segments(new_safe)), new_len
        NOTIFS.append({"id": new_id("n"), "userId": uid, "type": "ROUTE_ISSUE", "segmentId": sid,
                       "reportId": report_id, "createdAt": iso(now()), "read": False,
                       "message": f"{(barrier or {}).get('reporterName') or 'A helper'} reported {LABEL[status]} near "
                                  f"{nearest_place(*snapped)}. Your route is affected.",
                       "reroute": {"extraDistanceM": extra, "newDistanceM": int(new_len)},
                       "barrier": barrier, "senderName": (barrier or {}).get("reporterName"),
                       "senderBadge": (barrier or {}).get("reporterBadge"),
                       "placeLabel": f"Near {nearest_place(*snapped)}, on your route"})
        hit.append(uid)
    return hit


# ---- Explore and booking (prototype data) ----
VENUES = [
    {"id": "v1", "name": "Kesar Cafe", "category": "CAFE", "lat": 26.843776, "lon": 75.807971, "address": "Main road, near the market",
     "features": ["Step-free entrance", "Ramp", "Wide door", "Quiet corner"], "rating": 4.6,
     "note": "Staff are trained to help. Ask for the ground-floor table."},
    {"id": "v2", "name": "Sunrise Cafe", "category": "CAFE", "lat": 26.844534, "lon": 75.809412, "address": "Opposite the metro station",
     "features": ["Step-free entrance", "Accessible toilet", "Braille menu", "Sign-language friendly"], "rating": 4.4,
     "note": "Braille and picture menus at the counter."},
    {"id": "v3", "name": "Shanti Park", "category": "PARK", "lat": 26.841577, "lon": 75.808294, "address": "South of the market",
     "features": ["Flat paved paths", "Benches every 50 m", "Accessible toilet", "Shaded"], "rating": 4.5,
     "note": "Flat loop of about 600 m with places to rest."},
    {"id": "v4", "name": "Community Library", "category": "LIBRARY", "lat": 26.844994, "lon": 75.807024, "address": "Next to the city hospital",
     "features": ["Lift", "Ramp", "Large-print books", "Quiet reading room"], "rating": 4.3,
     "note": "Lift to every floor. Audio books at the desk."},
]
ALL_TOPICS = ["Entrance and ramp", "Washroom", "Safety", "Hospitality"]
_VER = {"v1": {"videoTopics": ALL_TOPICS, "qaDone": 12, "qaTotal": 12},
        "v2": {"videoTopics": ALL_TOPICS, "qaDone": 12, "qaTotal": 12},
        "v3": {"videoTopics": ["Entrance and ramp"], "qaDone": 5, "qaTotal": 12}}
_REV = {
    "v1": [{"id": "rv1", "author": "Anil K.", "need": "Wheelchair user", "rating": 5, "whenLabel": "2 weeks ago",
            "text": "Staff moved a chair without being asked. The washroom door is wide enough for my chair."}],
    "v2": [{"id": "rv4", "author": "Priya M.", "need": "Blind or low vision", "rating": 5, "whenLabel": "3 weeks ago",
            "text": "Braille menu at the counter, and the owner walked me to my table."}],
}
for _v in VENUES:
    _v["verification"] = _VER.get(_v["id"], {"videoTopics": [], "qaDone": 0, "qaTotal": 12})
    _v["reviews"] = _REV.get(_v["id"], [])


class ReviewIn(BaseModel):
    userId: str
    author: str
    need: str = ""
    rating: int = 5
    text: str


BOOKINGS: list = []
_BOOK_HELPERS = ["cg_01", "cg_02"]


class BookingIn(BaseModel):
    userId: str
    kind: str = "TRAVEL"
    destination: str = ""
    slot: str
    note: str = ""
    minutes: int = 60


HELP_PRICE_PER_HOUR = 199  # rupees; the Helping Hand keeps 149 of it


@app.get("/venues")
def venues():
    return VENUES


@app.post("/venues/{venue_id}/reviews")
def add_review(venue_id: str, body: ReviewIn):
    venue = next((v for v in VENUES if v["id"] == venue_id), None)
    if venue is None:
        raise HTTPException(404, "Unknown place")
    review = {"id": f"rv_{len(venue['reviews']) + 1}_{venue_id}", "author": body.author, "need": body.need,
              "rating": max(1, min(5, body.rating)), "text": body.text.strip(), "whenLabel": "Just now"}
    venue["reviews"].insert(0, review)
    return review


@app.post("/bookings")
def create_booking(body: BookingIn):
    h = USERS[_BOOK_HELPERS[len(BOOKINGS) % len(_BOOK_HELPERS)]]
    b = {"id": new_id("bk"), "userId": body.userId, "helperName": h["name"], "helperBadge": h["badge"],
         "kind": body.kind, "destination": body.destination, "slot": body.slot, "note": body.note,
         "status": "CONFIRMED", "minutes": max(30, body.minutes),
         "price": -(-HELP_PRICE_PER_HOUR * max(30, body.minutes) // 60)}
    BOOKINGS.insert(0, b)
    return b


@app.get("/bookings")
def list_bookings(userId: str):
    return [b for b in BOOKINGS if b["userId"] == userId]


@app.post("/bookings/{bid}/cancel")
def cancel_booking(bid: str):
    for b in BOOKINGS:
        if b["id"] == bid:
            b["status"] = "CANCELLED"
            return b
    raise HTTPException(404, "Unknown booking")


@app.get("/notifications")
def notifications(userId: str):
    return sorted([n for n in NOTIFS if n["userId"] == userId], key=lambda n: n["createdAt"], reverse=True)


@app.post("/notifications/{nid}/read")
def mark_read(nid: str):
    for n in NOTIFS:
        if n["id"] == nid:
            n["read"] = True
    return {"ok": True}


@app.post("/sos")
def sos(body: SosIn):                                    # thin: stored only; real delivery is "planned"
    SOS.append({"id": new_id("sos"), "at": iso(now()), **body.model_dump()})
    return {"ok": True, "note": "Prototype only - nothing was sent to a real contact"}


@app.get("/helper")
def helper_page():
    return FileResponse(os.path.join(HERE, "helper.html"))
