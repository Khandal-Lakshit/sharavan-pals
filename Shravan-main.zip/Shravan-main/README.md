# Shravan (code name Raahi) - Android Studio project in the Koshpal KMP + MFR layout

Two logins in one app: **User** (barrier-free route, places around you, Helping Hand booking, alerts, "ask a Helping Hand to check") and **Helping Hand** (the verified helper: open requests, photo + status report, "mark route checked").
Open this folder in Android Studio. Modules: `:app` (Android UI), `:shared` (KMP: domain, data, FluxDecks, Coordinators, ViewModels).

## What is copied from Koshpal, unchanged except the package name (koshpal -> raahi)
`Events`, `StateReflector`, `CallError`, `NetworkError`, `Result`, `Logger` (expect), `safeCall`, `responseToResult`, `HttpClientFactory`,
`BaseUrl`, `constructUrl`, `ErrorResponse`, `ObserveAsEvents`, `NetworkError.toString(context)` + its strings.
Same app wiring: `RaahiApp` sets `BaseUrl.value = BuildConfig.BASE_URL`, plants Timber, `startKoin { androidContext; androidLogger; modules(sharedModule, appModule) }`.

## Run
1. Backend (Mac):
```
cd backend && python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt pytest pillow
python test_flow.py          # prints: all good
uvicorn main:app --host 0.0.0.0 --port 8000
```
2. Emulator: nothing to set, `BASE_URL` defaults to `http://10.0.2.2:8000/` (your Mac).
3. Real phone: `ngrok http 8000`, then add this line to `local.properties` (it is git-ignored) and run again:
```
raahi.baseUrl=https://your-name.ngrok-free.app/
```
(`BASE_URL` is a `buildConfigField` in `app/build.gradle.kts`, like Koshpal. An ngrok free static domain avoids editing it every time.)
Helper without the app: `<url>/helper`. Reset demo data: `curl -X POST <url>/admin/reset`.

## Alert card (user)
An alert is a full card, not one line: a caption ("WARNING ON YOUR ROUTE" or "ROUTE CHECKED"), the barrier type as the title (for example "Steps"), the helper's photo and note, where it is ("On your route: Bus stop, Jawahar Circle to Metro station"), who sent it (avatar, name, "Verified driver" or "Verified NGO helper"), what it did ("Your route was updated, N m longer") and a "Show on map" button that opens Home with that barrier selected. Data: `AlertDto` carries `barrier`, `senderName`, `senderBadge`, `placeLabel` (backend `/notifications` sends them too). UI: `user/AlertCard.kt` and `AlertCardView` in `UserHomeView.swift`.

## Explore (round one, dummy data)
The Explore tab (compass icon) lists cafes, parks and a library near the user, nearest first, with access features (step-free entrance, ramp, Braille or picture menu, quiet, tactile paving, lift...) and a chip filter. "Route" switches to Home and plans the real road route from "Your location" (a fixed demo point near the bus stop, `DemoArea.USER_POINT`; round two uses the GPS fix) to that place, using the same OpenStreetMap routing and barrier avoidance as above. Data: `FakeWorld.venues`; backend `/venues` mirrors it.

## Cafe reviews and the Shravan Verified badge (round one, dummy data)
Every place card in Explore now has a **Reviews** button next to Route. It opens a bottom sheet with reviews written by other disabled visitors about how they were treated (name, access need, stars, text, when), the average that feeds the card's rating, and **Write a review** (stars, "About you" chips, text; the demo keeps it in memory and shows the toast "Thanks. Your review is posted."). A cafe that has shared a video on each of **Entrance and ramp, Washroom, Safety and Hospitality** and finished the 12 question access Q&A (`Verification.isVerified`) shows the **Shravan Verified** badge on its card and a checklist in the sheet; a cafe that has only some of them shows "Not verified yet" and which videos are missing (Green Leaf Cafe in the demo). The cafe side upload (video and Q&A form) is not built yet; the data model is `Verification`, `VenueReview` in `Explore.kt`. Data: `FakeWorld.venues`; backend `/venues` carries `verification` and `reviews`, and `POST /venues/{id}/reviews` adds one.

## Helping Hand booking (round one, dummy data)
A separate feature with its own tab (two-people icon). A Helping Hand is a verified person (driver or NGO partner) who helps with something, so it is not tied to any place. The form asks what help is needed (travel with me, shopping and errands, hospital or office visit, reading and forms), an optional destination, when they should meet you (in 30 minutes, in 1 hour, today 6 PM, tomorrow 10 AM) and an optional note. Confirming assigns a helper in turn and shows the toast "Booked. <name> will meet you in 30 minutes." While a booking is confirmed it floats as a card above the bottom bar on every tab (`BookingBanner`; every screen leaves room for it through `LocalBannerSpace` on Android and a bottom `safeAreaInset` on iOS). Tapping the card opens a bottom sheet with helper, badge, what, when, where, note and "Cancel booking"; the Helping Hand tab shows the same details instead of the form. Data: `FakeWorld.bookings`; backend `/bookings` mirrors it. **Price and description:** a Helping Hand costs **₹199 an hour**, minimum 30 minutes (`HELP_PRICE_PER_HOUR`); the Helping Hand keeps ₹149 of it (`HELP_HELPER_SHARE`). The form opens with a live price card that follows the chosen duration, shows a "What you get" description for the chosen kind of help (`HelpKind.detail`), asks separately when they should arrive and how long they should stay (30 minutes, 1 hour, 1.5 hours, 2 hours or 3 hours, `BOOKING_MINUTES`; each chip shows its price, worked out from ₹199 an hour and rounded up, so 30 minutes is ₹100), lists "Good to know" terms (`BOOKING_TERMS`: billed per hour, pay by UPI or cash at the end, free cancel until the helper sets off, ID checked) and the button reads "Book for ₹398" for 2 hours. The booking card, sheet and toast show how long and the price. Nothing is charged in the demo. `BookingDto` carries `hours` and `price`; the backend prices the booking at ₹199 an hour pro rata. The Helping Hand side does not receive bookings yet.

## Splash
`SplashScreen.kt` (Android) and `SplashView.swift` (iOS): on the iMessage-green launch colour a white circle pops in and inside it the four fingers of the Helping Hand logo rise one after the other, the thumb swings in, the location pin drops into the palm, the hand waves once, then "Shravan" and the tagline "Together with you." fade up in white. The logo is drawn as six separate transparent pieces (`drawable-nodpi/splash_f0..f3`, `splash_thumb`, `splash_pin`; `SplashF0..F3`, `SplashThumb`, `SplashPin` image sets), so nothing is cut from an image. Tap skips it; it is near-static when animations or Reduce Motion are off. Android 12+ shows the system splash first (`themes.xml`, same green and logo), iOS uses the `LaunchGreen` launch colour (#34C759), so the hand-over is seamless. To change the name or tagline edit `APP_NAME` and `APP_TAGLINE` (Android) and `appName` and `appTagline` (iOS).

## App icon
Source logo: `branding/raahi-logo.png` (the Helping Hand mark: four tonal fingers, a thumb and a location pin in the palm; lockups and the white and transparent marks are in `branding/shravan/`). Android: adaptive icon (iMessage green `#34C759` background + `drawable-nodpi/ic_launcher_foreground.png`, a white circle with the hand logo in the middle, kept inside the safe zone so round and squircle masks do not clip it). iOS: `Assets.xcassets/AppIcon.appiconset/AppIcon.png` (1024 px, no transparency, iOS rounds the corners).

## Layout
```
shared/src/commonMain/kotlin/com/app/raahi/
  app/{Events, StateReflector}.kt   app/{data/{mapper,repository}, di/SharedModule.kt, domain/{coordinator,model,repository,usecase}, fluxdeck, viewmodels}
  core/{data/networking, data/remote/{dto,source}, domain/util}
shared/src/androidMain|iosMain      Logger actuals, iosMain/.../IosModule.kt (Darwin engine)
app/src/main/java/com/app/raahi/
  RaahiApp.kt  MainActivity.kt  ui/theme/{Color,Type,Theme}.kt
  app/di/AppModule.kt   core/presentation/util/{ObserveAsEvents,NetworkErrorToString}.kt
  app/presentation/{navigation (Screen, AppNavHost, authGraph, userMainGraph, helperMainGraph), onboarding, user, helper, planned, globalcomponents}
```
Screens follow the Koshpal shape: `Screen(modifier, viewModel, onToX)`, events through `ObserveAsEvents` + Toast, ViewModels from `koinViewModel()`.
Call path: UI -> ViewModel -> Coordinator -> UseCase -> Repo -> DataSource. Reactive path: Repo Flow -> FluxDeck -> Formula -> ViewModel -> UI.

## Demo (about 90 s, screen-record)
User = Asha, Helper = Shravan (verified driver). Two devices, or one device logging out and in.
1. User opens **Home**: map of reported barriers, round pins with the reporter's initial, filter chips (All / Steps & ramps / Path & surface / Obstacles). Tap a pin: card with type, verified tick, "Reported by Meera · Verified NGO helper".
2. Route search is on Home too: From and To are pre-filled (Bus stop to Metro station). Find barrier-free route. The search card shrinks to "From / To" with an edit icon, dashed = normal route with 2 barriers, solid = barrier-free, and the bottom card shows the comparison.
3. Helper phone (Shravan, "Verified driver"): pick Steps, take a photo, submit.
4. User: alert within ~4 s, "Route updated" banner, the line redraws longer. The new pin is also on Home.
5. Finish on "Coming next" (SOS, handling card, places, voice, booking, ride-app partners): designed, not built.

## Who can report
Only verified helpers. First helpers are drivers and NGO partners; the badge ("Verified driver", "Verified NGO helper") shows on every pin, card and row. Prototype helpers are unpaid. Helpers are seeded (Shravan, Meera, Imran); there is no sign-up or verification flow yet.

## Status - read this
- Backend: tested (`test_flow.py`).
- Kotlin: **never compiled** (my sandbox cannot reach Maven). Packages and imports are checked by script only. Expect some errors on first build; paste them back.
- Gradle: versions come from your Koshpal build outputs (AGP 9.4.1, Kotlin 2.4.10, Koin 4.2.2, Ktor 3.6.0, Compose BOM 2026.09.00, Navigation 2.10.2, Coil 3.6.3).
  I could not see your root files. The Gradle wrapper version (9.4.1) and `shared/build.gradle.kts` (uses `com.android.kotlin.multiplatform.library`) are my best guess.
  If sync complains, copy your Koshpal `gradle/wrapper/gradle-wrapper.properties`, `gradle/libs.versions.toml`, `settings.gradle.kts` and `shared/build.gradle.kts` over mine (keep `rootProject.name` and the shared namespace).
- iOS: SwiftUI app and bridges are in `iosApp/` (see the iOS section). Also never compiled.
- Photo AI suggestion (`ANTHROPIC_API_KEY`) is off by default and untested. Map is a synthetic grid until you run `build_graph.py` (untested).


## Backend address
Not set in the app UI. It is `BuildConfig.BASE_URL`, read from `local.properties`:

    raahi.baseUrl=http://10.0.2.2:8000/      # Android emulator -> your Mac (default)
    raahi.baseUrl=https://xxxx.ngrok-free.app/   # real phone

If the server is down the app says "Can't reach the Raahi server at <url>", not "no internet".

## UI
Poppins for titles (parent), Inter for body text (child), set in `ui/theme/Type.kt` (Android) and `FontExtensions.swift` (`.poppins`, `.inter`). Bottom navigation is a floating pill in deep green (white icons, white active circle with a green icon) on both platforms. All buttons are fully round (pill). The role screen ("Who is using Shravan?") has a deep-green hero with pin previews and two role cards with a round arrow button; the helper screen uses a 2-column grid of barrier tiles, request cards with avatars, and a floating identity card ("Verified driver · Shravan").

Theme: iOS Messages green on white. One palette in `ui/theme/Color.kt` (Android) and `RaahiTheme` in `ColorExtensions.swift` (iOS). Bright green = big fills and icons; deep green = small text. Corners come from the theme `shapes` scale (buttons are `CircleShape`, 24 cards, 28 floating panels). Status bar icons: every screen has a light background, so they are dark; dark mode flips them (`SetStatusBarDarkIcons`). White text on the bright green is about 2.2:1 contrast; for stricter accessibility change `MessageGreen` to `GreenDeep` in `Theme.kt` (and `primary` in `ColorExtensions.swift`). Cards are plain: white (iOS `secondarySystemGroupedBackground`), 0.5 dp separator border, no shadow or elevation. Every screen background is iOS `systemGroupedBackground` (F2F2F7, black in dark mode); see `GroupedBackground` / `hairlineBorder()` on Android and `RaahiTheme.grouped` / `flatSurface` on iOS. Messages use the system Toast. On iOS the native equivalent will be a system alert.

## Status
Kotlin is NOT compiled yet (build hosts were unreachable where this was written). Paste the first compile errors and they get fixed.

### Helper alert

When the user taps "Ask a helper to check this route", the helper gets an alert card on their home screen: "Asha needs help. Please check this route: Bus stop, Jawahar Circle to Metro station · Jaipur", with Check route (opens that route on the map) and Later. After the helper reports, the user gets the reroute alert as before. In the prototype both roles share one in-memory FakeWorld, so log out and sign in as the helper to see it; helpers polling every 4 s will see it live. Round two filters by distance to the route on the backend. Home also shows the city ("📍 Jaipur"); this comes from `DemoArea` in `Route.kt`, round one only.

### Helper location

"Use my GPS" reads the device fix, drops the green marker, flies the map there and swaps the button for a "Location set" row with a Change button (tap the map to set it by hand instead). An Android emulator reports Mountain View (37.422, -122.084) unless you change it: Extended controls > Location, then set 26.842, 75.805 to stay in the demo area. In the iOS simulator use Features > Location > Custom Location.

## Route confidence (from the SC-02 brief)

Every route shows a confidence score from the age and coverage of the street photos behind it, and how many segments have no recent imagery. Each segment scores 1.0 for a photo from today, falling in a straight line to 0 at 180 days, and 0 when it has no photo; the route score is the average (High 75+, Medium 50-74, Low below 50). A segment with no photo, or one older than 90 days, counts as "no recent imagery". Logic: `RouteImagery.from()` in `domain/model/Route.kt`. Shown on the route panel as "NN% sure" inside each route card and in the "How sure are we?" card (`ConfidenceCard`). Round one uses hard-coded photo ages in `FakeWorld`; the backend already returns `imagery` per route (`IMAGERY` in `backend/main.py`, reset to 0 days when a helper reports on that footpath). The photo ages are cycled from fixed patterns, so the barrier-free route usually scores about 80% and the normal route about 55%.

## Testing both roles (round one)
With `USE_FAKE_DATA = true` the demo data lives inside each app process, so a phone and an emulator do NOT see each other's reports and alerts. To see the helper's report reach the user, run both roles in the same app instance: sign in as User, plan a route and tap "Ask a helper to check", log out, sign in as Helper, submit, log out and sign in as User again. For two real devices set `USE_FAKE_DATA = false` and run the backend (see Run), but note the backend still uses its own demo street graph, not the OpenStreetMap routing above.

## Routing in the prototype (round one)
Routes are not hard-coded. For whichever From and To the user picks (four places in Jaipur: bus stop, metro station, city hospital, market square), `core/data/fake/OsrmClient.kt` asks the public OpenStreetMap (OSRM) routing server for the real road geometry, so it needs internet. `RoutePlanner.kt` then makes the barrier-free route: it takes OSRM's alternatives, and if every one still touches a barrier (closer than 25 m) it forces a waypoint 150, 250 and 350 m to either side of the barrier and keeps the shortest clear route. Distances and minutes are computed from the geometry (70 m/min). The map draws a green "A" at the start and a dark "B" at the end.

What is still demo data: the barriers, the helpers and the photo ages. Seeded barriers sit on real roads; if a chosen route meets none, `FakeWorld.ensureBarrierOn` invents one part-way along it so there is always something to route around. A helper's report is placed on the barrier-free route the user was last shown, so the next route really goes round it (the reroute banner then says "New route shown"). If the phone has no internet, the Bus stop to Metro walk falls back to a saved copy of its routes; any other pair shows "Can't reach the routing service". Round two replaces `OsrmClient` and `RoutePlanner` with the FastAPI backend (Dijkstra with a penalty per barrier type).

## Demo data (round one)
`USE_FAKE_DATA = true` in `shared/.../app/di/SharedModule.kt`. The three Fake data sources share one in-memory `FakeWorld`, so a helper report really creates the user's alert and new route. Everything is hard-coded and labelled as demo data. Set it to `false` to use the FastAPI backend (`backend/`), which is ready but not connected.

## iOS (SwiftUI, Liquid Glass)
Open `iosApp/iosApp.xcodeproj` in Xcode 26 (iOS 26.5 target, same as Koshpal). The build phase runs `./gradlew :shared:embedAndSignAppleFrameworkForXcode`, the framework is `SharedCore`, and the app calls `AppModuleKt.doInitKoin()` like Koshpal.

- Bridges: `AuthViewModelBridge`, `RouteViewModelBridge`, `HelperViewModelBridge` wrap the shared ViewModels. They use `FlowWatcherKt.watch(flow:)` (iosMain `FlowWatcher.kt`) instead of SKIE's `for await`, so no extra Gradle plugin is needed. If Koshpal already uses SKIE, you can switch the bridges to `for await` with no other change.
- Liquid Glass: bottom panel, floating top card, buttons (`.glass`, `.glassProminent`), role cards on login.
- Sizes: every `.poppins(n)` and `.inter(n)` is scaled to about 90% in `Font.compact` (floor 11 pt), cards use 12 pt padding and 20 pt corners, the tab bar buttons are 42 pt and bottom spacing comes from `Metrics` in `Components.swift`, so the map shows more.
- No system toast on iOS: errors use the system alert (`errorAlert`); short successes (booking confirmed, booking cancelled, alert sent) use the `.toast(...)` capsule at the top of the user screen.
- Real device camera needs a signing team set in Xcode. The simulator falls back to the photo library.
- Round two: uncomment the `BaseUrl` line in `iosAppApp.swift` and set `USE_FAKE_DATA = false`. Plain http to localhost needs an App Transport Security exception.

## What is not verified
Nothing has been compiled: not the Gradle project, not the Kotlin, not the Swift or the Xcode project. Expect a few first-build errors and send them back.
