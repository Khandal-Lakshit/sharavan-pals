package com.app.raahi.app.presentation.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import androidx.navigation.navigation
import com.app.raahi.app.presentation.onboarding.LoginScreen
import com.app.raahi.app.presentation.onboarding.OnboardingScreen
import com.app.raahi.app.viewmodels.authviewmodel.AuthViewModel
import org.koin.androidx.compose.koinViewModel

fun NavGraphBuilder.authGraph(
    navController: NavHostController,
    modifier: Modifier,
    enter: (AnimatedContentTransitionScope<*>.() -> EnterTransition),
    exit: (AnimatedContentTransitionScope<*>.() -> ExitTransition),
    popEnter: (AnimatedContentTransitionScope<*>.() -> EnterTransition),
    popExit: (AnimatedContentTransitionScope<*>.() -> ExitTransition)
) {
    navigation(
        startDestination = Screen.Onboarding.route,
        route = Screen.Graph.AUTH
    ) {
        composable(
            route = Screen.Onboarding.route,
            enterTransition = enter,
            exitTransition = exit,
            popEnterTransition = popEnter,
            popExitTransition = popExit
        ) {
            OnboardingScreen(
                modifier = modifier,
                onToLogin = {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(Screen.Onboarding.route) { inclusive = true }
                    }
                }
            )
        }
        composable(
            route = Screen.Login.route,
            enterTransition = enter,
            exitTransition = exit,
            popEnterTransition = popEnter,
            popExitTransition = popExit
        ) {
            val viewModel: AuthViewModel = koinViewModel()
            LoginScreen(
                modifier = modifier,
                viewModel = viewModel,
                onToUserHome = {
                    navController.navigate(Screen.Graph.USER) {
                        popUpTo(Screen.Graph.AUTH) { inclusive = true }
                    }
                },
                onToHelperHome = {
                    navController.navigate(Screen.Graph.HELPER) {
                        popUpTo(Screen.Graph.AUTH) { inclusive = true }
                    }
                }
            )
        }
    }
}
