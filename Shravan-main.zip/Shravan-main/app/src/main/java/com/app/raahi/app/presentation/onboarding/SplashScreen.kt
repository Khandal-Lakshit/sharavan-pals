package com.app.raahi.app.presentation.onboarding

import android.provider.Settings
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.app.raahi.R
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

const val APP_NAME = "Shravan"
const val APP_TAGLINE = "Together with you."

/** Same iMessage green as the app icon and the Android 12 system splash, so the hand-over is seamless. */
private val SplashGreen = Color(0xFF34C759)
private val TextShadow = Shadow(color = Color(0x55000000), offset = Offset(0f, 3f), blurRadius = 10f)

/**
 * Opening animation: a white disc pops in, then inside it the four fingers of the Helping Hand rise one after the other,
 * the thumb swings in, the location pin drops into the palm, the hand gives a small wave, then the name and tagline fade up in white. Tap to skip. With
 * animations turned off in system settings it just shows the finished logo briefly.
 */
@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val context = LocalContext.current
    val reduceMotion = remember {
        Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    }
    val still = if (reduceMotion) 1f else 0f
    val disc = remember { Animatable(still) }
    val fingers = remember { List(4) { Animatable(still) } }
    val thumb = remember { Animatable(still) }
    val pin = remember { Animatable(still) }
    val wave = remember { Animatable(0f) }
    val name = remember { Animatable(still) }
    val tagline = remember { Animatable(still) }
    val screen = remember { Animatable(1f) }

    LaunchedEffect(Unit) {
        if (reduceMotion) {
            delay(900)
        } else coroutineScope {
            launch { disc.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)) }
            delay(250)
            fingers.forEachIndexed { i, a ->
                launch {
                    delay(i * 90L)
                    a.animateTo(1f, spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessLow))
                }
            }
            launch {
                delay(380)
                thumb.animateTo(1f, spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMediumLow))
            }
            launch {
                delay(560)
                pin.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow))
            }
            launch { delay(1500); name.animateTo(1f, tween(450)) }
            launch { delay(1700); tagline.animateTo(1f, tween(450)) }
            delay(1400)
            wave.animateTo(-1f, tween(170))
            wave.animateTo(1f, tween(260))
            wave.animateTo(-0.5f, tween(200))
            wave.animateTo(0f, tween(180))
            delay(1000)
        }
        screen.animateTo(0f, tween(300))
        onFinished()
    }

    val rise = with(LocalDensity.current) { 60.dp.toPx() }
    val drop = with(LocalDensity.current) { 100.dp.toPx() }

    Box(
        Modifier
            .fillMaxSize()
            .alpha(screen.value)
            .background(SplashGreen)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onFinished() }
            .semantics { contentDescription = "$APP_NAME. $APP_TAGLINE" },
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(24.dp)) {
            Box(
                Modifier
                    .size(240.dp)
                    .graphicsLayer { scaleX = disc.value; scaleY = disc.value }
                    .clip(CircleShape)
                    .background(Color.White),
            ) {
                // the hand sits in the middle of the disc and pivots at the wrist when it waves
                Box(
                    Modifier.fillMaxSize().graphicsLayer {
                        transformOrigin = TransformOrigin(0.5f, 0.8f)
                        rotationZ = wave.value * 7f
                    },
                ) {
                    val pieces = listOf(R.drawable.splash_f0, R.drawable.splash_f1, R.drawable.splash_f2, R.drawable.splash_f3)
                    pieces.forEachIndexed { i, res ->
                        Image(
                            painterResource(res), contentDescription = null,
                            modifier = Modifier.fillMaxSize().graphicsLayer {
                                val v = fingers[i].value
                                translationY = (1f - v) * rise
                                alpha = v.coerceIn(0f, 1f)
                            },
                        )
                    }
                    Image(
                        painterResource(R.drawable.splash_thumb), contentDescription = null,
                        modifier = Modifier.fillMaxSize().graphicsLayer {
                            val v = thumb.value
                            transformOrigin = TransformOrigin(0.38f, 0.66f)
                            rotationZ = (1f - v) * 55f
                            alpha = v.coerceIn(0f, 1f)
                        },
                    )
                    Image(
                        painterResource(R.drawable.splash_pin), contentDescription = null,
                        modifier = Modifier.fillMaxSize().graphicsLayer {
                            val v = pin.value
                            translationY = (v - 1f) * drop
                            alpha = (v * 3f).coerceIn(0f, 1f)
                        },
                    )
                }
            }
            Column(
                Modifier.clearAndSetSemantics { },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Text(
                    APP_NAME,
                    style = MaterialTheme.typography.displayMedium.copy(shadow = TextShadow),
                    color = Color.White,
                    modifier = Modifier.graphicsLayer { alpha = name.value; translationY = (1f - name.value) * 24f },
                )
                Text(
                    APP_TAGLINE,
                    style = MaterialTheme.typography.titleMedium.copy(shadow = TextShadow),
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 32.dp)
                        .graphicsLayer { alpha = tagline.value; translationY = (1f - tagline.value) * 16f },
                )
            }
        }
    }
}
