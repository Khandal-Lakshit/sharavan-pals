package com.app.raahi.app.presentation.user

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import com.app.raahi.app.presentation.globalcomponents.BarrierRow
import com.app.raahi.app.presentation.globalcomponents.ConfidenceCard
import com.app.raahi.app.presentation.globalcomponents.GlyphBadge
import com.app.raahi.app.presentation.globalcomponents.RaahiCard
import com.app.raahi.app.presentation.globalcomponents.RouteLegend
import com.app.raahi.app.presentation.globalcomponents.RouteStat
import com.app.raahi.app.presentation.globalcomponents.SectionTitle
import com.app.raahi.app.viewmodels.routeviewmodel.RouteViewModel

/** Bottom card on Home once a route exists: compare the two routes, ask a helper, see the barriers, read directions. */
@Composable
fun RoutePanel(viewModel: RouteViewModel) {
    val plan by viewModel.plan.collectAsState()
    val banner by viewModel.rerouteBanner.collectAsState()
    val requested by viewModel.checkRequested.collectAsState()
    val barriers by viewModel.barriersOnMap.collectAsState()
    val showDirections by viewModel.showDirections.collectAsState()
    val p = plan ?: return

    val maxHeight = (LocalConfiguration.current.screenHeightDp * 0.34f).dp
    Column(
        Modifier.fillMaxWidth().heightIn(max = maxHeight).verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        banner?.let {
            RaahiCard(container = MaterialTheme.colorScheme.tertiaryContainer) {
                Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                    GlyphBadge("⚠️", size = 40, container = MaterialTheme.colorScheme.surface)
                    Column(Modifier.weight(1f)) {
                        Text("Your route was updated", style = MaterialTheme.typography.titleSmall)
                        Text(it, style = MaterialTheme.typography.bodyMedium)
                        TextButton(onClick = viewModel::dismissBanner, modifier = Modifier.heightIn(min = 48.dp)) {
                            Text("Dismiss", style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }
        }

        Text("About ${p.safe.durationMin} min · ${p.safe.distanceM} m", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RouteStat(
                title = "Barrier-free",
                meters = p.safe.distanceM,
                minutes = p.safe.durationMin,
                barriers = p.safe.barriers.size,
                highlighted = true,
                modifier = Modifier.weight(1f),
                extra = if (p.extraDistanceM > 0) "+${p.extraDistanceM} m longer" else null,
                imagery = p.safe.imagery,
            )
            RouteStat(
                title = "Normal",
                meters = p.baseline.distanceM,
                minutes = p.baseline.durationMin,
                barriers = p.baseline.barriers.size,
                highlighted = false,
                modifier = Modifier.weight(1f),
                imagery = p.baseline.imagery,
            )
        }
        RouteLegend()
        ConfidenceCard(barrierFree = p.safe.imagery, normal = p.baseline.imagery)
        OutlinedButton(
            onClick = viewModel::askHelperToCheck,
            enabled = !requested,
            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
            shape = CircleShape,
        ) {
            Text(
                if (requested) "Helping Hand asked ✓" else "Ask a Helping Hand to check this route",
                style = MaterialTheme.typography.titleSmall,
            )
        }
        if (requested) {
            Text(
                "Helping Hands around this route were alerted. You will get an alert here when one has checked it.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (barriers.isNotEmpty()) {
            SectionTitle("Barriers on the normal route")
            barriers.forEach { b -> BarrierRow(b) { viewModel.selectBarrier(b.id) } }
        }
        TextButton(onClick = viewModel::toggleDirections, modifier = Modifier.heightIn(min = 48.dp)) {
            Text(if (showDirections) "Hide directions" else "Show directions as text", style = MaterialTheme.typography.labelLarge)
        }
        if (showDirections) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                p.safe.steps.forEachIndexed { i, st ->
                    Text("${i + 1}. ${st.text}", style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}
