package com.app.raahi.app.presentation.helper

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.location.Geocoder
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.semantics.Role as SemanticsRole
import com.app.raahi.R
import com.app.raahi.app.presentation.globalcomponents.Avatar
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.ui.focus.onFocusEvent
import kotlinx.coroutines.delay
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.BottomSheetScaffold
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.app.raahi.app.Events
import com.app.raahi.app.domain.model.BarrierType
import com.app.raahi.app.domain.model.DemoArea
import com.app.raahi.app.domain.model.GeoPoint
import com.app.raahi.app.domain.model.HelpRequest
import com.app.raahi.app.presentation.globalcomponents.GlyphBadge
import com.app.raahi.app.presentation.globalcomponents.PhotoUtils
import com.app.raahi.app.presentation.globalcomponents.Pill
import com.app.raahi.app.presentation.globalcomponents.hairlineBorder
import com.app.raahi.app.presentation.globalcomponents.RaahiCard
import com.app.raahi.app.presentation.globalcomponents.RaahiMap
import com.app.raahi.app.presentation.globalcomponents.SetStatusBarDarkIcons
import com.app.raahi.app.presentation.profile.HelperProfileContent
import com.app.raahi.ui.theme.GreenDeep
import com.app.raahi.ui.theme.MessageGreen
import com.app.raahi.app.viewmodels.helperviewmodel.HelperViewModel
import com.app.raahi.core.presentation.util.ObserveAsEvents
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

@Suppress("DEPRECATION")
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun HelperHomeScreen(
    modifier: Modifier = Modifier,
    viewModel: HelperViewModel,
    onLogout: () -> Unit = {}
) {
    SetStatusBarDarkIcons(darkIcons = !isSystemInDarkTheme())
    val ctx = LocalContext.current
    val userName by viewModel.userName.collectAsState()
    val userBadge by viewModel.userBadge.collectAsState()
    val scope = rememberCoroutineScope()

    val requests by viewModel.requests.collectAsState()
    val incoming by viewModel.incomingAlert.collectAsState()
    val selectedId by viewModel.selectedRequestId.collectAsState()
    val route by viewModel.requestedRoute.collectAsState()
    val barriers by viewModel.barriers.collectAsState()
    val location by viewModel.location.collectAsState()
    val status by viewModel.status.collectAsState()
    val note by viewModel.note.collectAsState()
    val photo by viewModel.photo.collectAsState()
    val submitting by viewModel.isSubmitting.collectAsState()
    val canSubmit by viewModel.canSubmit.collectAsState()
    val result by viewModel.lastResult.collectAsState()

    ObserveAsEvents(viewModel.events) { event ->
        when (event) {
            is Events.Success -> Toast.makeText(ctx, event.message ?: "Done", Toast.LENGTH_SHORT).show()
            is Events.Error -> Toast.makeText(ctx, event.message ?: "Something went wrong", Toast.LENGTH_LONG).show()
            else -> {}
        }
    }

    var showProfile by remember { mutableStateOf(false) }
    var gpsFocus by remember { mutableStateOf<GeoPoint?>(null) }
    // City / area name for the chosen point. Needs the device geocoder and a network; falls back to coordinates only.
    val placeName by produceState<String?>(initialValue = null, key1 = location) {
        value = null
        val p = location ?: return@produceState
        value = withContext(Dispatchers.IO) {
            runCatching {
                if (!Geocoder.isPresent()) null
                else Geocoder(ctx, Locale.getDefault()).getFromLocation(p.lat, p.lon, 1)
                    ?.firstOrNull()
                    ?.let { a -> listOfNotNull(a.subLocality ?: a.thoroughfare, a.locality).distinct().joinToString(", ").ifBlank { null } }
            }.getOrNull()
        }
    }
    fun readGps() = PhotoUtils.currentLocation(ctx) { point ->
        if (point != null) { viewModel.setLocation(point); gpsFocus = point }
        else Toast.makeText(ctx, "Could not get a GPS fix. Tap the map instead.", Toast.LENGTH_SHORT).show()
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) readGps() else Toast.makeText(ctx, "Location permission denied. Tap the map instead.", Toast.LENGTH_SHORT).show()
    }

    var pendingUri by remember { mutableStateOf<Uri?>(null) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val uri = pendingUri
        if (ok && uri != null) {
            scope.launch {
                val bytes = withContext(Dispatchers.IO) { PhotoUtils.compress(ctx, uri) }
                if (bytes != null) viewModel.setPhoto(bytes)
                else Toast.makeText(ctx, "Could not read the photo. Try again.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val noteVisible = remember { BringIntoViewRequester() }

    BottomSheetScaffold(
        // Edge-to-edge means the manifest's adjustResize alone no longer lifts anything: the screen has to take the
        // keyboard height itself, so the sheet rides above the keyboard.
        modifier = Modifier.fillMaxSize().imePadding(),
        sheetPeekHeight = 196.dp + WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding(),
        sheetContainerColor = MaterialTheme.colorScheme.surface,
        sheetShape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        sheetContent = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 620.dp).verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp).padding(bottom = 24.dp).navigationBarsPadding(),
                verticalArrangement = Arrangement.spacedBy(20.dp),
            ) {
                Section("What do you see?") {
                    FlowRow(
                        maxItemsInEachRow = 2,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        BarrierType.entries.forEach { type ->
                            TypeTile(type, selected = status == type, onClick = { viewModel.setStatus(type) }, modifier = Modifier.weight(1f))
                        }
                    }
                }

                Section("Route to check") {
                    if (requests.isEmpty()) {
                        Text(
                            "No open requests right now. You can still report any barrier you see.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    } else {
                        requests.forEach { r ->
                            val selected = r.id == selectedId
                            Surface(
                                modifier = Modifier.fillMaxWidth().clip(MaterialTheme.shapes.large)
                                    .selectable(selected = selected, role = SemanticsRole.RadioButton) {
                                        viewModel.selectRequest(if (selected) null else r.id)
                                    }
                                    .semantics { contentDescription = "${r.userName} asks: ${r.title}. ${if (selected) "Selected." else "Double tap to select."}" },
                                shape = MaterialTheme.shapes.large,
                                color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                border = if (selected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else hairlineBorder(),
                            ) {
                                Row(
                                    Modifier.heightIn(min = 64.dp).padding(horizontal = 14.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                ) {
                                    Avatar(r.userName, size = 40)
                                    Column(Modifier.weight(1f)) {
                                        Text(r.userName, style = MaterialTheme.typography.titleSmall)
                                        Text(r.title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    RadioButton(selected = selected, onClick = null)
                                }
                            }
                        }
                        OutlinedButton(
                            onClick = viewModel::markRouteChecked,
                            enabled = selectedId != null,
                            modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                            shape = CircleShape,
                        ) { Text("Mark route checked", style = MaterialTheme.typography.titleSmall) }
                    }
                }

                Section("Photo and note") {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(
                            onClick = {
                                val file = File(ctx.cacheDir, "images/report_${System.currentTimeMillis()}.jpg").also { it.parentFile?.mkdirs() }
                                val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
                                pendingUri = uri
                                camera.launch(uri)
                            },
                            modifier = Modifier.heightIn(min = 52.dp),
                            shape = CircleShape,
                        ) { Text(if (photo == null) "Take photo" else "Retake photo", style = MaterialTheme.typography.titleSmall) }
                        photo?.let { bytes ->
                            val bmp = remember(bytes) {
                                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = 4 })
                            }
                            if (bmp != null) {
                                Image(
                                    bitmap = bmp.asImageBitmap(),
                                    contentDescription = "Preview of the photo you took",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.size(64.dp).clip(MaterialTheme.shapes.medium),
                                )
                            }
                        }
                    }
                    OutlinedTextField(
                        value = note,
                        onValueChange = viewModel::setNote,
                        label = { Text("Note (optional)") },
                        singleLine = true,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth()
                            .bringIntoViewRequester(noteVisible)
                            .onFocusEvent { focus ->
                                if (focus.isFocused) scope.launch { delay(350); noteVisible.bringIntoView() }   // after the keyboard has animated in
                            },
                    )
                }

                Button(
                    onClick = viewModel::submit,
                    enabled = canSubmit && !submitting,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
                    shape = CircleShape,
                ) {
                    if (submitting) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    else Text("Submit report", style = MaterialTheme.typography.titleSmall)
                }

                result?.let { r ->
                    RaahiCard(container = MaterialTheme.colorScheme.secondaryContainer) {
                        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                            GlyphBadge("\u2705", size = 40, container = MaterialTheme.colorScheme.surface)
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("Report saved", style = MaterialTheme.typography.titleSmall)
                                    if (r.verified) Pill("Verified")
                                }
                                Text(
                                    "Matched to footpath ${r.segmentId}, ${r.snapDistanceM.toInt()} m from your point.",
                                    style = MaterialTheme.typography.bodyMedium,
                                )
                                r.aiSuggestion?.let {
                                    Text("Demo detection: $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        },
    ) { inner ->
        Box(Modifier.fillMaxSize().padding(bottom = inner.calculateBottomPadding())) {
            RaahiMap(
                modifier = Modifier.fillMaxSize(),
                description = "Map. Tap to set where you are. Known barriers are marked.",
                safe = route,
                barriers = barriers,
                marker = location,
                focus = gpsFocus,
                fitTo = route,
                fitPaddingTop = 250.dp,
                onMapClick = viewModel::setLocation,
            )
            Column(
                Modifier.statusBarsPadding().padding(top = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                HelperTopRow(userName, onOpenProfile = { showProfile = true }, onLogout = onLogout)
                incoming?.let { r ->
                    HelpAlertCard(r, onCheck = { viewModel.acceptAlert(r.id) }, onLater = { viewModel.dismissAlert(r.id) })
                }
                Surface(
                    modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.surface,
                    border = hairlineBorder(),
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Avatar(userName.ifBlank { "H" }, size = 40)
                            Column(Modifier.weight(1f)) {
                                Text(if (userName.isBlank()) "Helping Hand" else userName, style = MaterialTheme.typography.titleSmall)
                                if (userBadge.isNotBlank()) {
                                    Text("\u2713 $userBadge", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                                }
                            }
                            Pill("Only verified Helping Hands report")
                        }
                        val point = location
                        if (point == null) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Button(
                                    onClick = {
                                        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                                        if (granted) readGps() else permission.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                                    },
                                    modifier = Modifier.heightIn(min = 48.dp),
                                    shape = CircleShape,
                                ) { Text("Use my GPS", style = MaterialTheme.typography.titleSmall) }
                                Text(
                                    "Or tap the map",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        } else {
                            // The location is set: the GPS button gives way to a status line with a way to change it.
                            Row(
                                Modifier.semantics(mergeDescendants = true) {
                                    contentDescription = "Location set at %.5f, %.5f.".format(point.lat, point.lon)
                                },
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                GlyphBadge("\uD83D\uDCCD", size = 40, container = MaterialTheme.colorScheme.primaryContainer)
                                Column(Modifier.weight(1f)) {
                                    val placeLabel = placeName ?: DemoArea.cityFor(point)
                                    Text(placeLabel ?: "Location set", style = MaterialTheme.typography.titleSmall, maxLines = 1)
                                    Text(
                                        (if (placeLabel != null) "Location set \u00B7 " else "") + "%.5f, %.5f".format(point.lat, point.lon),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                OutlinedButton(
                                    onClick = { gpsFocus = null; viewModel.clearLocation() },
                                    modifier = Modifier.heightIn(min = 44.dp),
                                    shape = CircleShape,
                                ) { Text("Change", style = MaterialTheme.typography.labelLarge) }
                            }
                        }
                    }
                }
            }
        }

        if (showProfile) {
            ModalBottomSheet(
                onDismissRequest = { showProfile = false },
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
                containerColor = MaterialTheme.colorScheme.surface,
            ) {
                HelperProfileContent(
                    userName = userName,
                    userBadge = userBadge,
                    onLogout = { showProfile = false; onLogout() },
                    onDismiss = { showProfile = false },
                )
            }
        }
    }
}

/** "Asha needs help around this route": shown when a user asks for a check; Check route opens it on the map. */
@Composable
private fun HelpAlertCard(request: HelpRequest, onCheck: () -> Unit, onLater: () -> Unit) {
    val city = request.polyline.firstOrNull()?.let { DemoArea.cityFor(it) }
    Surface(
        modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().semantics { liveRegion = LiveRegionMode.Polite },
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.primaryContainer,
        border = BorderStroke(0.5.dp, MessageGreen.copy(alpha = 0.6f)),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                GlyphBadge("\uD83D\uDD14", size = 40, container = MaterialTheme.colorScheme.surface)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("${request.userName} needs help", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "Please check this route: ${request.title}" + (city?.let { " \u00B7 $it" } ?: ""),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = onCheck, modifier = Modifier.heightIn(min = 48.dp), shape = CircleShape) {
                    Text("Check route", style = MaterialTheme.typography.titleSmall)
                }
                TextButton(onClick = onLater, modifier = Modifier.heightIn(min = 48.dp)) {
                    Text("Later", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
private fun HelperTopRow(userName: String, onOpenProfile: () -> Unit, onLogout: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surface, border = hairlineBorder()) {
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Icon(
                    painterResource(R.drawable.ic_explore),
                    contentDescription = null,
                    tint = GreenDeep,
                    modifier = Modifier.size(18.dp),
                )
                Text(
                    "Shravan",
                    style = MaterialTheme.typography.titleMedium,
                    color = GreenDeep,
                )
            }
        }
        Box(Modifier.weight(1f))
        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surface,
            border = hairlineBorder(),
            modifier = Modifier.heightIn(min = 44.dp).clip(CircleShape).clickable(onClick = onOpenProfile),
        ) {
            Row(
                Modifier.padding(start = 6.dp, end = 16.dp).heightIn(min = 44.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Avatar(userName.ifBlank { "H" }, size = 30)
                Text(userName.ifBlank { "Profile" }, style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

/** One barrier type: round icon and label. Selected = green outline on a green tint. */
@Composable
private fun TypeTile(type: BarrierType, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.heightIn(min = 60.dp).clip(MaterialTheme.shapes.large)
            .selectable(selected = selected, role = SemanticsRole.RadioButton, onClick = onClick)
            .semantics { contentDescription = type.label },
        shape = MaterialTheme.shapes.large,
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        border = if (selected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else hairlineBorder(),
    ) {
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            GlyphBadge(type.symbol, size = 36, container = MaterialTheme.colorScheme.surface)
            Text(type.label, style = MaterialTheme.typography.labelLarge, maxLines = 2)
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        content()
    }
}
