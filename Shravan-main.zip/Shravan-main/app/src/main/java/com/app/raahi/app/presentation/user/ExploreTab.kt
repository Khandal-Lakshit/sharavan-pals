package com.app.raahi.app.presentation.user

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.app.raahi.app.domain.model.NearbyVenue
import com.app.raahi.app.domain.model.REVIEWER_NEEDS
import com.app.raahi.app.domain.model.VERIFICATION_TOPICS
import com.app.raahi.app.domain.model.Venue
import com.app.raahi.app.domain.model.VenueCategory
import com.app.raahi.app.domain.model.VenueReview
import com.app.raahi.app.presentation.globalcomponents.Avatar
import com.app.raahi.ui.theme.GreenDeep
import com.app.raahi.app.presentation.globalcomponents.FilterPill
import com.app.raahi.app.presentation.globalcomponents.GlyphBadge
import com.app.raahi.app.presentation.globalcomponents.RaahiCard
import com.app.raahi.app.presentation.globalcomponents.floatingBarClearance
import com.app.raahi.app.viewmodels.routeviewmodel.ExploreFilter
import com.app.raahi.app.viewmodels.routeviewmodel.RouteViewModel

private fun distanceLabel(m: Int) = if (m < 1000) "$m m" else "%.1f km".format(m / 1000.0)

/**
 * Friendly places around the user (demo data): cafes, parks and libraries with the access features that matter, a
 * Route button that opens the route from the user's location on the Home map.
 */
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ExploreTab(viewModel: RouteViewModel) {
    val nearby by viewModel.nearby.collectAsState()
    val filter by viewModel.exploreFilter.collectAsState()
    var openId by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = floatingBarClearance() + 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("Around you", style = MaterialTheme.typography.headlineSmall)
                Text(
                    "Friendly places near your location. Demo data.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ExploreFilter.entries.toList()) { f ->
                    FilterPill(f.label, selected = f == filter, onClick = { viewModel.setExploreFilter(f) })
                }
            }
        }
        items(nearby, key = { it.venue.id }) { n ->
            VenueCard(n, onRoute = { viewModel.goTo(n.venue) }, onReviews = { openId = n.venue.id })
        }
    }

    nearby.firstOrNull { it.venue.id == openId }?.venue?.let { v ->
        ModalBottomSheet(
            onDismissRequest = { openId = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surface,
        ) {
            VenueSheet(v, onPost = { rating, need, text -> viewModel.postReview(v.id, rating, need, text) })
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun VenueCard(n: NearbyVenue, onRoute: () -> Unit, onReviews: () -> Unit) {
    val v = n.venue
    RaahiCard(
        modifier = Modifier.semantics {
            contentDescription = "${v.name}, ${v.category.label}, ${distanceLabel(n.distanceM)} away, rated ${v.displayRating} from ${v.reviews.size} reviews. " +
                (if (v.isVerified) "Shravan Verified. " else "") + "Features: ${v.features.joinToString(", ")}."
        },
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                GlyphBadge(v.category.symbol, size = 44)
                Column(Modifier.weight(1f)) {
                    Text(v.name, style = MaterialTheme.typography.titleMedium)
                    if (v.isVerified) VerifiedBadge()
                    Text(
                        "${v.category.label} · ${distanceLabel(n.distanceM)} · ★ ${v.displayRating} (${v.reviews.size})",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                v.features.forEach { f ->
                    Box(Modifier.clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 10.dp, vertical = 4.dp)) {
                        Text(f, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
            Text(v.note, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onRoute, modifier = Modifier.weight(1f).heightIn(min = 48.dp), shape = CircleShape) {
                    Text("Route", style = MaterialTheme.typography.titleSmall)
                }
                OutlinedButton(onClick = onReviews, modifier = Modifier.weight(1f).heightIn(min = 48.dp), shape = CircleShape) {
                    Text("Reviews", style = MaterialTheme.typography.titleSmall)
                }
            }
        }
    }
}

private val StarGold = Color(0xFFF2B01E)

/** The Shravan Verified mark: a place has shared its videos and answered the access Q&A. */
@Composable
private fun VerifiedBadge() {
    Box(
        Modifier.padding(top = 2.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer)
            .padding(horizontal = 8.dp, vertical = 2.dp)
            .semantics { contentDescription = "Shravan Verified" },
    ) {
        Text("✓ Shravan Verified", style = MaterialTheme.typography.labelMedium, color = GreenDeep)
    }
}

/** Bottom sheet: the verification checklist, reviews from other disabled visitors, and a way to add one. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun VenueSheet(v: Venue, onPost: (Int, String, String) -> Unit) {
    var writing by remember { mutableStateOf(false) }
    var stars by remember { mutableStateOf(5) }
    var need by remember { mutableStateOf(REVIEWER_NEEDS.first()) }
    var text by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).imePadding().navigationBarsPadding()
            .padding(start = 20.dp, end = 20.dp, bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            GlyphBadge(v.category.symbol, size = 44)
            Column(Modifier.weight(1f)) {
                Text(v.name, style = MaterialTheme.typography.headlineSmall)
                Text(
                    "★ ${v.displayRating} from ${v.reviews.size} disabled visitors",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        if (v.category == VenueCategory.CAFE) {
            RaahiCard(container = if (v.isVerified) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        if (v.isVerified) "✓ Shravan Verified" else "Not verified yet",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (v.isVerified) GreenDeep else MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        "A cafe earns this by sharing a video on each topic below and answering our access questions.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    VERIFICATION_TOPICS.forEach { topic ->
                        val done = topic in v.verification.videoTopics
                        Text(
                            (if (done) "✓  " else "○  ") + "$topic video " + (if (done) "shared" else "missing"),
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (done) GreenDeep else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Text(
                        "Access Q&A: ${v.verification.qaDone} of ${v.verification.qaTotal} answered",
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (v.verification.qaDone >= v.verification.qaTotal) GreenDeep else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        Text("How other disabled visitors were treated", style = MaterialTheme.typography.titleMedium)
        if (v.reviews.isEmpty()) {
            Text("No reviews yet. Be the first.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        v.reviews.forEach { r -> ReviewRow(r) }

        if (!writing) {
            Button(
                onClick = { writing = true },
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                shape = CircleShape,
            ) { Text("Write a review", style = MaterialTheme.typography.titleSmall) }
        } else {
            Text("How were you treated?", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                (1..5).forEach { i ->
                    Text(
                        "★",
                        style = MaterialTheme.typography.headlineMedium,
                        color = if (i <= stars) StarGold else MaterialTheme.colorScheme.outlineVariant,
                        modifier = Modifier.heightIn(min = 48.dp).clickable(role = Role.Button) { stars = i }
                            .padding(horizontal = 6.dp)
                            .semantics { contentDescription = "$i stars" },
                    )
                }
            }
            Text("About you", style = MaterialTheme.typography.titleSmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                REVIEWER_NEEDS.forEach { option -> FilterPill(option, selected = option == need, onClick = { need = option }) }
            }
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text("Were staff patient? Was the washroom usable? Did you feel safe?") },
                shape = MaterialTheme.shapes.medium,
                minLines = 3,
                modifier = Modifier.fillMaxWidth(),
            )
            Button(
                onClick = { onPost(stars, need, text); text = ""; stars = 5; writing = false },
                enabled = text.isNotBlank(),
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                shape = CircleShape,
            ) { Text("Post review", style = MaterialTheme.typography.titleSmall) }
        }
    }
}

@Composable
private fun ReviewRow(r: VenueReview) {
    Row(
        Modifier.fillMaxWidth().semantics(mergeDescendants = true) {
            contentDescription = "${r.author}, ${r.need}, ${r.rating} stars, ${r.whenLabel}. ${r.text}"
        },
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Avatar(r.author, size = 36)
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("${r.author} · ${r.need}", style = MaterialTheme.typography.titleSmall)
            Text(
                "★".repeat(r.rating) + "  " + r.whenLabel,
                style = MaterialTheme.typography.labelMedium,
                color = StarGold,
            )
            Text(r.text, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
