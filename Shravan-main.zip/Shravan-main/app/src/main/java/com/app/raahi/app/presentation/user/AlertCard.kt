package com.app.raahi.app.presentation.user

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.app.raahi.R
import com.app.raahi.app.domain.model.Alert
import com.app.raahi.app.domain.model.AlertType
import com.app.raahi.app.presentation.globalcomponents.Avatar
import com.app.raahi.app.presentation.globalcomponents.GlyphBadge
import com.app.raahi.app.presentation.globalcomponents.Pill
import com.app.raahi.app.presentation.globalcomponents.RaahiCard
import com.app.raahi.app.presentation.globalcomponents.formatTime
import com.app.raahi.ui.theme.GreenDeep
import com.app.raahi.ui.theme.MessageGreen
import com.app.raahi.ui.theme.WarnVermillion

/**
 * One alert, in full: what it is about, who sent it, where it is, what it did to the route, and a way to see it on the
 * map. A warning shows the barrier (type, photo, the helper's note); a "route checked" alert shows who checked it.
 */
@Composable
fun AlertCard(alert: Alert, onShowOnMap: (String) -> Unit, modifier: Modifier = Modifier) {
    val barrier = alert.barrier
    val isWarning = alert.type == AlertType.ROUTE_ISSUE
    val caption = when (alert.type) {
        AlertType.ROUTE_ISSUE -> "WARNING ON YOUR ROUTE"
        AlertType.ROUTE_CHECKED -> "ROUTE CHECKED"
        AlertType.OTHER -> "UPDATE"
    }
    val title = when {
        barrier != null -> barrier.type.label
        alert.type == AlertType.ROUTE_CHECKED -> "A Helping Hand checked your route"
        else -> alert.message
    }

    RaahiCard(
        modifier = modifier.semantics {
            contentDescription = buildString {
                if (!alert.isRead) append("New. ")
                append(caption.lowercase()).append(". ").append(title).append(". ")
                barrier?.note?.let { append(it).append(". ") }
                alert.senderName?.let { append("Sent by ").append(it).append(alert.senderBadge?.let { b -> ", $b" } ?: "").append(". ") }
                alert.placeLabel?.let { append(it).append(". ") }
            }
        },
        container = if (alert.isRead) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.primaryContainer,
        borderColor = if (alert.isRead) MaterialTheme.colorScheme.outlineVariant else MessageGreen.copy(alpha = 0.5f),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                GlyphBadge(
                    barrier?.type?.symbol ?: if (isWarning) "⚠️" else "✅",
                    size = 48,
                    container = if (isWarning) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.secondaryContainer,
                )
                Column(Modifier.weight(1f)) {
                    Text(
                        caption,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isWarning) WarnVermillion else GreenDeep,
                    )
                    Text(title, style = MaterialTheme.typography.titleLarge)
                }
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (!alert.isRead) Pill("NEW")
                    Text(formatTime(alert.createdAt), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            barrier?.imageUrl?.let { url ->
                AsyncImage(
                    model = url,
                    contentDescription = "Photo from the Helping Hand: ${barrier.type.label}",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(MaterialTheme.shapes.medium),
                )
            }

            barrier?.note?.takeIf { it.isNotBlank() }?.let {
                Text("“$it”", style = MaterialTheme.typography.bodyLarge)
            }

            alert.placeLabel?.let {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
                    Text("📍", style = MaterialTheme.typography.bodyMedium)
                    Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            alert.senderName?.let { name ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(name, size = 32)
                    Column {
                        Text(if (isWarning) "Reported by $name" else "Checked by $name", style = MaterialTheme.typography.titleSmall)
                        alert.senderBadge?.let { badge ->
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(painterResource(R.drawable.ic_check), contentDescription = null, tint = GreenDeep, modifier = Modifier.size(14.dp))
                                Text(badge, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }

            if (isWarning) {
                val extra = alert.extraDistanceM
                Box(
                    Modifier.clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                ) {
                    Text(
                        when {
                            extra != null && extra > 0 -> "Your route was updated, $extra m longer"
                            extra != null && extra < 0 -> "Your route was updated, ${-extra} m shorter"
                            else -> "Your route was updated"
                        },
                        style = MaterialTheme.typography.labelLarge,
                    )
                }
                if (barrier != null) {
                    OutlinedButton(
                        onClick = { onShowOnMap(barrier.id) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                        shape = CircleShape,
                    ) { Text("Show on map", style = MaterialTheme.typography.titleSmall) }
                }
            }
        }
    }
}
