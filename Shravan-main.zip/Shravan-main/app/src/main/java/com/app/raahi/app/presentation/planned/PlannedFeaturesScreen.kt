package com.app.raahi.app.presentation.planned

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.app.raahi.app.presentation.globalcomponents.GlyphBadge
import com.app.raahi.app.presentation.globalcomponents.PlannedTag
import com.app.raahi.app.presentation.globalcomponents.RaahiCard
import com.app.raahi.app.presentation.globalcomponents.floatingBarClearance
import com.app.raahi.ui.theme.MessageGreen

private data class Planned(val emoji: String, val title: String, val body: String)

private val items = listOf(
    Planned("🆘", "SOS with handling notes", "Hold for 3 seconds. Contacts get a push and a short link; the nearest partner hospital sees your location and your own instructions on how to move you."),
    Planned("🩺", "Medical and handling card", "You write how responders should help, for example \"do not lift under the arms\". Every field is optional and only shared during an SOS."),
    Planned("🚕", "Ride-app partners", "Verified drivers on ride apps report barriers as they drive. Needs a partnership with a ride company."),
    Planned("👥", "Friends and caretakers", "Trusted contacts, live location sharing, and verified Helping Hand partners."),
    Planned("🗣️", "Voice control", "\"Take me to the nearest cafe with a ramp\". Every voice action will also work by touch."),
)

@Composable
fun PlannedFeaturesScreen(modifier: Modifier = Modifier) {
    // Status bar inset on top, floating bar clearance at the bottom, 20 dp on the sides.
    Column(
        modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = floatingBarClearance() + 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Column(Modifier.padding(bottom = 4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Coming next", style = MaterialTheme.typography.headlineSmall)
            Text(
                "Designed with disabled users. Not live in this prototype.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        items.forEach { item ->
            RaahiCard {
                Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.Top) {
                    GlyphBadge(item.emoji)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(item.title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                            PlannedTag()
                        }
                        Text(item.body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        RaahiCard(container = MaterialTheme.colorScheme.primaryContainer, borderColor = MessageGreen.copy(alpha = 0.5f)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Preview: card a responder would open", style = MaterialTheme.typography.titleSmall)
                Text("Name: Asha (demo)", style = MaterialTheme.typography.bodyMedium)
                Text("Uses: power wheelchair, battery is heavy", style = MaterialTheme.typography.bodyMedium)
                Text("Handling: do not lift under the arms. Speak before touching.", style = MaterialTheme.typography.bodyMedium)
                Text("Static mock. Nothing is sent anywhere.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
