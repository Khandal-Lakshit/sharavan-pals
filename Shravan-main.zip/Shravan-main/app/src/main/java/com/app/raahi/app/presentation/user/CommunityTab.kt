package com.app.raahi.app.presentation.user

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.app.raahi.R
import com.app.raahi.app.domain.model.ChatMessage
import com.app.raahi.app.domain.model.CommunityGroup
import com.app.raahi.app.domain.model.GroupMember
import com.app.raahi.app.presentation.globalcomponents.Avatar
import com.app.raahi.app.presentation.globalcomponents.FilterPill
import com.app.raahi.app.presentation.globalcomponents.GlyphBadge
import com.app.raahi.app.presentation.globalcomponents.Pill
import com.app.raahi.app.presentation.globalcomponents.floatingBarClearance
import com.app.raahi.app.presentation.globalcomponents.hairlineBorder
import com.app.raahi.app.viewmodels.routeviewmodel.CommunityFilter
import com.app.raahi.app.viewmodels.routeviewmodel.RouteViewModel
import com.app.raahi.app.viewmodels.routeviewmodel.UserTab
import com.app.raahi.ui.theme.GreenDeep

@Composable
fun CommunityTab(viewModel: RouteViewModel) {
    val groups by viewModel.communityGroups.collectAsState()
    val allMessages by viewModel.communityMessages.collectAsState()
    val searchQuery by viewModel.communitySearch.collectAsState()
    val filter by viewModel.communityFilter.collectAsState()
    val unreadAlerts by viewModel.unreadCount.collectAsState()

    var activeChatGroup by remember { mutableStateOf<CommunityGroup?>(null) }
    var showGroupInfo by remember { mutableStateOf(false) }

    Box(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .background(MaterialTheme.colorScheme.background)
    ) {
        val active = activeChatGroup
        when {
            showGroupInfo && active != null -> {
                // Screen 3: WhatsApp Style Group Info / Details Screen
                GroupInfoScreen(
                    group = active,
                    onBack = { showGroupInfo = false }
                )
            }
            active != null -> {
                // Screen 2: Dedicated Group Chat Screen (with bottom padding for MainActivity navigation bar)
                GroupChatScreen(
                    group = active,
                    messages = allMessages[active.id] ?: emptyList(),
                    onBack = {
                        activeChatGroup = null
                        viewModel.setChatOpen(false)
                    },
                    onOpenInfo = { showGroupInfo = true },
                    onSendMessage = { text -> viewModel.sendCommunityMessage(text) }
                )
            }
            else -> {
                // Screen 1: Communities List Screen
                CommunitiesListScreen(
                    groups = groups,
                    searchQuery = searchQuery,
                    filter = filter,
                    unreadAlerts = unreadAlerts,
                    onSearchChange = viewModel::setCommunitySearch,
                    onFilterChange = viewModel::setCommunityFilter,
                    onNotificationClick = { viewModel.setTab(UserTab.ALERTS) },
                    onSelectGroup = { group ->
                        viewModel.selectCommunityGroup(group.id)
                        activeChatGroup = group
                    }
                )
            }
        }
    }
}

@Composable
private fun CommunitiesListScreen(
    groups: List<CommunityGroup>,
    searchQuery: String,
    filter: CommunityFilter,
    unreadAlerts: Int,
    onSearchChange: (String) -> Unit,
    onFilterChange: (CommunityFilter) -> Unit,
    onNotificationClick: () -> Unit,
    onSelectGroup: (CommunityGroup) -> Unit,
) {
    val filteredGroups = groups.filter { g ->
        (searchQuery.isBlank() || g.name.contains(searchQuery, ignoreCase = true) || g.description.contains(searchQuery, ignoreCase = true)) &&
        when (filter) {
            CommunityFilter.ALL -> true
            CommunityFilter.JOINED -> g.unreadCount >= 0
            CommunityFilter.RECOMMENDED -> g.unreadCount == 0
        }
    }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(bottom = floatingBarClearance() + 4.dp)
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(top = 8.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.Top,
    ) {
        // Top Title + Notification Bell
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Communities", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                IconButton(onClick = onNotificationClick) {
                    BadgedBox(
                        badge = {
                            if (unreadAlerts > 0) {
                                Badge(containerColor = MaterialTheme.colorScheme.error) { Text("$unreadAlerts") }
                            }
                        }
                    ) {
                        Icon(painterResource(R.drawable.ic_bell), contentDescription = "Alerts", modifier = Modifier.size(24.dp))
                    }
                }
            }
        }

        // Search Bar
        item {
            Box(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    placeholder = { Text("Search Communities...") },
                    leadingIcon = { Icon(painterResource(R.drawable.ic_search), contentDescription = null, modifier = Modifier.size(20.dp)) },
                    singleLine = true,
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFFF7F7F9),
                        unfocusedContainerColor = Color(0xFFF7F7F9),
                        unfocusedBorderColor = Color(0xFFE0E0E0),
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }

        // Filter Pills
        item {
            Row(
                Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CommunityFilter.entries.forEach { f ->
                    FilterPill(label = f.label, selected = f == filter, onClick = { onFilterChange(f) })
                }
            }
        }

        // Community List Cards: PURE WHITE BACKGROUND, FULL WIDTH, NO PADDING, 0.5 DP BOTTOM BORDER
        items(filteredGroups, key = { it.id }) { group ->
            CommunityListItem(group = group, onClick = { onSelectGroup(group) })
        }

        // Recommended Section
        item {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Recommended Communities", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                RecommendedCommunityCard(
                    symbol = "🚕",
                    name = "Jaipur Accessible Auto Network",
                    sub = "118 members · 12 mutual connections",
                    onJoin = {}
                )
            }
        }
    }
}

@Composable
private fun CommunityListItem(group: CommunityGroup, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(Color.White)
            .clickable(onClick = onClick)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(contentAlignment = Alignment.BottomEnd) {
                GlyphBadge(group.symbol, size = 52)
                Box(
                    Modifier
                        .size(13.dp)
                        .clip(CircleShape)
                        .background(GreenDeep)
                )
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(group.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Icon(painterResource(R.drawable.ic_check), contentDescription = "Verified", tint = GreenDeep, modifier = Modifier.size(16.dp))
                }
                Text(
                    group.lastMessage.ifBlank { group.description },
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray,
                    maxLines = 1,
                )
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("20 min ago", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                if (group.unreadCount > 0) {
                    Box(
                        Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE8F1FF)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("${group.unreadCount}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF007AFF), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(0.5.dp)
                .background(Color(0xFFE5E5E5))
        )
    }
}

@Composable
private fun RecommendedCommunityCard(symbol: String, name: String, sub: String, onJoin: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = Color.White,
        border = hairlineBorder(),
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            GlyphBadge(symbol, size = 48)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(sub, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(
                    modifier = Modifier.size(36.dp).clip(CircleShape).clickable { },
                    shape = CircleShape,
                    color = Color(0xFFF2F2F7),
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(painterResource(R.drawable.ic_close), contentDescription = "Dismiss", modifier = Modifier.size(16.dp), tint = Color.Gray)
                    }
                }
                Surface(
                    modifier = Modifier.size(36.dp).clip(CircleShape).clickable(onClick = onJoin),
                    shape = CircleShape,
                    color = GreenDeep,
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(painterResource(R.drawable.ic_check), contentDescription = "Join", tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun GroupChatScreen(
    group: CommunityGroup,
    messages: List<ChatMessage>,
    onBack: () -> Unit,
    onOpenInfo: () -> Unit,
    onSendMessage: (String) -> Unit,
) {
    var textInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .navigationBarsPadding()
            .imePadding()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Chat Header Bar (Transparent background + Round white cards for icons of same size)
        Row(
            Modifier
                .fillMaxWidth()
                .background(Color.Transparent)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            // Left: Back Icon in Round White Card
            Surface(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onBack),
                shape = CircleShape,
                color = Color.White,
                border = hairlineBorder(),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        painter = painterResource(R.drawable.ic_back),
                        contentDescription = "Back",
                        modifier = Modifier.size(20.dp),
                        tint = MaterialTheme.colorScheme.onSurface,
                    )
                }
            }

            // Center: Group Name
            Text(
                text = group.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = MaterialTheme.colorScheme.onSurface,
            )

            // Right: More Options Icon in Round White Card
            Surface(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onOpenInfo),
                shape = CircleShape,
                color = Color.White,
                border = hairlineBorder(),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = "•••",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
        }

        // Messages Thread
        LazyColumn(
            Modifier.weight(1f),
            state = listState,
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("Today  18:00 PM", style = MaterialTheme.typography.labelSmall, color = Color.Gray, fontSize = 12.sp)
                }
            }

            items(messages, key = { it.id }) { msg ->
                ChatMessageBubble(msg)
            }
        }

        // Floating Bottom Message Composer Bar (with bottom inset padding)
        Surface(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            shape = RoundedCornerShape(30.dp),
            color = Color.White,
            border = hairlineBorder(),
            shadowElevation = 2.dp,
        ) {
            Row(
                Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedTextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    placeholder = { Text("Type a message...", color = Color.Gray, fontSize = 15.sp) },
                    singleLine = true,
                    shape = RoundedCornerShape(22.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                    ),
                    modifier = Modifier.weight(1f),
                )
                Text("📎", fontSize = 18.sp)
                Text("🎙️", fontSize = 18.sp)
                Button(
                    onClick = {
                        if (textInput.isNotBlank()) {
                            onSendMessage(textInput)
                            textInput = ""
                        }
                    },
                    shape = CircleShape,
                    modifier = Modifier.size(42.dp),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GreenDeep)
                ) {
                    Text("↑", style = MaterialTheme.typography.titleMedium, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun GroupInfoScreen(
    group: CommunityGroup,
    onBack: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxSize()
            .navigationBarsPadding()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top App Bar
        Row(
            Modifier
                .fillMaxWidth()
                .background(Color.Transparent)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Surface(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onBack),
                shape = CircleShape,
                color = Color.White,
                border = hairlineBorder(),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(painterResource(R.drawable.ic_back), contentDescription = "Back", modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurface)
                }
            }
            Text("Group Info", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.size(40.dp))
        }

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // Centered App / Community Logo Header (WhatsApp Style)
            item {
                Surface(
                    Modifier.fillMaxWidth(),
                    color = Color.White,
                    border = hairlineBorder(),
                ) {
                    Column(
                        Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        // Large Centered App Compass Logo
                        Box(
                            Modifier
                                .size(88.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                painterResource(R.drawable.ic_explore),
                                contentDescription = "App Logo",
                                tint = GreenDeep,
                                modifier = Modifier.size(48.dp),
                            )
                        }
                        Text(group.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text(
                            group.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.Gray,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                        Pill("${group.memberCount} Members · Verified Community")
                    }
                }
            }

            // WhatsApp Style Group Members Section
            item {
                Surface(
                    Modifier.fillMaxWidth(),
                    color = Color.White,
                    border = hairlineBorder(),
                ) {
                    Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("Group Members", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("${group.members.size} active", style = MaterialTheme.typography.labelMedium, color = Color.Gray)
                        }

                        group.members.forEach { member ->
                            MemberRowItem(member = member)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MemberRowItem(member: GroupMember) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Avatar(member.name, size = 44)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(member.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                if (member.isVerified) {
                    Icon(painterResource(R.drawable.ic_check), contentDescription = "Verified", tint = GreenDeep, modifier = Modifier.size(16.dp))
                }
            }
            Text(member.role, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        }
        if (member.isMe) {
            Pill("You")
        }
    }
}

@Composable
private fun ChatMessageBubble(msg: ChatMessage) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (msg.isMe) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Bottom,
    ) {
        if (msg.isMe) {
            // MY MESSAGES (Vibrant App Theme Green Bubble on Right)
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = GreenDeep,
            ) {
                Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        msg.text,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White,
                        fontSize = 15.sp,
                    )
                    Row(
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text(
                            msg.timestamp + "  ✓",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 11.sp,
                        )
                    }
                }
            }
        } else {
            // OTHER SENDER MESSAGES (White Bubble on Left + Sender Avatar & Name BELOW)
            Column(
                horizontalAlignment = Alignment.Start,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = Color.White,
                    border = hairlineBorder(),
                ) {
                    Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            msg.text,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFF1C1C1E),
                            fontSize = 15.sp,
                        )
                        Text(
                            msg.timestamp,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.Gray,
                            fontSize = 11.sp,
                        )
                    }
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(start = 4.dp)
                ) {
                    Avatar(msg.senderName, size = 22)
                    Text(
                        msg.senderName,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.DarkGray,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp,
                    )
                }
            }
        }
    }
}
