package com.app.raahi.app.presentation.globalcomponents

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.app.raahi.app.domain.model.Barrier
import com.app.raahi.app.domain.model.GeoPoint
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.sources.GeoJsonSource

private const val STYLE_JSON = """
{"version":8,
 "glyphs":"https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf",
 "sources":{"osm":{"type":"raster","tiles":["https://tile.openstreetmap.org/{z}/{x}/{y}.png"],"tileSize":256,"maxzoom":19,
   "attribution":"© OpenStreetMap contributors"}},
 "layers":[{"id":"osm","type":"raster","source":"osm"}]}
"""

private const val EMPTY = """{"type":"FeatureCollection","features":[]}"""

private fun lineJson(points: List<GeoPoint>): String =
    if (points.size < 2) EMPTY else
        """{"type":"Feature","properties":{},"geometry":{"type":"LineString","coordinates":[${
            points.joinToString(",") { "[${it.lon},${it.lat}]" }
        }]}}"""

private fun pinKey(b: Barrier) = "pin_${b.type.name}_${b.reporterName?.firstOrNull()?.uppercaseChar() ?: '?'}"

private fun barrierJson(list: List<Barrier>, selectedId: String?): String =
    if (list.isEmpty()) EMPTY else
        """{"type":"FeatureCollection","features":[${
            list.joinToString(",") { b ->
                val label = if (b.verified) "" else "AI ?"
                val size = if (b.id == selectedId) 1.3 else 1.0
                """{"type":"Feature","properties":{"id":"${b.id}","icon":"${pinKey(b)}","label":"$label","size":$size},
                   "geometry":{"type":"Point","coordinates":[${b.point.lon},${b.point.lat}]}}"""
            }
        }]}"""

/**
 * The Home-map pin: white round badge with the barrier icon, and a small brand-coloured avatar with the reporter's
 * initial at the bottom right. Drawn once per (type, initial) and registered as a map image.
 */
private fun pinBitmap(context: Context, glyph: String, initial: String?): Bitmap {
    val d = context.resources.displayMetrics.density
    val canvasSize = (64 * d).toInt()
    val bmp = Bitmap.createBitmap(canvasSize, canvasSize, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val center = canvasSize / 2f
    val radius = 22 * d
    val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = AndroidColor.WHITE
        setShadowLayer(5 * d, 0f, 2 * d, 0x55000000)
    }
    c.drawCircle(center, center, radius, fill)
    val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 22 * d; textAlign = Paint.Align.CENTER }
    c.drawText(glyph, center, center - (text.ascent() + text.descent()) / 2f, text)
    if (initial != null) {
        val ax = center + radius * 0.72f
        val ay = center + radius * 0.72f
        val ar = 9 * d
        c.drawCircle(ax, ay, ar + 2 * d, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = AndroidColor.WHITE })
        c.drawCircle(ax, ay, ar, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF248A3D.toInt() })
        val t = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = AndroidColor.WHITE; textSize = 11 * d; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD
        }
        c.drawText(initial, ax, ay - (t.ascent() + t.descent()) / 2f, t)
    }
    return bmp
}

/** Round letter badge for the From (A) and To (B) ends of the route. */
private fun endpointBitmap(context: Context, letter: String, color: Int): Bitmap {
    val d = context.resources.displayMetrics.density
    val size = (48 * d).toInt()
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val center = size / 2f
    c.drawCircle(center, center, 20 * d, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = AndroidColor.WHITE })
    c.drawCircle(center, center, 16 * d, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color })
    val t = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = AndroidColor.WHITE; textSize = 18 * d; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD
    }
    c.drawText(letter, center, center - (t.ascent() + t.descent()) / 2f, t)
    return bmp
}

private fun endpointsJson(origin: GeoPoint?, destination: GeoPoint?): String {
    val features = listOfNotNull(
        origin?.let { """{"type":"Feature","properties":{"icon":"end_A"},"geometry":{"type":"Point","coordinates":[${it.lon},${it.lat}]}}""" },
        destination?.let { """{"type":"Feature","properties":{"icon":"end_B"},"geometry":{"type":"Point","coordinates":[${it.lon},${it.lat}]}}""" },
    )
    return if (features.isEmpty()) EMPTY else """{"type":"FeatureCollection","features":[${features.joinToString(",")}]}"""
}

private fun pointJson(p: GeoPoint?): String =
    if (p == null) EMPTY else
        """{"type":"Feature","properties":{},"geometry":{"type":"Point","coordinates":[${p.lon},${p.lat}]}}"""

/**
 * One map for both roles. Normal route = dashed vermillion, safe route = solid blue, barriers = circle + text label.
 * Barrier detail is also available as a list under the map, because maps are weak for screen-reader users.
 */
@Composable
fun RaahiMap(
    modifier: Modifier = Modifier,
    description: String,
    baseline: List<GeoPoint> = emptyList(),
    safe: List<GeoPoint> = emptyList(),
    barriers: List<Barrier> = emptyList(),
    /** Start (A) and end (B) of the planned route. Drawn as lettered badges. */
    origin: GeoPoint? = null,
    destination: GeoPoint? = null,
    marker: GeoPoint? = null,
    /** When this changes to a non-null point the camera flies there (for example after "Use my GPS"). */
    focus: GeoPoint? = null,
    selectedBarrierId: String? = null,
    fitTo: List<GeoPoint> = emptyList(),
    /** Screen space covered by floating cards, so fitted pins and routes are not hidden behind them. */
    fitPaddingTop: Dp = 90.dp,
    fitPaddingBottom: Dp = 90.dp,
    onMapClick: ((GeoPoint) -> Unit)? = null,
    onBarrierClick: ((String) -> Unit)? = null,
) {
    val context = LocalContext.current
    val mapView = remember { MapLibre.getInstance(context); MapView(context) }
    var map by remember { mutableStateOf<MapLibreMap?>(null) }
    var style by remember { mutableStateOf<Style?>(null) }
    val clickMap by rememberUpdatedState(onMapClick)
    val clickBarrier by rememberUpdatedState(onBarrierClick)
    val density = LocalDensity.current
    val padTop by rememberUpdatedState(with(density) { fitPaddingTop.roundToPx() })
    val padBottom by rememberUpdatedState(with(density) { fitPaddingBottom.roundToPx() })
    val padSide = with(density) { 40.dp.roundToPx() }

    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle, mapView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_CREATE -> mapView.onCreate(null)
                Lifecycle.Event.ON_START -> mapView.onStart()
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                Lifecycle.Event.ON_STOP -> mapView.onStop()
                Lifecycle.Event.ON_DESTROY -> mapView.onDestroy()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        onDispose {
            lifecycle.removeObserver(observer)
            runCatching { mapView.onPause(); mapView.onStop(); mapView.onDestroy() }
        }
    }

    AndroidView(
        modifier = modifier.semantics { contentDescription = description },
        factory = {
            mapView.getMapAsync { m ->
                map = m
                m.cameraPosition = CameraPosition.Builder().target(LatLng(26.8438, 75.8072)).zoom(15.0).build()
                m.setStyle(Style.Builder().fromJson(STYLE_JSON)) { s ->
                    s.addSource(GeoJsonSource("baseline", EMPTY))
                    s.addSource(GeoJsonSource("safe", EMPTY))
                    s.addSource(GeoJsonSource("barriers", EMPTY))
                    s.addSource(GeoJsonSource("marker", EMPTY))
                    s.addSource(GeoJsonSource("endpoints", EMPTY))
                    s.addImage("end_A", endpointBitmap(context, "A", 0xFF248A3D.toInt()))
                    s.addImage("end_B", endpointBitmap(context, "B", 0xFF1C1C1E.toInt()))
                    s.addLayer(
                        LineLayer("baseline-line", "baseline").withProperties(
                            PropertyFactory.lineColor("#D55E00"), PropertyFactory.lineWidth(5f),
                            PropertyFactory.lineDasharray(arrayOf(2f, 2f)),
                            PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
                        )
                    )
                    s.addLayer(
                        LineLayer("safe-line", "safe").withProperties(
                            PropertyFactory.lineColor("#248A3D"), PropertyFactory.lineWidth(7f),
                            PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
                        )
                    )
                    s.addLayer(
                        SymbolLayer("endpoint-pin", "endpoints").withProperties(
                            PropertyFactory.iconImage(Expression.get("icon")),
                            PropertyFactory.iconAllowOverlap(true),
                            PropertyFactory.iconIgnorePlacement(true),
                        )
                    )
                    s.addLayer(
                        SymbolLayer("barrier-pin", "barriers").withProperties(
                            PropertyFactory.iconImage(Expression.get("icon")),
                            PropertyFactory.iconSize(Expression.get("size")),
                            PropertyFactory.iconAllowOverlap(true),
                            PropertyFactory.iconIgnorePlacement(true),
                        )
                    )
                    s.addLayer(
                        SymbolLayer("barrier-label", "barriers").withProperties(
                            PropertyFactory.textField(Expression.get("label")),
                            PropertyFactory.textFont(arrayOf("Open Sans Regular", "Arial Unicode MS Regular")),
                            PropertyFactory.textSize(12f),
                            PropertyFactory.textOffset(arrayOf(0f, 2.2f)),
                            PropertyFactory.textAllowOverlap(true),
                            PropertyFactory.textColor("#111111"),
                            PropertyFactory.textHaloColor("#FFFFFF"), PropertyFactory.textHaloWidth(2f),
                        )
                    )
                    s.addLayer(
                        CircleLayer("marker-circle", "marker").withProperties(
                            PropertyFactory.circleRadius(9f), PropertyFactory.circleColor("#248A3D"),
                            PropertyFactory.circleStrokeColor("#FFFFFF"), PropertyFactory.circleStrokeWidth(4f),
                        )
                    )
                    style = s
                }
                m.addOnMapClickListener { latLng ->
                    val hit = m.queryRenderedFeatures(m.projection.toScreenLocation(latLng), "barrier-pin").firstOrNull()
                    val barrierId = hit?.getStringProperty("id")
                    val onBarrier = clickBarrier
                    val onMap = clickMap
                    when {
                        barrierId != null && onBarrier != null -> { onBarrier(barrierId); true }
                        onMap != null -> { onMap(GeoPoint(latLng.latitude, latLng.longitude)); true }
                        else -> false
                    }
                }
            }
            mapView
        },
    )

    LaunchedEffect(style, baseline) { style?.getSourceAs<GeoJsonSource>("baseline")?.setGeoJson(lineJson(baseline)) }
    LaunchedEffect(style, safe) { style?.getSourceAs<GeoJsonSource>("safe")?.setGeoJson(lineJson(safe)) }
    LaunchedEffect(style, barriers, selectedBarrierId) {
        val s = style ?: return@LaunchedEffect
        barriers.forEach { b ->
            val key = pinKey(b)
            if (s.getImage(key) == null) {
                s.addImage(key, pinBitmap(context, b.type.symbol, b.reporterName?.firstOrNull()?.uppercase()))
            }
        }
        s.getSourceAs<GeoJsonSource>("barriers")?.setGeoJson(barrierJson(barriers, selectedBarrierId))
    }
    LaunchedEffect(style, origin, destination) {
        style?.getSourceAs<GeoJsonSource>("endpoints")?.setGeoJson(endpointsJson(origin, destination))
    }
    LaunchedEffect(style, marker) { style?.getSourceAs<GeoJsonSource>("marker")?.setGeoJson(pointJson(marker)) }
    LaunchedEffect(map, focus) {
        val m = map ?: return@LaunchedEffect
        if (focus != null) m.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(focus.lat, focus.lon), 17.0))
    }
    LaunchedEffect(map, fitTo) {
        val m = map ?: return@LaunchedEffect
        if (fitTo.size >= 2) {
            val bounds = LatLngBounds.Builder().includes(fitTo.map { LatLng(it.lat, it.lon) }).build()
            m.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, padSide, padTop, padSide, padBottom))
        } else if (fitTo.size == 1) {
            m.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(fitTo[0].lat, fitTo[0].lon), 17.0))
        }
    }
}
