package com.app.raahi.app.presentation.navigation

sealed class Screen(
    val route: String
) {
    data object Onboarding : Screen("onboarding")
    data object Login : Screen("login")
    data object UserHome : Screen("user_home")
    data object HelperHome : Screen("helper_home")

    object Graph {
        const val AUTH = "authGraph"
        const val USER = "userMainGraph"
        const val HELPER = "helperMainGraph"
    }
}
