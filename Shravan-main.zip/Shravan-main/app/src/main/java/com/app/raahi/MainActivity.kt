package com.app.raahi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.Modifier
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.navigation.compose.rememberNavController
import com.app.raahi.app.presentation.onboarding.SplashScreen
import com.app.raahi.app.presentation.navigation.AppNavHost
import com.app.raahi.app.presentation.navigation.Screen
import com.app.raahi.ui.theme.RaahiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RaahiTheme {
                val navController = rememberNavController()
                var showSplash by rememberSaveable { mutableStateOf(true) }

                // No Scaffold here: every screen handles its own system-bar insets, so the map can run edge to edge.
                Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                    AppNavHost(
                        navController = navController,
                        modifier = Modifier.fillMaxSize(),
                        startDestination = Screen.Graph.AUTH
                    )
                    if (showSplash) SplashScreen(onFinished = { showSplash = false })
                }
            }
        }
    }
}
