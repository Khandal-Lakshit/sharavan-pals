package com.app.raahi.app.presentation.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.app.raahi.app.presentation.globalcomponents.Pill
import com.app.raahi.app.presentation.globalcomponents.SetStatusBarDarkIcons
import kotlinx.coroutines.launch

private data class IntroPage(val emoji: String, val title: String, val body: String, val planned: Boolean)

private val pages = listOf(
    IntroPage("🗺️", "Routes that avoid barriers", "Shravan finds the footpath route with no steps, missing ramps or broken surfaces, and shows it next to the normal route.", false),
    IntroPage("🤝", "Helping Hands keep it fresh", "Helping Hands walk your route, photograph problems and confirm them. You get an alert and your route updates.", false),
    IntroPage("🆘", "SOS with your handling notes", "Hold one button and your contacts and the nearest hospital get your location and instructions on how to move you safely.", true),
    IntroPage("🗣️", "Voice, places, friends, booking", "Voice control, accessible cafes and hospitals, a friends and caretaker circle, and assistance booking.", true),
)

@Composable
fun OnboardingScreen(
    modifier: Modifier = Modifier,
    onToLogin: () -> Unit = {}
) {
    val state = rememberPagerState { pages.size }
    val scope = rememberCoroutineScope()
    val last = state.currentPage == pages.lastIndex

    SetStatusBarDarkIcons(darkIcons = !isSystemInDarkTheme())

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onToLogin, modifier = Modifier.heightIn(min = 48.dp)) {
                Text("Skip", style = MaterialTheme.typography.labelLarge)
            }
        }
        HorizontalPager(state = state, modifier = Modifier.weight(1f)) { index ->
            val page = pages[index]
            Column(
                Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Box(
                    Modifier.size(168.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center,
                ) { Text(page.emoji, fontSize = 72.sp) }
                Text(
                    page.title,
                    style = MaterialTheme.typography.headlineMedium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 32.dp),
                )
                Text(
                    page.body,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 12.dp),
                )
                if (page.planned) {
                    Pill(
                        "Planned - not live in this prototype",
                        modifier = Modifier.padding(top = 16.dp),
                        container = MaterialTheme.colorScheme.tertiaryContainer,
                        content = MaterialTheme.colorScheme.tertiary,
                    )
                }
            }
        }

        Row(
            Modifier.padding(vertical = 16.dp).semantics { contentDescription = "Page ${state.currentPage + 1} of ${pages.size}" },
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            pages.indices.forEach { i ->
                val selected = i == state.currentPage
                Box(
                    Modifier
                        .size(width = if (selected) 24.dp else 8.dp, height = 8.dp)
                        .clip(RoundedCornerShape(50))
                        .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                )
            }
        }

        Button(
            onClick = { if (last) onToLogin() else scope.launch { state.animateScrollToPage(state.currentPage + 1) } },
            modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
            shape = CircleShape,
        ) { Text(if (last) "Get started" else "Next", style = MaterialTheme.typography.titleSmall) }
    }
}
