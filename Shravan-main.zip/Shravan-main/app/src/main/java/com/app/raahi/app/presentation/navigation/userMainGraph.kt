package com.app.raahi.app.presentation.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import androidx.navigation.navigation
import com.app.raahi.app.presentation.user.UserHomeScreen
import com.app.raahi.app.viewmodels.authviewmodel.AuthViewModel
import com.app.raahi.app.viewmodels.routeviewmodel.RouteViewModel
import org.koin.androidx.compose.koinViewModel

fun NavGraphBuilder.userMainGraph(
    navController: NavHostController,
    modifier: Modifier,
    enter: (AnimatedContentTransitionScope<*>.() -> EnterTransition),
    exit: (AnimatedContentTransitionScope<*>.() -> ExitTransition),
    popEnter: (AnimatedContentTransitionScope<*>.() -> EnterTransition),
    popExit: (AnimatedContentTransitionScope<*>.() -> ExitTransition)
) {
    navigation(
        startDestination = Screen.UserHome.route,
        route = Screen.Graph.USER
    ) {
        composable(
            route = Screen.UserHome.route,
            enterTransition = enter,
            exitTransition = exit,
            popEnterTransition = popEnter,
            popExitTransition = popExit
        ) {
            val authViewModel: AuthViewModel = koinViewModel()
            val viewModel: RouteViewModel = koinViewModel()
            val user by authViewModel.user.collectAsStateWithLifecycle()

            // Logging out clears the session FluxDeck; once the user is gone, go back to the login screen.
            LaunchedEffect(user) {
                if (user == null) {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(Screen.Graph.USER) { inclusive = true }
                    }
                }
            }

            UserHomeScreen(
                modifier = modifier,
                viewModel = viewModel,
                onLogout = authViewModel::logout
            )
        }
    }
}
