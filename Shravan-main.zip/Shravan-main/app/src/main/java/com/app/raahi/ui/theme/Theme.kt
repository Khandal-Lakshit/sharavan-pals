package com.app.raahi.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = MessageGreen,
    onPrimary = Color.White,
    primaryContainer = GreenTint,
    onPrimaryContainer = GreenInk,
    secondary = GreenDeep,
    onSecondary = Color.White,
    secondaryContainer = GreenTint,
    onSecondaryContainer = GreenInk,
    tertiary = WarnVermillion,
    onTertiary = Color.White,
    tertiaryContainer = WarnContainer,
    onTertiaryContainer = Ink,
    background = GroupedBackground,
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink,
    surfaceVariant = Fill,
    onSurfaceVariant = InkSoft,
    outline = InkSoft,
    outlineVariant = Hairline,
    error = ErrorRed,
)

private val DarkColorScheme = darkColorScheme(
    primary = MessageGreen,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF123D20),
    onPrimaryContainer = DarkInk,
    secondary = GreenOnDark,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF123D20),
    onSecondaryContainer = DarkInk,
    tertiary = Color(0xFFFFA866),
    tertiaryContainer = Color(0xFF3A2514),
    onTertiaryContainer = DarkInk,
    background = DarkBackground,
    onBackground = DarkInk,
    surface = DarkSurface,
    onSurface = DarkInk,
    surfaceVariant = DarkFill,
    onSurfaceVariant = DarkInkSoft,
    outline = DarkInkSoft,
    outlineVariant = DarkHairline,
    error = Color(0xFFFF453A),
)

/** One corner scale for the whole app. small = chips inside cards, medium = buttons and fields, large = cards, extraLarge = floating panels. */
private val RaahiShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun RaahiTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme,
        typography = Typography,
        shapes = RaahiShapes,
        content = content,
    )
}
