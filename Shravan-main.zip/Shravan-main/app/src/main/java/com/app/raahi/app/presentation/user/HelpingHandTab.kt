package com.app.raahi.app.presentation.user

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.app.raahi.app.domain.model.BOOKING_MINUTES
import com.app.raahi.app.domain.model.BOOKING_SLOTS
import com.app.raahi.app.domain.model.BOOKING_TERMS
import com.app.raahi.app.domain.model.HELP_PRICE_PER_HOUR
import com.app.raahi.app.domain.model.helpPrice
import com.app.raahi.app.domain.model.durationLabel
import com.app.raahi.app.domain.model.Booking
import com.app.raahi.app.domain.model.HelpKind
import com.app.raahi.app.presentation.globalcomponents.Avatar
import com.app.raahi.app.presentation.globalcomponents.FilterPill
import com.app.raahi.app.presentation.globalcomponents.GlyphBadge
import com.app.raahi.app.presentation.globalcomponents.Pill
import com.app.raahi.app.presentation.globalcomponents.RaahiCard
import com.app.raahi.app.presentation.globalcomponents.floatingBarClearance
import com.app.raahi.app.viewmodels.routeviewmodel.RouteViewModel
import com.app.raahi.ui.theme.GreenDeep

/** Height of the floating booking card plus the gap under it. Screens reserve this much extra bottom space. */
val BookingBannerSpace = 76.dp

/**
 * Helping Hand: book a verified person (a driver or an NGO partner) to help with travel, errands, a visit or reading.
 * It is its own feature and has nothing to do with the places in Explore. Once booked, the tab shows the booking
 * instead of the form, and the same booking floats above the bottom bar on every tab.
 */
@Composable
fun HelpingHandTab(viewModel: RouteViewModel) {
    val active by viewModel.activeBooking.collectAsState()
    Column(
        Modifier.fillMaxSize().statusBarsPadding().imePadding()
            .verticalScroll(rememberScrollState())
            .padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = floatingBarClearance() + 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("Helping Hand", style = MaterialTheme.typography.headlineSmall)
            Text(
                "A verified person who helps you get around or get things done.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        val booking = active
        if (booking != null) {
            Text("Your booking", style = MaterialTheme.typography.titleMedium)
            RaahiCard(container = MaterialTheme.colorScheme.primaryContainer, borderColor = GreenDeep.copy(alpha = 0.4f)) {
                Column(Modifier.padding(16.dp)) { BookingDetails(booking, onCancel = { viewModel.cancelBooking(booking.id) }) }
            }
        } else {
            BookingForm(onBook = viewModel::bookHelper)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun BookingForm(onBook: (HelpKind, String, String, String, Int) -> Unit) {
    var kind by remember { mutableStateOf(HelpKind.TRAVEL) }
    var slot by remember { mutableStateOf(BOOKING_SLOTS.first()) }
    var minutes by remember { mutableStateOf(BOOKING_MINUTES[1]) }
    var destination by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    val currentPrice = helpPrice(kind, minutes)

    RaahiCard(container = MaterialTheme.colorScheme.primaryContainer, borderColor = GreenDeep.copy(alpha = 0.4f)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Your price", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("₹$currentPrice", style = MaterialTheme.typography.headlineMedium, color = GreenDeep)
            Text(
                "for ${durationLabel(minutes)} with a verified Helping Hand (${kind.label} @ ₹${kind.baseHourlyRate}/hr). You pay them directly when you are done.",
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }

    SectionLabel("What do you need help with?")
    HelpKind.entries.forEach { option ->
        ChoiceRow(
            selected = option == kind,
            onSelect = { kind = option },
            leading = { GlyphBadge(option.symbol, size = 40) },
            title = "${option.label} (₹${option.baseHourlyRate}/hr)",
            subtitle = option.blurb,
        )
    }
    RaahiCard {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("What you get", style = MaterialTheme.typography.titleSmall)
            Text(kind.detail, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    SectionLabel("Where are you going? (optional)")
    OutlinedTextField(
        value = destination,
        onValueChange = { destination = it },
        placeholder = { Text("A place, an address or a landmark") },
        singleLine = true,
        shape = MaterialTheme.shapes.medium,
        modifier = Modifier.fillMaxWidth(),
    )
    SectionLabel("When should they arrive?")
    BOOKING_SLOTS.forEach { option ->
        ChoiceRow(selected = option == slot, onSelect = { slot = option }, title = option)
    }
    SectionLabel("How long should they stay with you?")
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        BOOKING_MINUTES.forEach { m ->
            FilterPill("${durationLabel(m)} · ₹${helpPrice(kind, m)}", selected = m == minutes, onClick = { minutes = m })
        }
    }
    SectionLabel("Anything they should know? (optional)")
    OutlinedTextField(
        value = note,
        onValueChange = { note = it },
        placeholder = { Text("For example: I use a wheelchair") },
        shape = MaterialTheme.shapes.medium,
        minLines = 2,
        modifier = Modifier.fillMaxWidth(),
    )
    RaahiCard {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Good to know", style = MaterialTheme.typography.titleSmall)
            BOOKING_TERMS.forEach { line ->
                Text("•  $line", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
    Button(
        onClick = { onBook(kind, destination, slot, note, minutes) },
        modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
        shape = CircleShape,
    ) { Text("Book for ₹$currentPrice", style = MaterialTheme.typography.titleSmall) }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 6.dp))
}

@Composable
private fun ChoiceRow(
    selected: Boolean,
    onSelect: () -> Unit,
    title: String,
    subtitle: String? = null,
    leading: (@Composable () -> Unit)? = null,
) {
    Surface(
        modifier = Modifier.fillMaxWidth().clip(MaterialTheme.shapes.large)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onSelect),
        shape = MaterialTheme.shapes.large,
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(
            if (selected) 1.dp else 0.5.dp,
            if (selected) GreenDeep else MaterialTheme.colorScheme.outlineVariant,
        ),
    ) {
        Row(
            Modifier.heightIn(min = 56.dp).padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            leading?.invoke()
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall)
                subtitle?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            RadioButton(selected = selected, onClick = null)
        }
    }
}

/** What the booking says, used inside the tab and inside the bottom sheet. */
@Composable
fun BookingDetails(b: Booking, onCancel: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(b.helperName, size = 48)
            Column(Modifier.weight(1f)) {
                Text(b.helperName, style = MaterialTheme.typography.titleMedium)
                b.helperBadge?.let { Text("✓ $it", style = MaterialTheme.typography.bodySmall, color = GreenDeep) }
            }
            Pill("Confirmed")
        }
        DetailRow("Helping with", "${b.kind.symbol}  ${b.kind.label}")
        DetailRow("Meets you", b.slot)
        DetailRow("How long", durationLabel(b.minutes))
        DetailRow("Price", "₹${b.price}. Pay your Helping Hand by UPI or cash when you are done.")
        DetailRow("Going to", b.destination.ifBlank { "Not set. Tell them when they arrive." })
        if (b.note.isNotBlank()) DetailRow("Your note", b.note)
        OutlinedButton(
            onClick = onCancel,
            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
            shape = CircleShape,
        ) { Text("Cancel booking", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.error) }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}

/** The floating card above the bottom bar. Tap it to open the booking. */
@Composable
fun BookingBanner(b: Booking, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .shadow(8.dp, shape)
            .clip(shape)
            .background(MaterialTheme.colorScheme.primaryContainer)
            .border(0.5.dp, GreenDeep.copy(alpha = 0.4f), shape)
            .clickable(onClickLabel = "Show booking details", onClick = onClick)
            .heightIn(min = 64.dp)
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .semantics {
                contentDescription = "Helping Hand booked. ${b.helperName} meets you ${b.slot.replaceFirstChar { it.lowercase() }}."
            },
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(b.helperName, size = 40)
        Column(Modifier.weight(1f)) {
            Text("Helping Hand booked", style = MaterialTheme.typography.titleSmall)
            Text(
                "${b.helperName} · ${b.slot}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Text("›", style = MaterialTheme.typography.headlineSmall, color = GreenDeep)
    }
}

/** Content of the bottom sheet opened from the banner. */
@Composable
fun BookingSheetContent(b: Booking, onCancel: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().navigationBarsPadding().padding(start = 20.dp, end = 20.dp, bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Your Helping Hand", style = MaterialTheme.typography.headlineSmall)
        BookingDetails(b, onCancel)
    }
}
