package com.app.raahi.ui.theme

import androidx.compose.ui.graphics.Color

// One palette for the whole app: iOS Messages green on white. Change a value here and screens, pins, map lines,
// the bottom bar and the iOS app (RaahiTheme in ColorExtensions.swift) all follow.
//
// Rule of thumb: bright green = big fills and icons. Deep green = anything that is small text on white.
val MessageGreen = Color(0xFF34C759)   // primary: buttons, active tab, chips, highlights
val GreenDeep = Color(0xFF248A3D)      // green text, avatars, ticks, the barrier-free route line
val GreenTint = Color(0xFFD4F4DE)      // soft green background (unread alerts, selected tiles, preview cards): strong enough to read on F2F2F7 and on white
val GreenInk = Color(0xFF0B3D1A)       // text on GreenTint

val Ink = Color(0xFF111111)
val InkSoft = Color(0xFF6C6C70)        // secondary text
val GroupedBackground = Color(0xFFF2F2F7) // iOS systemGroupedBackground: the background of every screen
val Fill = Color(0xFFF2F2F7)           // inputs and chips sitting inside a white card
val Hairline = Color(0xFFC6C6C8)       // iOS separator: the 0.5 dp border of every card

// Warning / normal route: Okabe-Ito vermillion. Routes also differ by dash, so colour is never the only signal.
val WarnVermillion = Color(0xFFD55E00)
val WarnContainer = Color(0xFFFFF1E6)
val ErrorRed = Color(0xFFD70015)
val ConfidenceAmber = Color(0xFF946B00) // "Medium" route confidence (text label always accompanies it)

// Dark theme (Messages dark: black, charcoal cards, same green)
val DarkBackground = Color(0xFF000000)
val DarkSurface = Color(0xFF1C1C1E)
val DarkFill = Color(0xFF2C2C2E)
val DarkInk = Color(0xFFF2F2F7)
val DarkInkSoft = Color(0xFF98989F)
val DarkHairline = Color(0xFF38383A)
val GreenOnDark = Color(0xFF30D158)
