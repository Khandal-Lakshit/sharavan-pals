package com.app.raahi.app.di

import io.ktor.client.engine.HttpClientEngine
import io.ktor.client.engine.okhttp.OkHttp
import org.koin.dsl.module
import java.util.concurrent.TimeUnit

/** Android-only bindings. sharedModule needs exactly one platform piece: an HttpClientEngine. */
val appModule = module {
    single<HttpClientEngine> {
        OkHttp.create {
            // photo uploads over ngrok can take longer than OkHttp's 10 s default
            config {
                connectTimeout(15, TimeUnit.SECONDS)
                readTimeout(60, TimeUnit.SECONDS)
                writeTimeout(60, TimeUnit.SECONDS)
            }
        }
    }
}
