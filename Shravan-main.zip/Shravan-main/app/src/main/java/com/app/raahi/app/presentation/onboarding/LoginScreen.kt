package com.app.raahi.app.presentation.onboarding

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role as SemanticsRole
import com.app.raahi.R
import com.app.raahi.app.presentation.globalcomponents.Avatar
import com.app.raahi.app.presentation.globalcomponents.Pill
import com.app.raahi.app.presentation.globalcomponents.hairlineBorder
import com.app.raahi.ui.theme.GreenDeep
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.app.raahi.app.Events
import com.app.raahi.app.domain.model.Role
import com.app.raahi.app.presentation.globalcomponents.SetStatusBarDarkIcons
import com.app.raahi.app.viewmodels.authviewmodel.AuthViewModel
import com.app.raahi.core.presentation.util.ObserveAsEvents

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    modifier: Modifier = Modifier,
    viewModel: AuthViewModel,
    onToUserHome: () -> Unit = {},
    onToHelperHome: () -> Unit = {}
) {
    val context = LocalContext.current
    val loading by viewModel.isLoading.collectAsState()
    val user by viewModel.user.collectAsState()
    var chosen by remember { mutableStateOf<Role?>(null) }

    SetStatusBarDarkIcons(darkIcons = !isSystemInDarkTheme())

    ObserveAsEvents(viewModel.events) { event ->
        when (event) {
            is Events.Success -> Toast.makeText(context, event.message ?: "Done", Toast.LENGTH_SHORT).show()
            is Events.Error -> Toast.makeText(context, event.message ?: "Something went wrong", Toast.LENGTH_LONG).show()
            else -> {}
        }
    }

    // The role decides which main graph opens.
    LaunchedEffect(user) {
        val u = user ?: return@LaunchedEffect
        if (u.role == Role.USER) onToUserHome() else onToHelperHome()
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp),
    ) {
        Hero()

        Column(Modifier.padding(horizontal = 4.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Who is using Shravan?", style = MaterialTheme.typography.headlineSmall)
            RoleCard(
                glyph = "\u267F",
                title = "I need a barrier-free route",
                body = "See what is blocked nearby, plan a route around it and get alerts when it changes.",
                loading = loading && chosen == Role.USER,
                enabled = !loading,
                onClick = { chosen = Role.USER; viewModel.login(Role.USER) },
            )
            RoleCard(
                glyph = "\uD83E\uDD1D",
                title = "I am a verified Helping Hand",
                body = "Drivers and NGO partners report steps, broken paths and blocked ramps.",
                badge = "Verified drivers and NGOs only",
                loading = loading && chosen == Role.HELPER,
                enabled = !loading,
                onClick = { chosen = Role.HELPER; viewModel.login(Role.HELPER) },
            )
            Text(
                "Prototype: no password. You sign in as the demo user (Asha) or the demo Helping Hand (Shravan, a verified driver). In the real app only verified helpers can report.",
                style = MaterialTheme.typography.bodySmall.copy(lineHeight = 17.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
            )
        }
    }
}

/** Deep green card with the brand and a preview of what the map looks like. */
@Composable
private fun Hero() {
    Box(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 280.dp)
            .background(GreenDeep, MaterialTheme.shapes.extraLarge),
    ) {
        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier.size(56.dp).background(Color.White, CircleShape),
                contentAlignment = Alignment.Center,
            ) { Text("\uD83E\uDDED", style = MaterialTheme.typography.headlineSmall) }
            Box(Modifier.height(56.dp))
            Text("Shravan", style = MaterialTheme.typography.displaySmall, color = Color.White)
            Text(
                "Footpath routes that avoid steps, missing ramps and broken surfaces, kept up to date by people on the ground.",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.92f),
                modifier = Modifier.padding(end = 40.dp),
            )
        }
        PinPreview("\uD83E\uDE9C", "R", Modifier.align(Alignment.TopEnd).offset(x = (-24).dp, y = 20.dp))
        PinPreview("\u26D4", "M", Modifier.align(Alignment.TopEnd).offset(x = (-84).dp, y = 76.dp))
        PinPreview("\uD83D\uDCCD", "I", Modifier.align(Alignment.TopEnd).offset(x = (-16).dp, y = 132.dp))
    }
}

/** Same look as a Home-map pin: white round badge with the barrier icon and the reporter's initial. */
@Composable
private fun PinPreview(glyph: String, initial: String, modifier: Modifier = Modifier) {
    Box(modifier.size(56.dp)) {
        Surface(shape = CircleShape, color = Color.White, modifier = Modifier.size(48.dp)) {
            Box(contentAlignment = Alignment.Center) { Text(glyph, style = MaterialTheme.typography.titleLarge) }
        }
        Avatar(
            initial,
            modifier = Modifier.align(Alignment.BottomEnd).border(2.dp, Color.White, CircleShape),
            size = 22,
        )
    }
}

@Composable
private fun RoleCard(
    glyph: String,
    title: String,
    body: String,
    enabled: Boolean,
    loading: Boolean,
    onClick: () -> Unit,
    badge: String? = null,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.large)
            .clickable(enabled = enabled, role = SemanticsRole.Button, onClick = onClick)
            .semantics { contentDescription = "$title. $body" },
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = hairlineBorder(),
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(
                Modifier.size(56.dp).background(MaterialTheme.colorScheme.surfaceVariant, CircleShape),
                contentAlignment = Alignment.Center,
            ) { Text(glyph, style = MaterialTheme.typography.headlineSmall) }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, style = MaterialTheme.typography.titleSmall.copy(lineHeight = 21.sp))
                Text(
                    body,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp, lineHeight = 17.sp, letterSpacing = 0.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (badge != null) Pill(badge, modifier = Modifier.padding(top = 4.dp))
            }
            // The round arrow is the button: green circle, white arrow, spinner while signing in.
            Box(
                Modifier.size(44.dp).background(MaterialTheme.colorScheme.primary, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                if (loading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                else Icon(painterResource(R.drawable.ic_chevron), contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
            }
        }
    }
}
