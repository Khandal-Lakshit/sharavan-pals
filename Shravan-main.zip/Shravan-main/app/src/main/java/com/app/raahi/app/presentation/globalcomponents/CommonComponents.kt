package com.app.raahi.app.presentation.globalcomponents

import android.app.Activity
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import com.app.raahi.R
import com.app.raahi.ui.theme.GreenDeep
import com.app.raahi.ui.theme.MessageGreen
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.app.raahi.app.domain.model.Barrier
import com.app.raahi.app.domain.model.ConfidenceLevel
import com.app.raahi.app.domain.model.Place
import com.app.raahi.app.domain.model.RouteImagery
import com.app.raahi.ui.theme.ConfidenceAmber
import com.app.raahi.ui.theme.WarnVermillion
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

fun formatTime(iso: String): String = runCatching {
    OffsetDateTime.parse(iso).atZoneSameInstant(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("hh:mm a"))
}.getOrDefault("")

/** Configures status bar icon appearance (dark icons for light header backgrounds, light/white icons for dark headers). */
@Composable
fun SetStatusBarDarkIcons(darkIcons: Boolean) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = darkIcons
            }
        }
    }
}

/** iOS-style flat card edge: 0.5 dp separator colour, never a shadow. */
@Composable
fun hairlineBorder() = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant)

/** Flat container used everywhere: surface fill, 24 dp corners, 0.5 dp border, no shadow. */
@Composable
fun RaahiCard(
    modifier: Modifier = Modifier,
    container: Color = MaterialTheme.colorScheme.surface,
    borderColor: Color = MaterialTheme.colorScheme.outlineVariant,
    content: @Composable ColumnScope.() -> Unit,
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = container),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = BorderStroke(0.5.dp, borderColor),
        content = content,
    )
}

/** Parent text = Poppins (titles). Child text = Inter (body). Both come from the theme. */
@Composable
fun ScreenHeader(
    title: String,
    subtitle: String,
    actionLabel: String,
    onAction: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 12.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlyphBadge("🧭", size = 42)
            Column {
                Text(title, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onSurface)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        TextButton(onClick = onAction, modifier = Modifier.heightIn(min = 48.dp)) {
            Text(actionLabel, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = modifier.padding(top = 8.dp).semantics { contentDescription = text },
    )
}

/** Small rounded label, for statuses like NEW, Planned, Verified. */
@Composable
fun Pill(
    text: String,
    modifier: Modifier = Modifier,
    container: Color = MaterialTheme.colorScheme.primaryContainer,
    content: Color = MaterialTheme.colorScheme.secondary,
) {
    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(container)
            .padding(horizontal = 10.dp, vertical = 4.dp),
    ) {
        Text(text, style = MaterialTheme.typography.labelMedium, color = content)
    }
}

@Composable
fun PlannedTag() {
    Pill("Planned")
}

/** Round tinted badge that holds an emoji or a single glyph. */
@Composable
fun GlyphBadge(
    glyph: String,
    modifier: Modifier = Modifier,
    size: Int = 48,
    container: Color = MaterialTheme.colorScheme.primaryContainer,
) {
    Box(
        modifier.size(size.dp).clip(CircleShape).background(container),
        contentAlignment = Alignment.Center,
    ) {
        Text(glyph, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
fun PlaceDropdown(
    label: String,
    selected: Place?,
    places: List<Place>,
    onSelect: (Place) -> Unit,
    modifier: Modifier = Modifier,
) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        Column(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 52.dp)
                .clip(MaterialTheme.shapes.medium)
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .clickable { open = true }
                .padding(horizontal = 14.dp, vertical = 6.dp)
                .semantics { contentDescription = "$label: ${selected?.name ?: "not chosen"}. Double tap to change." },
            verticalArrangement = Arrangement.Center,
        ) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                selected?.name ?: "Choose a place",
                maxLines = 1,
                style = MaterialTheme.typography.titleSmall,
                color = if (selected == null) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
            )
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            places.forEach { p ->
                DropdownMenuItem(text = { Text(p.name, style = MaterialTheme.typography.bodyLarge) }, onClick = { onSelect(p); open = false })
            }
        }
    }
}

/** Icon + text + status line, so a barrier is understood without colour or without the map. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BarrierRow(barrier: Barrier, onClick: () -> Unit) {
    val status = reporterLine(barrier)
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .semantics { contentDescription = "${barrier.type.label}. $status. Double tap for details." },
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = hairlineBorder(),
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GlyphBadge(barrier.type.symbol, size = 40, container = MaterialTheme.colorScheme.tertiaryContainer)
            Column(Modifier.weight(1f)) {
                Text(barrier.type.label, style = MaterialTheme.typography.titleSmall)
                Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Pill(
                if (barrier.verified) "Verified" else "AI ?",
                container = if (barrier.verified) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.tertiaryContainer,
                content = if (barrier.verified) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.tertiary,
            )
        }
    }
}

@Composable
fun BarrierDialog(barrier: Barrier, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        shape = MaterialTheme.shapes.large,
        title = { Text("${barrier.type.symbol}  ${barrier.type.label}", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (barrier.imageUrl != null) {
                    AsyncImage(
                        model = barrier.imageUrl,
                        contentDescription = "Photo of the barrier: ${barrier.type.label}",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp).clip(MaterialTheme.shapes.medium),
                    )
                }
                Text(reporterLine(barrier), style = MaterialTheme.typography.bodyLarge)
                Text("Matched to footpath segment ${barrier.segmentId}.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                barrier.note?.takeIf { it.isNotBlank() }?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
            }
        },
        confirmButton = { TextButton(onClick = onClose, modifier = Modifier.heightIn(min = 48.dp)) { Text("Close", style = MaterialTheme.typography.labelLarge) } },
    )
}

/** Map legend swatch: the line style matches what is drawn on the map (solid blue = safe, dashed orange = normal). */
@Composable
fun RouteLegend(modifier: Modifier = Modifier) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
        LegendItem(GreenDeep, dashed = false, text = "Barrier-free")
        LegendItem(WarnVermillion, dashed = true, text = "Normal route")
    }
}

@Composable
private fun LegendItem(color: Color, dashed: Boolean, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Canvas(Modifier.size(width = 32.dp, height = 10.dp)) {
            drawLine(
                color = color,
                start = Offset(0f, size.height / 2),
                end = Offset(size.width, size.height / 2),
                strokeWidth = 6.dp.toPx(),
                cap = StrokeCap.Round,
                pathEffect = if (dashed) PathEffect.dashPathEffect(floatArrayOf(14f, 12f)) else null,
            )
        }
        Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** One of two side-by-side route summaries. */
@Composable
fun RouteStat(
    title: String,
    meters: Int,
    minutes: Int,
    barriers: Int,
    highlighted: Boolean,
    modifier: Modifier = Modifier,
    extra: String? = null,
    imagery: RouteImagery = RouteImagery.EMPTY,
) {
    Card(
        modifier = modifier.semantics {
            contentDescription = "$title: $meters metres, about $minutes minutes, $barriers barriers. " +
                "Confidence ${imagery.confidencePct} percent, ${imagery.noRecentCount} segments without recent imagery."
        },
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(
            containerColor = if (highlighted) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surfaceVariant,
            contentColor = if (highlighted) MaterialTheme.colorScheme.onSecondary else MaterialTheme.colorScheme.onSurface,
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = if (highlighted) null else hairlineBorder(),
    ) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Text("$meters m", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("about $minutes min", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.width(1.dp))
            Text(
                if (barriers == 0) "No barriers" else "$barriers barrier${if (barriers == 1) "" else "s"}",
                style = MaterialTheme.typography.titleSmall,
            )
            if (extra != null) Text(extra, style = MaterialTheme.typography.bodySmall)
            if (imagery.segmentCount > 0) {
                Text("${imagery.confidencePct}% sure", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 6.dp))
                Text(
                    if (imagery.noRecentCount == 0) "Imagery up to date"
                    else "${imagery.noRecentCount} of ${imagery.segmentCount} segments without recent imagery",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}


@Composable
private fun levelColor(level: ConfidenceLevel): Color = when (level) {
    ConfidenceLevel.HIGH -> MaterialTheme.colorScheme.secondary
    ConfidenceLevel.MEDIUM -> ConfidenceAmber
    ConfidenceLevel.LOW -> MaterialTheme.colorScheme.error
}

/**
 * "How sure are we?": one confidence score per route (from the age and coverage of street photos) and how many
 * segments have no recent imagery. Plain card, 0.5 dp border, no shadow. Words and numbers carry the meaning, colour only helps.
 */
@Composable
fun ConfidenceCard(barrierFree: RouteImagery, normal: RouteImagery, modifier: Modifier = Modifier) {
    RaahiCard(modifier) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("How sure are we?", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Score from how old and how complete the street photos are.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            ConfidenceRow("Barrier-free route", barrierFree)
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, thickness = 0.5.dp)
            ConfidenceRow("Normal route", normal)
            Text(
                "No recent imagery means no street photo, or one older than ${RouteImagery.RECENT_DAYS} days.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ConfidenceRow(title: String, imagery: RouteImagery) {
    val color = levelColor(imagery.level)
    val gaps = imagery.noRecentCount
    val gapText = when {
        imagery.segmentCount == 0 -> "No imagery information yet"
        gaps == 0 -> "All ${imagery.segmentCount} segments have recent imagery"
        gaps == 1 -> "1 of ${imagery.segmentCount} segments has no recent imagery"
        else -> "$gaps of ${imagery.segmentCount} segments have no recent imagery"
    }
    Column(
        Modifier.semantics(mergeDescendants = true) {
            contentDescription = "$title. Confidence ${imagery.confidencePct} percent, ${imagery.level.label}. $gapText."
        },
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
            Text("${imagery.confidencePct}%", style = MaterialTheme.typography.titleLarge, color = color)
            Box(Modifier.width(8.dp))
            Text(imagery.level.label, style = MaterialTheme.typography.labelLarge, color = color)
        }
        Box(Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant)) {
            Box(Modifier.fillMaxWidth(imagery.confidencePct / 100f).height(8.dp).clip(CircleShape).background(color))
        }
        Text(
            gapText,
            style = MaterialTheme.typography.bodyMedium,
            color = if (gaps > 0) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (imagery.recentCount > 0 || imagery.typicalAgeDays > 0) {
            Text(
                "Typical photo age: ${imagery.typicalAgeDays} days",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** One sentence that says who reported a barrier and how far to trust it. Used by rows, the dialog and the Home card. */
fun reporterLine(barrier: Barrier): String = when {
    barrier.reporterName != null && barrier.reporterBadge != null -> "Reported by ${barrier.reporterName} \u00B7 ${barrier.reporterBadge}"
    barrier.reporterName != null -> "Reported by ${barrier.reporterName}"
    barrier.verified -> "Verified by a Helping Hand"
    else -> "AI detected (${(barrier.confidence * 100).toInt()}% sure), not yet verified"
}

/** Round initial avatar. Helpers have no photos in the prototype, so the initial is the avatar everywhere. */
@Composable
fun Avatar(name: String, modifier: Modifier = Modifier, size: Int = 28) {
    Box(
        modifier.size(size.dp).clip(CircleShape).background(GreenDeep),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            name.firstOrNull()?.uppercase() ?: "?",
            style = MaterialTheme.typography.labelMedium,
            color = Color.White,
        )
    }
}

/** Avatar + name + tick + badge, the "who told me this" line. */
@Composable
fun ReporterLine(barrier: Barrier, modifier: Modifier = Modifier) {
    val name = barrier.reporterName
    val badge = barrier.reporterBadge
    Row(
        modifier.semantics(mergeDescendants = true) { contentDescription = reporterLine(barrier) },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (name != null) Avatar(name, size = 28)
        Column {
            Text(name ?: "AI suggestion", style = MaterialTheme.typography.titleSmall)
            if (badge != null) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(painterResource(R.drawable.ic_check), contentDescription = null, tint = GreenDeep, modifier = Modifier.size(14.dp))
                    Text(badge, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

/** Rounded filter chip used on the Home map. Selected = brand fill. */
@Composable
fun FilterPill(label: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.heightIn(min = 44.dp).selectable(selected = selected, role = Role.Tab, onClick = onClick),
        shape = RoundedCornerShape(50),
        color = if (selected) MessageGreen else MaterialTheme.colorScheme.surface,
        border = if (selected) null else hairlineBorder(),
    ) {
        Box(Modifier.padding(horizontal = 18.dp), contentAlignment = Alignment.Center) {
            Text(
                label,
                style = MaterialTheme.typography.labelLarge,
                color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}


/** 56 dp items + 8 dp padding top and bottom. */
private val FloatingBarHeight = 60.dp
/** Distance between the bar and the bottom system inset. Kept small on purpose. */
private val FloatingBarBottomGap = 4.dp
/** Distance between a card and the bar above which it floats. */
private val FloatingBarCardGap = 8.dp

class NavItem(val iconRes: Int, val label: String, val badge: Int = 0)

/** Space a screen must leave at the bottom so its content is not hidden behind the floating bar. */
@Composable
fun floatingBarClearance(): Dp = floatingBarTop() + LocalBannerSpace.current

/** Distance from the screen bottom to the top of the floating bar, plus a small gap. Floating cards sit here. */
@Composable
fun floatingBarTop(): Dp = FloatingBarHeight + FloatingBarBottomGap + FloatingBarCardGap +
    WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

/** Extra bottom space reserved while a floating booking card sits above the bar, so no screen hides content behind it. */
val LocalBannerSpace = compositionLocalOf { 0.dp }

/**
 * Floating pill bar. Deep green card, white icons; the active item sits in a white circle with a green icon.
 * Icon-only, so every item carries a screen-reader label.
 */
@Composable
fun FloatingNavBar(
    items: List<NavItem>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.navigationBarsPadding().padding(bottom = FloatingBarBottomGap),
        shape = RoundedCornerShape(50),
        color = GreenDeep,
    ) {
        Row(Modifier.padding(6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            items.forEachIndexed { index, item ->
                val selected = index == selectedIndex
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(if (selected) Color.White else Color.Transparent)
                        .selectable(selected = selected, role = Role.Tab, onClick = { onSelect(index) })
                        .semantics {
                            contentDescription = item.label + if (item.badge > 0) ", ${item.badge} unread" else ""
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    BadgedBox(badge = { if (item.badge > 0) Badge { Text("${item.badge}") } }) {
                        Icon(painterResource(item.iconRes), contentDescription = null, tint = if (selected) GreenDeep else Color.White, modifier = Modifier.size(24.dp))
                    }
                }
            }
        }
    }
}
