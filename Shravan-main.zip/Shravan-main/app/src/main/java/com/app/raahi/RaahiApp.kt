package com.app.raahi

import android.app.Application
import com.app.raahi.app.di.appModule
import com.app.raahi.app.di.sharedModule
import com.app.raahi.core.data.networking.BaseUrl
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.startKoin
import timber.log.Timber

class RaahiApp : Application() {
    override fun onCreate() {
        super.onCreate()
        BaseUrl.value = BuildConfig.BASE_URL
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
        startKoin {
            androidContext(this@RaahiApp)
            androidLogger()
            modules(sharedModule, appModule)
        }
    }
}
