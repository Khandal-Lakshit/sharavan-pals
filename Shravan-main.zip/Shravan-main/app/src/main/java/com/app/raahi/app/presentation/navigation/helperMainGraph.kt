package com.app.raahi.app.presentation.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import androidx.navigation.navigation
import com.app.raahi.app.presentation.helper.HelperHomeScreen
import com.app.raahi.app.viewmodels.authviewmodel.AuthViewModel
import com.app.raahi.app.viewmodels.helperviewmodel.HelperViewModel
import org.koin.androidx.compose.koinViewModel

fun NavGraphBuilder.helperMainGraph(
    navController: NavHostController,
    modifier: Modifier,
    enter: (AnimatedContentTransitionScope<*>.() -> EnterTransition),
    exit: (AnimatedContentTransitionScope<*>.() -> ExitTransition),
    popEnter: (AnimatedContentTransitionScope<*>.() -> EnterTransition),
    popExit: (AnimatedContentTransitionScope<*>.() -> ExitTransition)
) {
    navigation(
        startDestination = Screen.HelperHome.route,
        route = Screen.Graph.HELPER
    ) {
        composable(
            route = Screen.HelperHome.route,
            enterTransition = enter,
            exitTransition = exit,
            popEnterTransition = popEnter,
            popExitTransition = popExit
        ) {
            val authViewModel: AuthViewModel = koinViewModel()
            val viewModel: HelperViewModel = koinViewModel()
            val user by authViewModel.user.collectAsStateWithLifecycle()

            // Logging out clears the session FluxDeck; once the user is gone, go back to the login screen.
            LaunchedEffect(user) {
                if (user == null) {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(Screen.Graph.HELPER) { inclusive = true }
                    }
                }
            }

            HelperHomeScreen(
                modifier = modifier,
                viewModel = viewModel,
                onLogout = authViewModel::logout
            )
        }
    }
}
