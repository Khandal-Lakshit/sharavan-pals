package com.app.raahi.app.presentation.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.app.raahi.R
import com.app.raahi.app.presentation.globalcomponents.Avatar
import com.app.raahi.app.presentation.globalcomponents.GlyphBadge
import com.app.raahi.app.presentation.globalcomponents.Pill
import com.app.raahi.app.presentation.globalcomponents.RaahiCard
import com.app.raahi.ui.theme.GreenDeep

@Composable
fun UserProfileContent(
    userName: String,
    city: String,
    onLogout: () -> Unit,
    onDismiss: () -> Unit,
) {
    val name = userName.ifBlank { "Asha" }
    Column(
        Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        // Top Header
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("User Profile", style = MaterialTheme.typography.headlineSmall)
            Pill("Active User", container = MaterialTheme.colorScheme.primaryContainer)
        }

        // Profile Card
        RaahiCard(container = MaterialTheme.colorScheme.primaryContainer, borderColor = GreenDeep.copy(alpha = 0.3f)) {
            Row(
                Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Avatar(name, size = 64)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(name, style = MaterialTheme.typography.titleLarge)
                    Text("📍 ${city.ifBlank { "Jaipur, Rajasthan" }}", style = MaterialTheme.typography.bodyMedium, color = GreenDeep)
                    Text("Shravan Traveler · ID #SHR-USR-2026", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        // Mobility & Handling Info
        Text("Accessibility & Handling Details", style = MaterialTheme.typography.titleMedium)
        RaahiCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ProfileDetailRow("Mobility Aid", "👩‍🦽 Power Wheelchair (Heavy Battery)")
                ProfileDetailRow("Handling Instruction", "Do not lift under the arms. Speak clearly before touching or moving.")
                ProfileDetailRow("Emergency Contact", "📞 +91 98290 12345 (Family)")
                ProfileDetailRow("Hospital Preference", "🏥 EHCC Hospital, Malviya Nagar, Jaipur")
            }
        }

        // Stats Summary
        Text("Your Shravan Summary", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatBox("8", "Safe Trips", Modifier.weight(1f))
            StatBox("3", "Helpers Booked", Modifier.weight(1f))
            StatBox("2", "Groups Joined", Modifier.weight(1f))
        }

        // Action Buttons
        OutlinedButton(
            onClick = onLogout,
            modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
            shape = CircleShape,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
        ) {
            Text("Log out", style = MaterialTheme.typography.titleSmall)
        }
    }
}

@Composable
fun HelperProfileContent(
    userName: String,
    userBadge: String,
    onLogout: () -> Unit,
    onDismiss: () -> Unit,
) {
    val name = userName.ifBlank { "Ravi Driver" }
    val badge = userBadge.ifBlank { "Verified NGO Partner Driver" }

    Column(
        Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Helper Profile", style = MaterialTheme.typography.headlineSmall)
            Pill("✓ Verified Helper", container = MaterialTheme.colorScheme.secondaryContainer, content = MaterialTheme.colorScheme.secondary)
        }

        // Profile Card
        RaahiCard(container = MaterialTheme.colorScheme.secondaryContainer, borderColor = GreenDeep.copy(alpha = 0.3f)) {
            Row(
                Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Avatar(name, size = 64)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(name, style = MaterialTheme.typography.titleLarge)
                    Text("✓ $badge", style = MaterialTheme.typography.bodyMedium, color = GreenDeep)
                    Text("ID #SHR-HELPER-8492 · Jaipur Zone", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        // Verification & Badges
        Text("Helper Verification Details", style = MaterialTheme.typography.titleMedium)
        RaahiCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ProfileDetailRow("Aadhaar & Driving License", "✅ Verified & Background Checked")
                ProfileDetailRow("Rating & Reviews", "⭐ 4.9 / 5.0 (28 ratings)")
                ProfileDetailRow("Primary Speciality", "Ramp Verification, Wheelchair Transport Assistance")
                ProfileDetailRow("Operating City", "📍 Jaipur (Jawahar Circle, Malviya Nagar, C-Scheme)")
            }
        }

        // Helper Stats
        Text("Verification Stats", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatBox("18", "Barriers Verified", Modifier.weight(1f))
            StatBox("12", "Routes Checked", Modifier.weight(1f))
            StatBox("4.9 ★", "User Rating", Modifier.weight(1f))
        }

        // Logout
        OutlinedButton(
            onClick = onLogout,
            modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
            shape = CircleShape,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
        ) {
            Text("Log out", style = MaterialTheme.typography.titleSmall)
        }
    }
}

@Composable
private fun ProfileDetailRow(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun StatBox(number: String, label: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
    ) {
        Column(
            Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text(number, style = MaterialTheme.typography.headlineSmall, color = GreenDeep)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
