package com.app.raahi.app.presentation.user

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.app.raahi.app.presentation.profile.UserProfileContent
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.app.raahi.R
import com.app.raahi.app.domain.model.Barrier
import com.app.raahi.app.presentation.globalcomponents.Avatar
import com.app.raahi.app.presentation.globalcomponents.FilterPill
import com.app.raahi.app.presentation.globalcomponents.PlaceDropdown
import com.app.raahi.app.presentation.globalcomponents.RaahiMap
import com.app.raahi.app.presentation.globalcomponents.ReporterLine
import com.app.raahi.app.presentation.globalcomponents.floatingBarClearance
import com.app.raahi.app.presentation.globalcomponents.hairlineBorder
import com.app.raahi.app.viewmodels.routeviewmodel.HomeFilter
import com.app.raahi.app.viewmodels.routeviewmodel.RouteViewModel
import com.app.raahi.ui.theme.GreenDeep

/**
 * The whole user experience on one map: pins for every verified report, the route search on top, and one card at the
 * bottom that is either the selected pin, the planned route, or a summary. Search shrinks to "From -> To" once a route
 * exists.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeTab(viewModel: RouteViewModel, onLogout: () -> Unit) {
    val barriers by viewModel.homeBarriers.collectAsState()
    val filter by viewModel.homeFilter.collectAsState()
    val selected by viewModel.selectedBarrier.collectAsState()
    val userName by viewModel.userName.collectAsState()
    val city by viewModel.cityName.collectAsState()
    val plan by viewModel.plan.collectAsState()
    val fit by viewModel.mapFit.collectAsState()
    val collapsed by viewModel.searchCollapsed.collectAsState()

    var showProfile by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        RaahiMap(
            modifier = Modifier.fillMaxSize(),
            description = "Map of reported barriers and your route. ${barriers.size} pins. Barriers are also listed in the card at the bottom.",
            baseline = plan?.baseline?.polyline.orEmpty(),
            safe = plan?.safe?.polyline.orEmpty(),
            barriers = barriers,
            origin = plan?.baseline?.polyline?.firstOrNull(),
            destination = plan?.baseline?.polyline?.lastOrNull(),
            selectedBarrierId = selected?.id,
            fitTo = fit,
            fitPaddingTop = if (plan != null) 200.dp else if (collapsed) 230.dp else 330.dp,
            fitPaddingBottom = if (plan != null) (LocalConfiguration.current.screenHeightDp * 0.34f).dp + 32.dp else 270.dp,
            onBarrierClick = viewModel::selectBarrier,
            onMapClick = { viewModel.selectBarrier(null) },
        )

        Column(Modifier.statusBarsPadding().padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            BrandRow(userName, onOpenProfile = { showProfile = true }, onLogout = onLogout)
            if (collapsed) CollapsedSearch(viewModel) else ExpandedSearch(viewModel)
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(HomeFilter.entries.toList(), key = { it.name }) { f ->
                    FilterPill(f.label, selected = f == filter, onClick = { viewModel.setHomeFilter(f) })
                }
            }
        }

        Surface(
            modifier = Modifier.align(Alignment.BottomCenter)
                .padding(start = 16.dp, end = 16.dp, bottom = floatingBarClearance())
                .fillMaxWidth(),
            shape = MaterialTheme.shapes.extraLarge,
            color = MaterialTheme.colorScheme.surface,
            border = hairlineBorder(),
        ) {
            val b = selected
            when {
                b != null -> BarrierCard(b, onClose = { viewModel.selectBarrier(null) })
                plan != null && collapsed -> RoutePanel(viewModel)   // hidden while the user edits From / To
                else -> SummaryCard(barriers, userName, city)
            }
        }

        if (showProfile) {
            ModalBottomSheet(
                onDismissRequest = { showProfile = false },
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
                containerColor = MaterialTheme.colorScheme.surface,
            ) {
                UserProfileContent(
                    userName = userName,
                    city = city,
                    onLogout = { showProfile = false; onLogout() },
                    onDismiss = { showProfile = false },
                )
            }
        }
    }
}

@Composable
private fun BrandRow(userName: String, onOpenProfile: () -> Unit, onLogout: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surface, border = hairlineBorder()) {
            Row(
                Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Icon(
                    painterResource(R.drawable.ic_explore),
                    contentDescription = null,
                    tint = GreenDeep,
                    modifier = Modifier.size(18.dp),
                )
                Text(
                    "Shravan",
                    style = MaterialTheme.typography.titleMedium,
                    color = GreenDeep,
                )
            }
        }
        Box(Modifier.weight(1f))
        Surface(
            shape = RoundedCornerShape(50),
            color = MaterialTheme.colorScheme.surface,
            border = hairlineBorder(),
            modifier = Modifier.heightIn(min = 44.dp).clip(RoundedCornerShape(50)).clickable(onClick = onOpenProfile),
        ) {
            Row(
                Modifier.padding(start = 6.dp, end = 14.dp).heightIn(min = 44.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Avatar(userName.ifBlank { "A" }, size = 30)
                Text(userName.ifBlank { "Profile" }, style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

@Composable
private fun ExpandedSearch(viewModel: RouteViewModel) {
    val places by viewModel.places.collectAsState()
    val origin by viewModel.origin.collectAsState()
    val destination by viewModel.destination.collectAsState()
    val planning by viewModel.isPlanning.collectAsState()
    val canPlan by viewModel.canPlan.collectAsState()

    Surface(
        modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().animateContentSize(),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = hairlineBorder(),
    ) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            PlaceDropdown("From", origin, places, viewModel::chooseOrigin)
            PlaceDropdown("To", destination, places, viewModel::chooseDestination)
            Button(
                onClick = viewModel::findRoute,
                enabled = canPlan && !planning,
                modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp),
                shape = CircleShape,
            ) {
                if (planning) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                else Text("Find barrier-free route", style = MaterialTheme.typography.titleSmall)
            }
        }
    }
}

/** After a search: just "From ... To ..." and an edit icon. */
@Composable
private fun CollapsedSearch(viewModel: RouteViewModel) {
    val origin by viewModel.origin.collectAsState()
    val destination by viewModel.destination.collectAsState()
    val from = origin?.name.orEmpty()
    val to = destination?.name.orEmpty()

    Surface(
        modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().animateContentSize()
            .clip(MaterialTheme.shapes.large)
            .clickable(onClick = viewModel::editSearch)
            .semantics { contentDescription = "Route from $from to $to. Double tap to edit." },
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = hairlineBorder(),
    ) {
        Row(Modifier.padding(start = 18.dp, end = 8.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                EndpointLine("From", from)
                EndpointLine("To", to)
            }
            Box(
                Modifier.size(48.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center,
            ) {
                Icon(painterResource(R.drawable.ic_edit), contentDescription = null, modifier = Modifier.size(20.dp))
            }
        }
    }
}

@Composable
private fun EndpointLine(label: String, name: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(width = 36.dp, height = 20.dp))
        Text(name, style = MaterialTheme.typography.titleSmall, maxLines = 1)
    }
}

@Composable
private fun SummaryCard(barriers: List<Barrier>, userName: String, city: String) {
    val reporters = barriers.mapNotNull { it.reporterName }.distinct()
    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (city.isNotBlank()) {
            Text("\uD83D\uDCCD $city", style = MaterialTheme.typography.labelLarge, color = GreenDeep)
        }
        Text(
            if (userName.isBlank()) "Around you" else "Around you, $userName",
            style = MaterialTheme.typography.titleMedium,
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy((-8).dp)) {
                reporters.take(3).forEach { name -> Avatar(name, size = 24) }
            }
            Text(
                when {
                    barriers.isEmpty() -> "No reports for this filter"
                    reporters.isEmpty() -> "${barriers.size} reports"
                    else -> "${barriers.size} reports by ${reporters.take(2).joinToString(" and ")}" +
                        if (reporters.size > 2) " and ${reporters.size - 2} more" else ""
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Text(
            "Tap a pin to see who reported it. Choose From and To above for a route that avoids them.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/** Selected pin. Round-one reports have no photos, so tinted tiles with the barrier icon stand in until imageUrl is set. */
@Composable
private fun BarrierCard(barrier: Barrier, onClose: () -> Unit) {
    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            repeat(3) { i ->
                val tile = Modifier.weight(1f).heightIn(min = 56.dp).clip(MaterialTheme.shapes.medium)
                if (i == 0 && barrier.imageUrl != null) {
                    AsyncImage(
                        model = barrier.imageUrl,
                        contentDescription = "Photo of the barrier: ${barrier.type.label}",
                        contentScale = ContentScale.Crop,
                        modifier = tile,
                    )
                } else {
                    Box(
                        tile.background(
                            if (i == 0) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                        ),
                        contentAlignment = Alignment.Center,
                    ) { Text(if (i == 0) barrier.type.symbol else "", style = MaterialTheme.typography.headlineMedium) }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(barrier.type.label, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f, fill = false))
            if (barrier.verified) {
                Icon(
                    painterResource(R.drawable.ic_check),
                    contentDescription = "Verified report",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp).background(GreenDeep, CircleShape).padding(3.dp),
                )
            }
            Box(Modifier.weight(1f))
            Box(
                Modifier.size(48.dp).clip(CircleShape).clickable(role = Role.Button, onClick = onClose),
                contentAlignment = Alignment.Center,
            ) {
                Icon(painterResource(R.drawable.ic_close), contentDescription = "Close", modifier = Modifier.size(20.dp))
            }
        }
        barrier.note?.takeIf { it.isNotBlank() }?.let {
            Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        ReporterLine(barrier)
    }
}
