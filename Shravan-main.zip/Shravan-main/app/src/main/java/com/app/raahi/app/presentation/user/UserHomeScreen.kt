package com.app.raahi.app.presentation.user

import android.widget.Toast
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.background
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.app.raahi.R
import com.app.raahi.app.Events
import com.app.raahi.app.domain.model.AlertType
import com.app.raahi.app.presentation.globalcomponents.FloatingNavBar
import com.app.raahi.app.presentation.globalcomponents.GlyphBadge
import com.app.raahi.app.presentation.globalcomponents.NavItem
import com.app.raahi.app.presentation.globalcomponents.Pill
import com.app.raahi.app.presentation.globalcomponents.RaahiCard
import com.app.raahi.app.presentation.globalcomponents.SetStatusBarDarkIcons
import com.app.raahi.app.presentation.globalcomponents.LocalBannerSpace
import com.app.raahi.app.presentation.globalcomponents.floatingBarClearance
import com.app.raahi.app.presentation.globalcomponents.floatingBarTop
import com.app.raahi.ui.theme.MessageGreen
import com.app.raahi.app.presentation.globalcomponents.formatTime
import com.app.raahi.app.presentation.planned.PlannedFeaturesScreen
import com.app.raahi.app.viewmodels.routeviewmodel.RouteViewModel
import com.app.raahi.app.viewmodels.routeviewmodel.UserTab
import com.app.raahi.core.presentation.util.ObserveAsEvents

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserHomeScreen(
    modifier: Modifier = Modifier,
    viewModel: RouteViewModel,
    onLogout: () -> Unit = {}
) {
    val context = LocalContext.current
    val tab by viewModel.tab.collectAsState()
    val unread by viewModel.unreadCount.collectAsState()

    // The Home map is light in both themes; the other tabs follow the theme background.
    SetStatusBarDarkIcons(darkIcons = tab == UserTab.HOME || !isSystemInDarkTheme())

    ObserveAsEvents(viewModel.events) { event ->
        when (event) {
            is Events.Success -> Toast.makeText(context, event.message ?: "Done", Toast.LENGTH_SHORT).show()
            is Events.Error -> Toast.makeText(context, event.message ?: "Something went wrong", Toast.LENGTH_LONG).show()
            else -> {}
        }
    }

    val tabs = listOf(UserTab.HOME, UserTab.EXPLORE, UserTab.COMMUNITY, UserTab.HELP, UserTab.ALERTS, UserTab.PLANNED)
    val items = listOf(
        NavItem(R.drawable.ic_home, "Home"),
        NavItem(R.drawable.ic_explore, "Explore places"),
        NavItem(R.drawable.ic_chat, "Community"),
        NavItem(R.drawable.ic_helping_hand, "Helping Hand"),
        NavItem(R.drawable.ic_bell, "Alerts", unread),
        NavItem(R.drawable.ic_info, "Coming next"),
    )

    val booking by viewModel.activeBooking.collectAsState()
    val isChatOpen by viewModel.isChatOpen.collectAsState()
    var showBooking by rememberSaveable { mutableStateOf(false) }

    // Every tab leaves room for the floating booking card while there is one
    CompositionLocalProvider(LocalBannerSpace provides if (booking != null) BookingBannerSpace else 0.dp) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            when (tab) {
                UserTab.HOME -> HomeTab(viewModel, onLogout)
                UserTab.EXPLORE -> ExploreTab(viewModel)
                UserTab.COMMUNITY -> CommunityTab(viewModel)
                UserTab.HELP -> HelpingHandTab(viewModel)
                UserTab.ALERTS -> AlertsTab(viewModel)
                UserTab.PLANNED -> PlannedFeaturesScreen(Modifier.fillMaxSize())
            }
            booking?.let { b ->
                BookingBanner(
                    b,
                    onClick = { showBooking = true },
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = floatingBarTop()),
                )
            }
            if (!isChatOpen || tab != UserTab.COMMUNITY) {
                FloatingNavBar(
                    items = items,
                    selectedIndex = tabs.indexOf(tab),
                    onSelect = { viewModel.setTab(tabs[it]) },
                    modifier = Modifier.align(Alignment.BottomCenter),
                )
            }
        }
    }

    booking?.takeIf { showBooking }?.let { b ->
        ModalBottomSheet(
            onDismissRequest = { showBooking = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surface,
        ) {
            BookingSheetContent(b, onCancel = { showBooking = false; viewModel.cancelBooking(b.id) })
        }
    }
}

@Composable
private fun AlertsTab(viewModel: RouteViewModel) {
    val list by viewModel.alerts.collectAsState()
    if (list.isEmpty()) {
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(start = 20.dp, end = 20.dp, top = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Alerts", style = MaterialTheme.typography.headlineSmall)
            Text("No alerts yet", style = MaterialTheme.typography.titleMedium)
            Text(
                "When a Helping Hand reports a problem on your route, or finishes checking it, it shows up here.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        return
    }
    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = floatingBarClearance() + 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { Text("Alerts", style = MaterialTheme.typography.headlineSmall) }
        items(list, key = { it.id }) { n -> AlertCard(n, onShowOnMap = viewModel::showOnMap) }
    }
}
