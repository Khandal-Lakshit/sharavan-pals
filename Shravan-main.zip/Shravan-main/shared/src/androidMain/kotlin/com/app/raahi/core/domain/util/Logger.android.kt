package com.app.raahi.core.domain.util

import android.util.Log

actual fun logError(message: String, throwable: Throwable?) {
    Log.e("Raahi", message, throwable)
}

actual fun logDebug(message: String) {
    Log.d("Raahi", message)
}
