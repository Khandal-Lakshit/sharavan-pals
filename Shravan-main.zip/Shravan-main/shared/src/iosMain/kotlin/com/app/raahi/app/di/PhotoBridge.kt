package com.app.raahi.app.di

import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi

/** Swift sends the compressed JPEG as base64, Kotlin turns it back into the ByteArray the ViewModel expects. */
@OptIn(ExperimentalEncodingApi::class)
fun photoFromBase64(value: String): ByteArray = Base64.decode(value)
