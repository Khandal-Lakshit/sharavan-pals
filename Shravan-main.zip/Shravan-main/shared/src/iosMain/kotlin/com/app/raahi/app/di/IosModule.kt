package com.app.raahi.app.di

import io.ktor.client.engine.HttpClientEngine
import io.ktor.client.engine.darwin.Darwin
import org.koin.dsl.module

val iosModule = module {
    single<HttpClientEngine> { Darwin.create() }
}
