package com.app.raahi.app.di

import com.app.raahi.app.domain.model.BOOKING_MINUTES
import com.app.raahi.app.domain.model.BOOKING_SLOTS
import com.app.raahi.app.domain.model.BOOKING_TERMS
import com.app.raahi.app.domain.model.HELP_PRICE_PER_HOUR
import com.app.raahi.app.domain.model.REVIEWER_NEEDS
import com.app.raahi.app.domain.model.VERIFICATION_TOPICS
import com.app.raahi.app.domain.model.BarrierType
import com.app.raahi.app.domain.model.HelpKind
import com.app.raahi.app.viewmodels.authviewmodel.AuthViewModel
import com.app.raahi.app.viewmodels.helperviewmodel.HelperViewModel
import com.app.raahi.app.viewmodels.routeviewmodel.ExploreFilter
import com.app.raahi.app.viewmodels.routeviewmodel.HomeFilter
import com.app.raahi.app.viewmodels.routeviewmodel.RouteViewModel
import org.koin.core.context.startKoin
import org.koin.mp.KoinPlatform

/** Called once from the SwiftUI App init, like Koshpal: AppModuleKt.doInitKoin() */
fun initKoin() {
    startKoin {
        modules(sharedModule, iosModule)
    }
}

// Swift gets its Reflectors from here: AppModuleKt.getRouteViewModel()
fun getAuthViewModel(): AuthViewModel = KoinPlatform.getKoin().get()
fun getRouteViewModel(): RouteViewModel = KoinPlatform.getKoin().get()
fun getHelperViewModel(): HelperViewModel = KoinPlatform.getKoin().get()

/** Enum lists are awkward from Swift, so hand them over as a plain list. */
fun getBarrierTypes(): List<BarrierType> = BarrierType.entries
fun getHomeFilters(): List<HomeFilter> = HomeFilter.entries
fun getExploreFilters(): List<ExploreFilter> = ExploreFilter.entries
fun getBookingSlots(): List<String> = BOOKING_SLOTS
fun getBookingMinutes(): List<Int> = BOOKING_MINUTES
fun getBookingTerms(): List<String> = BOOKING_TERMS
fun getHelpPricePerHour(): Int = HELP_PRICE_PER_HOUR
fun getVerificationTopics(): List<String> = VERIFICATION_TOPICS
fun getReviewerNeeds(): List<String> = REVIEWER_NEEDS
fun getHelpKinds(): List<HelpKind> = HelpKind.entries
