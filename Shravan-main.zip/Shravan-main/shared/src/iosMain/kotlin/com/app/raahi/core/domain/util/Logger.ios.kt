package com.app.raahi.core.domain.util

actual fun logError(message: String, throwable: Throwable?) {
    println("Raahi ERROR: $message ${throwable?.message ?: ""}")
}

actual fun logDebug(message: String) {
    println("Raahi: $message")
}
