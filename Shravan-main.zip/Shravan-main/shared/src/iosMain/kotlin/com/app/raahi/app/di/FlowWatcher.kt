package com.app.raahi.app.di

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

/** Handle returned to Swift so a bridge can stop collecting in deinit. */
class FlowWatcher internal constructor(private val job: Job) {
    fun cancel() = job.cancel()
}

/**
 * Collects a StateFlow/Flow on the main thread and hands each value to Swift.
 * Swift: FlowWatcherKt.watch(viewModel.user) { value in ... }
 */
fun <T> watch(flow: Flow<T>, onEach: (T) -> Unit): FlowWatcher {
    val job = CoroutineScope(SupervisorJob() + Dispatchers.Main).launch {
        flow.collect { onEach(it) }
    }
    return FlowWatcher(job)
}
