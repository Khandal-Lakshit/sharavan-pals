package com.app.raahi.app.domain.model

/** What the person wants a Helping Hand for. A Helping Hand is a verified person who helps you get things done. */
enum class HelpKind(val label: String, val blurb: String, val detail: String, val symbol: String, val baseHourlyRate: Int = 199) {
    TRAVEL(
        "Travel with me", "Walks or rides along to where you are going",
        "Meets you at your door or stop, goes with you on foot, by auto or by cab, and sees you inside. Good for work, college and daily trips.",
        "🧭",
        199,
    ),
    ERRANDS(
        "Shopping and errands", "Helps you find things and carry them",
        "Goes shopping with you, reads labels and prices, carries the bags and checks the bill. You pay for what you buy.",
        "🛍️",
        149,
    ),
    APPOINTMENT(
        "Hospital or office visit", "Meets you there and helps with queues and forms",
        "Meets you at the hospital, bank or office, finds the right counter and helps with queues and forms. They do not give medical advice.",
        "🏥",
        249,
    ),
    READING(
        "Reading and forms", "Reads signs, letters and screens aloud",
        "Reads letters, bills, signs and screens aloud, and helps you fill in forms. Best in a quiet place.",
        "📄",
        129,
    );

    companion object {
        fun fromApi(value: String): HelpKind = entries.firstOrNull { it.name == value } ?: TRAVEL
    }
}

enum class BookingStatus { CONFIRMED, CANCELLED }

/** A verified Helping Hand booked to meet the user and help. [destination] is free text and may be empty. */
data class Booking(
    val id: String,
    val helperName: String,
    val helperBadge: String?,
    val kind: HelpKind,
    val destination: String,
    val slot: String,
    val note: String,
    val status: BookingStatus,
    val minutes: Int = 60,
    val price: Int = HELP_PRICE_PER_HOUR,
)

/** When the Helping Hand should arrive. Round one: a fixed list. Each reads naturally after "will meet you". */
val BOOKING_SLOTS = listOf("In 30 minutes", "In 1 hour", "Today, 6:00 PM", "Tomorrow, 10:00 AM")

/** What a Helping Hand costs. The user pays [HELP_PRICE_PER_HOUR] an hour, the Helping Hand keeps [HELP_HELPER_SHARE] of it. */
const val HELP_PRICE_PER_HOUR = 199
const val HELP_HELPER_SHARE = 149

/** How long to book, in minutes. Round one: a fixed list. */
val BOOKING_MINUTES = listOf(30, 60, 90, 120, 180)

/** The price for a task, rounded up to the next rupee. */
fun helpPrice(kind: HelpKind, minutes: Int): Int = (kind.baseHourlyRate * minutes + 59) / 60
fun helpPrice(minutes: Int): Int = (HELP_PRICE_PER_HOUR * minutes + 59) / 60

fun durationLabel(minutes: Int): String = when {
    minutes < 60 -> "$minutes minutes"
    minutes == 60 -> "1 hour"
    minutes % 60 == 0 -> "${minutes / 60} hours"
    else -> "${minutes / 60}.5 hours"
}

/** Shown under the form so the person knows what they are agreeing to. */
val BOOKING_TERMS = listOf(
    "Billed by the half hour, minimum 30 minutes. The price is worked out from how long you pick.",
    "Pay your Helping Hand by UPI or cash when you are done. Nothing is charged in this demo.",
    "Cancel free until your Helping Hand sets off.",
    "Your Helping Hand keeps ₹$HELP_HELPER_SHARE of every ₹$HELP_PRICE_PER_HOUR hour. The rest keeps Shravan running.",
    "Every Helping Hand is ID checked and wears a Shravan badge.",
)
