package com.app.raahi.app.domain.model

import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

enum class VenueCategory(val label: String, val plural: String, val symbol: String) {
    CAFE("Cafe", "Cafes", "☕"),
    PARK("Park", "Parks", "🌳"),
    LIBRARY("Library", "Libraries", "📚");

    companion object {
        fun fromApi(value: String): VenueCategory = entries.firstOrNull { it.name == value } ?: CAFE
    }
}

/** A place earns the Shravan Verified badge by sharing a video on each of these and finishing the access Q&A. */
val VERIFICATION_TOPICS = listOf("Entrance and ramp", "Washroom", "Safety", "Hospitality")

/** How a reviewer describes their own access need. */
val REVIEWER_NEEDS = listOf("Wheelchair user", "Blind or low vision", "Deaf or hard of hearing", "Walks with support", "Other")

/** The videos a place has shared and how much of the access Q&A it has answered. */
data class Verification(
    val videoTopics: List<String> = emptyList(),
    val qaDone: Int = 0,
    val qaTotal: Int = 12,
) {
    val missingTopics: List<String> get() = VERIFICATION_TOPICS.filter { it !in videoTopics }
    val isVerified: Boolean get() = missingTopics.isEmpty() && qaDone >= qaTotal
}

/** A review written by another disabled visitor about how they were treated. */
data class VenueReview(
    val id: String,
    val author: String,
    val need: String,
    val rating: Int,
    val text: String,
    val whenLabel: String,
)

/** A friendly place near the user, with the access features that matter to different disabilities. */
data class Venue(
    val id: String,
    val name: String,
    val category: VenueCategory,
    val point: GeoPoint,
    val address: String,
    val features: List<String>,
    val rating: Double,
    val note: String,
    val verification: Verification = Verification(),
    val reviews: List<VenueReview> = emptyList(),
) {
    /** Only cafes carry the badge for now. */
    val isVerified: Boolean get() = category == VenueCategory.CAFE && verification.isVerified

    /** The average of the reviews once there are some, the seeded rating until then. */
    val displayRating: Double
        get() = if (reviews.isEmpty()) rating else (reviews.sumOf { it.rating } * 10.0 / reviews.size).roundToInt() / 10.0
}

data class NearbyVenue(val venue: Venue, val distanceM: Int)

fun GeoPoint.distanceTo(other: GeoPoint): Int {
    fun rad(d: Double) = d * PI / 180.0
    val dLat = rad(other.lat - lat)
    val dLon = rad(other.lon - lon)
    val h = sin(dLat / 2) * sin(dLat / 2) + cos(rad(lat)) * cos(rad(other.lat)) * sin(dLon / 2) * sin(dLon / 2)
    return (2 * 6_371_000.0 * atan2(sqrt(h), sqrt(1 - h))).roundToInt()
}
