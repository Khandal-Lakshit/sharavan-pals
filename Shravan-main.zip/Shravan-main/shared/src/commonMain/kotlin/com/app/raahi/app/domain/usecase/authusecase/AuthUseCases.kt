package com.app.raahi.app.domain.usecase.authusecase

data class AuthUseCases(
    val loginUseCase: LoginUseCase,
)
