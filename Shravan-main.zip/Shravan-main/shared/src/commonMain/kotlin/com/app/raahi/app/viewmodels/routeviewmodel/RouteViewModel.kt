package com.app.raahi.app.viewmodels.routeviewmodel

import androidx.lifecycle.ViewModel
import com.app.raahi.app.fluxdeck.AuthFluxDeck
import kotlinx.coroutines.flow.map
import androidx.lifecycle.viewModelScope
import com.app.raahi.app.domain.coordinator.RouteCoordinator
import com.app.raahi.app.domain.model.Barrier
import com.app.raahi.app.domain.model.BarrierType
import com.app.raahi.app.domain.model.Booking
import com.app.raahi.app.domain.model.BookingStatus
import com.app.raahi.app.domain.model.HelpKind
import com.app.raahi.app.domain.model.GeoPoint
import com.app.raahi.app.domain.model.DemoArea
import com.app.raahi.app.domain.model.NearbyVenue
import com.app.raahi.app.domain.model.Place
import com.app.raahi.app.domain.model.Venue
import com.app.raahi.app.domain.model.VenueCategory
import com.app.raahi.app.domain.model.distanceTo
import com.app.raahi.app.domain.model.ChatMessage
import com.app.raahi.app.domain.model.CommunityGroup
import com.app.raahi.app.domain.repository.CommunityRepo
import com.app.raahi.app.fluxdeck.RouteFluxDeck
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

enum class UserTab { HOME, EXPLORE, COMMUNITY, HELP, ALERTS, PLANNED }

/** Category chips on the Community tab. */
enum class CommunityFilter(val label: String) {
    ALL("All"),
    JOINED("Joined"),
    RECOMMENDED("Recommended"),
}

/** Category chips on the Explore tab. */
enum class ExploreFilter(val label: String, val category: VenueCategory?) {
    ALL("All", null),
    CAFES("Cafes", VenueCategory.CAFE),
    PARKS("Parks", VenueCategory.PARK),
    LIBRARIES("Libraries", VenueCategory.LIBRARY),
}

/** Filter chips on the Home map. An empty set means "show everything". */
enum class HomeFilter(val label: String, val types: Set<BarrierType>) {
    ALL("All", emptySet()),
    STEPS("Steps & ramps", setOf(BarrierType.STEPS, BarrierType.MISSING_KERB_RAMP)),
    SURFACE("Path & surface", setOf(BarrierType.BROKEN_SURFACE, BarrierType.MISSING_FOOTPATH)),
    OBSTACLES("Obstacles", setOf(BarrierType.POLE_OBSTRUCTION, BarrierType.PARKED_VEHICLE, BarrierType.TEMP_BLOCKED)),
}

/** Reflector for the user feature. The UI only ever sees these read-only flows, never the FluxDeck. */
class RouteViewModel(
    private val coordinator: RouteCoordinator,
    private val fluxDeck: RouteFluxDeck,
    authFluxDeck: AuthFluxDeck,
    private val communityRepo: CommunityRepo,
) : ViewModel() {

    // Community Group Chat
    val communityGroups = communityRepo.groups
    val userName = authFluxDeck.user.map { it?.name.orEmpty() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    val communityMessages = combine(communityRepo.messages, authFluxDeck.user) { messages, u ->
        val currentName = u?.name?.ifBlank { "Asha" } ?: "Asha"
        messages.mapValues { (_, list) ->
            list.map { msg ->
                val isMyMessage = msg.isMe ||
                    msg.senderName.equals(currentName, ignoreCase = true) ||
                    (currentName.contains("Asha", ignoreCase = true) && msg.senderName.contains("Asha", ignoreCase = true))
                msg.copy(isMe = isMyMessage)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    private val _selectedGroupId = MutableStateFlow("c1")
    val selectedGroupId: StateFlow<String> = _selectedGroupId.asStateFlow()
    private val _communitySearch = MutableStateFlow("")
    val communitySearch: StateFlow<String> = _communitySearch.asStateFlow()
    private val _communityFilter = MutableStateFlow(CommunityFilter.ALL)
    val communityFilter: StateFlow<CommunityFilter> = _communityFilter.asStateFlow()
    private val _isChatOpen = MutableStateFlow(false)
    val isChatOpen: StateFlow<Boolean> = _isChatOpen.asStateFlow()

    // ephemeral screen state
    private val _tab = MutableStateFlow(UserTab.HOME)
    val tab: StateFlow<UserTab> = _tab.asStateFlow()
    private val _homeFilter = MutableStateFlow(HomeFilter.ALL)
    val homeFilter: StateFlow<HomeFilter> = _homeFilter.asStateFlow()
    /** True while the user is changing From/To after a route was found. */
    private val _editingSearch = MutableStateFlow(false)
    private val _showDirections = MutableStateFlow(false)
    val showDirections: StateFlow<Boolean> = _showDirections.asStateFlow()

    val events = coordinator.events

    private fun <T> Flow<T>.reflect(initial: T): StateFlow<T> =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), initial)

    // reflected FluxDeck state + Formulas
    val places = fluxDeck.places
    /** City shown on Home, taken from the demo places. Empty until places load. */
    val cityName = fluxDeck.places.map { list -> list.firstNotNullOfOrNull { DemoArea.cityFor(it.point) }.orEmpty() }
        .reflect("")
    val origin = fluxDeck.origin
    val destination = fluxDeck.destination
    val plan = fluxDeck.plan
    val isPlanning = fluxDeck.isPlanning
    val alerts = fluxDeck.alerts
    val rerouteBanner = fluxDeck.rerouteBanner
    val checkRequested = fluxDeck.checkRequested
    val canPlan = fluxDeck.canPlan.reflect(false)
    val unreadCount = fluxDeck.unreadCount.reflect(0)
    val barriersOnMap = fluxDeck.barriersOnMap.reflect(emptyList<Barrier>())
    val selectedBarrier = fluxDeck.selectedBarrier.reflect(null)
    val fitPoints = fluxDeck.fitPoints.reflect(emptyList<GeoPoint>())

    // Explore: friendly places around the user, nearest first, narrowed by the chip
    private val _exploreFilter = MutableStateFlow(ExploreFilter.ALL)
    val exploreFilter: StateFlow<ExploreFilter> = _exploreFilter.asStateFlow()
    val nearby = combine(fluxDeck.venues, fluxDeck.userLocation, _exploreFilter) { venues, here, filter ->
        venues.filter { filter.category == null || it.category == filter.category }
            .map { NearbyVenue(it, here.distanceTo(it.point)) }
            .sortedBy { it.distanceM }
    }.reflect(emptyList<NearbyVenue>())
    // Helping Hand: the one confirmed booking (newest) shows as the floating card above the bar
    val bookings = fluxDeck.bookings
    val activeBooking = fluxDeck.bookings.map { list -> list.firstOrNull { it.status == BookingStatus.CONFIRMED } }
        .reflect(null as Booking?)

    // Search card: once a route exists it shrinks to "From -> To" with an edit icon
    val searchCollapsed = combine(fluxDeck.plan, _editingSearch) { plan, editing -> plan != null && !editing }
        .reflect(false)

    // Home map: all reported barriers, narrowed by the chip (derived here, it is screen state)
    val homeBarriers = combine(fluxDeck.allBarriers, _homeFilter) { all, filter ->
        if (filter.types.isEmpty()) all else all.filter { it.type in filter.types }
    }.reflect(emptyList<Barrier>())

    // Camera target: the route once there is one, otherwise every visible pin
    val mapFit = combine(fluxDeck.fitPoints, homeBarriers) { route, pins ->
        if (route.isNotEmpty()) route else pins.map { it.point }
    }.reflect(emptyList<GeoPoint>())

    fun setTab(tab: UserTab) {
        _tab.value = tab
        fluxDeck.selectBarrier(null)
        if (tab == UserTab.ALERTS) coordinator.markAllAlertsRead()
    }

    fun setHomeFilter(filter: HomeFilter) {
        _homeFilter.value = filter
        fluxDeck.selectBarrier(null)
    }

    /** From an alert card: go to the map with that barrier selected. */
    fun showOnMap(barrierId: String) {
        _tab.value = UserTab.HOME
        fluxDeck.selectBarrier(barrierId)
    }

    fun setExploreFilter(filter: ExploreFilter) { _exploreFilter.value = filter }

    fun selectCommunityGroup(groupId: String) {
        _selectedGroupId.value = groupId
        _isChatOpen.value = true
        communityRepo.markGroupRead(groupId)
    }

    fun setChatOpen(open: Boolean) { _isChatOpen.value = open }
    fun setCommunitySearch(query: String) { _communitySearch.value = query }
    fun setCommunityFilter(filter: CommunityFilter) { _communityFilter.value = filter }

    fun sendCommunityMessage(text: String) {
        val name = userName.value.ifBlank { "You" }
        communityRepo.sendMessage(_selectedGroupId.value, text, name)
    }

    /** Tapping a place: show the route from the user's location on the Home map. */
    fun goTo(venue: Venue) {
        _tab.value = UserTab.HOME
        _editingSearch.value = false
        fluxDeck.selectBarrier(null)
        coordinator.goTo(venue)
    }
    fun bookHelper(kind: HelpKind, destination: String, slot: String, note: String, minutes: Int) =
        coordinator.bookHelper(kind, destination, slot, note, minutes)
    fun cancelBooking(id: String) = coordinator.cancelBooking(id)
    fun postReview(venueId: String, rating: Int, need: String, text: String) =
        coordinator.postReview(venueId, rating, need, text)

    fun toggleDirections() { _showDirections.value = !_showDirections.value }
    fun chooseOrigin(place: Place) = fluxDeck.updateOrigin(place)
    fun chooseDestination(place: Place) = fluxDeck.updateDestination(place)
    fun selectBarrier(id: String?) = fluxDeck.selectBarrier(id)
    fun dismissBanner() = fluxDeck.updateRerouteBanner(null)
    fun editSearch() {
        fluxDeck.selectBarrier(null)   // close any open detail card
        _editingSearch.value = true
    }

    fun findRoute() {
        _editingSearch.value = false
        fluxDeck.selectBarrier(null)
        coordinator.planRoute()
    }
    fun askHelperToCheck() = coordinator.requestRouteCheck()
}
