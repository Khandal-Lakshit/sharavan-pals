package com.app.raahi.app.data.repository

import com.app.raahi.app.data.mapper.toDomain
import com.app.raahi.app.domain.model.Alert
import com.app.raahi.app.domain.model.Barrier
import com.app.raahi.app.domain.model.Booking
import com.app.raahi.app.domain.model.HelpKind
import com.app.raahi.app.domain.model.Venue
import com.app.raahi.app.domain.model.GeoPoint
import com.app.raahi.app.domain.model.HelpRequest
import com.app.raahi.app.domain.model.Place
import com.app.raahi.app.domain.model.RoutePlan
import com.app.raahi.app.domain.repository.RouteRepo
import com.app.raahi.core.data.remote.dto.BookingRequestDto
import com.app.raahi.core.data.remote.dto.CheckRequestDto
import com.app.raahi.core.data.remote.dto.PointDto
import com.app.raahi.core.data.remote.dto.RouteRequestDto
import com.app.raahi.core.data.remote.source.RouteDataSource
import com.app.raahi.core.domain.util.NetworkError
import com.app.raahi.core.domain.util.Result
import com.app.raahi.core.domain.util.map
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class RouteRepoImpl(private val remote: RouteDataSource) : RouteRepo {

    private fun GeoPoint.dto() = PointDto(lat, lon)

    override suspend fun searchPlaces(query: String): Result<List<Place>, NetworkError> =
        remote.searchPlaces(query).map { list -> list.map { it.toDomain() } }

    override suspend fun planRoute(from: GeoPoint, to: GeoPoint, userId: String?): Result<RoutePlan, NetworkError> =
        remote.planRoute(RouteRequestDto(from.dto(), to.dto(), userId)).map { it.toDomain() }

    override suspend fun requestRouteCheck(
        userId: String, from: GeoPoint, to: GeoPoint, title: String,
    ): Result<HelpRequest, NetworkError> =
        remote.createCheckRequest(CheckRequestDto(from.dto(), to.dto(), userId, title)).map { it.toDomain() }

    override suspend fun markAlertRead(id: String): Result<Unit, NetworkError> =
        remote.markAlertRead(id).map { }

    override suspend fun getVenues(): Result<List<Venue>, NetworkError> =
        remote.getVenues().map { list -> list.map { it.toDomain() } }

    override suspend fun bookHelper(userId: String, kind: HelpKind, destination: String, slot: String, note: String, minutes: Int): Result<Booking, NetworkError> =
        remote.createBooking(BookingRequestDto(userId, kind.name, destination, slot, note, minutes)).map { it.toDomain() }

    override suspend fun getBookings(userId: String): Result<List<Booking>, NetworkError> =
        remote.getBookings(userId).map { list -> list.map { it.toDomain() } }

    override suspend fun cancelBooking(id: String): Result<Booking, NetworkError> =
        remote.cancelBooking(id).map { it.toDomain() }

    override fun observeAlerts(userId: String): Flow<Result<List<Alert>, NetworkError>> = flow {
        while (true) {
            emit(remote.getAlerts(userId).map { list -> list.map { it.toDomain() } })
            delay(POLL_MS)
        }
    }

    override fun observeBarriers(): Flow<Result<List<Barrier>, NetworkError>> = flow {
        while (true) {
            emit(remote.getBarriers().map { list -> list.map { it.toDomain() } })
            delay(POLL_MS)
        }
    }

    private companion object {
        const val POLL_MS = 4_000L
    }
}
