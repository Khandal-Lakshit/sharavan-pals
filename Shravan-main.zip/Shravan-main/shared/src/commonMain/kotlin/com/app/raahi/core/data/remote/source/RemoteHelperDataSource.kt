package com.app.raahi.core.data.remote.source

import com.app.raahi.core.data.networking.constructUrl
import com.app.raahi.core.data.networking.safeCall
import com.app.raahi.core.data.remote.dto.CompleteRequestDto
import com.app.raahi.core.data.remote.dto.HelpRequestDto
import com.app.raahi.core.data.remote.dto.ReportResponseDto
import com.app.raahi.core.domain.util.NetworkError
import com.app.raahi.core.domain.util.Result
import io.ktor.client.HttpClient
import io.ktor.client.request.forms.formData
import io.ktor.client.request.forms.submitFormWithBinaryData
import io.ktor.client.request.get
import io.ktor.client.request.parameter
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.Headers
import io.ktor.http.HttpHeaders
import io.ktor.http.contentType

class RemoteHelperDataSource(private val httpClient: HttpClient) : HelperDataSource {

    override suspend fun getOpenRequests(): Result<List<HelpRequestDto>, NetworkError> =
        safeCall<List<HelpRequestDto>> {
            httpClient.get(urlString = constructUrl("/route-requests")) { parameter("open", true) }
        }

    override suspend fun completeRequest(id: String, helperId: String): Result<HelpRequestDto, NetworkError> =
        safeCall<HelpRequestDto> {
            httpClient.post(urlString = constructUrl("/route-requests/$id/complete")) {
                contentType(ContentType.Application.Json)
                setBody(CompleteRequestDto(helperId))
            }
        }

    override suspend fun createReport(
        lat: Double,
        lon: Double,
        status: String,
        reporterId: String,
        note: String?,
        requestId: String?,
        photo: ByteArray?,
    ): Result<ReportResponseDto, NetworkError> = safeCall<ReportResponseDto> {
        httpClient.submitFormWithBinaryData(
            url = constructUrl("/reports"),
            formData = formData {
                append("lat", lat.toString())
                append("lon", lon.toString())
                append("status", status)
                append("reporterId", reporterId)
                if (!note.isNullOrBlank()) append("note", note)
                if (requestId != null) append("requestId", requestId)
                if (photo != null) {
                    append("photo", photo, Headers.build {
                        append(HttpHeaders.ContentType, "image/jpeg")
                        append(HttpHeaders.ContentDisposition, "filename=\"report.jpg\"")
                    })
                }
            },
        )
    }
}
