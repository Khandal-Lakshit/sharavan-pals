package com.app.raahi.app.fluxdeck

import com.app.raahi.app.domain.model.Alert
import com.app.raahi.app.domain.model.Barrier
import com.app.raahi.app.domain.model.Booking
import com.app.raahi.app.domain.model.DemoArea
import com.app.raahi.app.domain.model.Venue
import com.app.raahi.app.domain.model.VenueReview
import com.app.raahi.app.domain.model.GeoPoint
import com.app.raahi.app.domain.model.Place
import com.app.raahi.app.domain.model.RoutePlan
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map

/** Model for the user's "find a barrier-free route" feature. */
class RouteFluxDeck {
    private val _places = MutableStateFlow<List<Place>>(emptyList())
    val places: StateFlow<List<Place>> = _places.asStateFlow()

    private val _origin = MutableStateFlow<Place?>(null)
    val origin: StateFlow<Place?> = _origin.asStateFlow()

    private val _destination = MutableStateFlow<Place?>(null)
    val destination: StateFlow<Place?> = _destination.asStateFlow()

    private val _plan = MutableStateFlow<RoutePlan?>(null)
    val plan: StateFlow<RoutePlan?> = _plan.asStateFlow()

    private val _isPlanning = MutableStateFlow(false)
    val isPlanning: StateFlow<Boolean> = _isPlanning.asStateFlow()

    private val _alerts = MutableStateFlow<List<Alert>>(emptyList())
    val alerts: StateFlow<List<Alert>> = _alerts.asStateFlow()

    private val _allBarriers = MutableStateFlow<List<Barrier>>(emptyList())
    val allBarriers: StateFlow<List<Barrier>> = _allBarriers.asStateFlow()

    private val _selectedBarrierId = MutableStateFlow<String?>(null)
    val selectedBarrierId: StateFlow<String?> = _selectedBarrierId.asStateFlow()

    private val _rerouteBanner = MutableStateFlow<String?>(null)
    val rerouteBanner: StateFlow<String?> = _rerouteBanner.asStateFlow()

    private val _handledIssueIds = MutableStateFlow<Set<String>>(emptySet())
    val handledIssueIds: StateFlow<Set<String>> = _handledIssueIds.asStateFlow()

    private val _checkRequested = MutableStateFlow(false)
    val checkRequested: StateFlow<Boolean> = _checkRequested.asStateFlow()

    private val _venues = MutableStateFlow<List<Venue>>(emptyList())
    val venues: StateFlow<List<Venue>> = _venues.asStateFlow()

    private val _bookings = MutableStateFlow<List<Booking>>(emptyList())
    val bookings: StateFlow<List<Booking>> = _bookings.asStateFlow()

    /** Where "around you" is measured from. Round one: a fixed demo point; round two: the phone's GPS fix. */
    private val _userLocation = MutableStateFlow(DemoArea.USER_POINT)
    val userLocation: StateFlow<GeoPoint> = _userLocation.asStateFlow()

    // ---- Formulas ----
    val canPlan: Flow<Boolean> = combine(_origin, _destination) { o, d -> o != null && d != null && o.name != d.name }

    val unreadCount: Flow<Int> = _alerts.map { list -> list.count { !it.isRead } }

    val barriersOnMap: Flow<List<Barrier>> = _plan.map { p ->
        if (p == null) emptyList() else (p.baseline.barriers + p.safe.barriers).distinctBy { it.id }
    }

    /** One selection serves both maps: a pin on Home or a barrier on the planned route. */
    val selectedBarrier: Flow<Barrier?> = combine(_allBarriers, barriersOnMap, _selectedBarrierId) { all, onRoute, id ->
        (onRoute + all).firstOrNull { it.id == id }
    }

    val fitPoints: Flow<List<GeoPoint>> = _plan.map { p ->
        if (p == null) emptyList() else p.baseline.polyline + p.safe.polyline
    }

    // ---- state writers ----
    fun updatePlaces(list: List<Place>) { _places.value = list }
    fun updateVenues(list: List<Venue>) { _venues.value = list }
    fun addReview(venueId: String, review: VenueReview) {
        _venues.value = _venues.value.map { if (it.id == venueId) it.copy(reviews = listOf(review) + it.reviews) else it }
    }
    fun updateBookings(list: List<Booking>) { _bookings.value = list }
    fun upsertBooking(b: Booking) { _bookings.value = listOf(b) + _bookings.value.filter { it.id != b.id } }
    fun updateOrigin(place: Place) { _origin.value = place; resetRoute() }
    fun updateDestination(place: Place) { _destination.value = place; resetRoute() }

    private fun resetRoute() {
        _plan.value = null
        _checkRequested.value = false
        _selectedBarrierId.value = null
    }

    fun updatePlan(plan: RoutePlan?) { _plan.value = plan }
    fun setPlanning(value: Boolean) { _isPlanning.value = value }
    fun updateAlerts(list: List<Alert>) { _alerts.value = list }
    fun updateAllBarriers(list: List<Barrier>) { _allBarriers.value = list }
    fun selectBarrier(id: String?) { _selectedBarrierId.value = id }
    fun updateRerouteBanner(text: String?) { _rerouteBanner.value = text }
    fun markIssuesHandled(ids: Set<String>) { _handledIssueIds.value = _handledIssueIds.value + ids }
    fun setCheckRequested(value: Boolean) { _checkRequested.value = value }

    fun clear() {
        _places.value = emptyList(); _origin.value = null; _destination.value = null
        _plan.value = null; _isPlanning.value = false; _alerts.value = emptyList(); _allBarriers.value = emptyList()
        _selectedBarrierId.value = null; _rerouteBanner.value = null
        _handledIssueIds.value = emptySet(); _checkRequested.value = false
        _venues.value = emptyList(); _bookings.value = emptyList()
    }
}
