package com.app.raahi.app.domain.usecase.helperusecase

import com.app.raahi.app.domain.model.Barrier
import com.app.raahi.app.domain.model.HelpRequest
import com.app.raahi.app.domain.model.ReportDraft
import com.app.raahi.app.domain.model.ReportResult
import com.app.raahi.app.domain.repository.HelperRepo
import com.app.raahi.core.domain.util.NetworkError
import com.app.raahi.core.domain.util.Result
import kotlinx.coroutines.flow.Flow

class ObserveBarriersUseCase(private val helperRepo: HelperRepo) {
    operator fun invoke(): Flow<Result<List<Barrier>, NetworkError>> = helperRepo.observeBarriers()
}

class SubmitReportUseCase(private val helperRepo: HelperRepo) {
    suspend operator fun invoke(reporterId: String, draft: ReportDraft): Result<ReportResult, NetworkError> =
        helperRepo.submitReport(reporterId, draft)
}

class CompleteRouteCheckUseCase(private val helperRepo: HelperRepo) {
    suspend operator fun invoke(requestId: String, helperId: String): Result<Unit, NetworkError> =
        helperRepo.completeRouteCheck(requestId, helperId)
}

class ObserveOpenRequestsUseCase(private val helperRepo: HelperRepo) {
    operator fun invoke(): Flow<Result<List<HelpRequest>, NetworkError>> = helperRepo.observeOpenRequests()
}

data class HelperUseCases(
    val observeBarriers: ObserveBarriersUseCase,
    val submitReport: SubmitReportUseCase,
    val completeRouteCheck: CompleteRouteCheckUseCase,
    val observeOpenRequests: ObserveOpenRequestsUseCase,
)
