package com.app.raahi.app.domain.repository

import com.app.raahi.app.domain.model.Barrier
import com.app.raahi.app.domain.model.HelpRequest
import com.app.raahi.app.domain.model.ReportDraft
import com.app.raahi.app.domain.model.ReportResult
import com.app.raahi.core.domain.util.NetworkError
import com.app.raahi.core.domain.util.Result
import kotlinx.coroutines.flow.Flow

interface HelperRepo {
    fun observeBarriers(): Flow<Result<List<Barrier>, NetworkError>>
    suspend fun submitReport(reporterId: String, draft: ReportDraft): Result<ReportResult, NetworkError>
    suspend fun completeRouteCheck(requestId: String, helperId: String): Result<Unit, NetworkError>
    fun observeOpenRequests(): Flow<Result<List<HelpRequest>, NetworkError>>
}
