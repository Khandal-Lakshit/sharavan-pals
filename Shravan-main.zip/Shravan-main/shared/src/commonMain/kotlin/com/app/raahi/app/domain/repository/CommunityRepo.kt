package com.app.raahi.app.domain.repository

import com.app.raahi.app.domain.model.ChatMessage
import com.app.raahi.app.domain.model.CommunityGroup
import kotlinx.coroutines.flow.StateFlow

interface CommunityRepo {
    val groups: StateFlow<List<CommunityGroup>>
    val messages: StateFlow<Map<String, List<ChatMessage>>>
    fun sendMessage(groupId: String, text: String, senderName: String)
    fun markGroupRead(groupId: String)
}
