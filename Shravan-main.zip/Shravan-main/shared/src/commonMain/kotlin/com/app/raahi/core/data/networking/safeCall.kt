package com.app.raahi.core.data.networking

import com.app.raahi.core.domain.util.NetworkError
import com.app.raahi.core.domain.util.Result
import com.app.raahi.core.domain.util.logError
import io.ktor.client.statement.HttpResponse
import io.ktor.util.network.UnresolvedAddressException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.serialization.SerializationException

suspend inline fun <reified T> safeCall(
    execute: () -> HttpResponse
): Result<T, NetworkError> {
    val response = try {
        execute()
    } catch (_: UnresolvedAddressException) {
        return Result.Error(NetworkError.SERVER_ERROR, serverUnreachable())
    } catch (e: SerializationException) {
        logError("Serialization Error", e)
        return Result.Error(NetworkError.SERIALIZATION, e.message)
    } catch (e: Exception) {
        currentCoroutineContext().ensureActive()
        logError("SafeCall Unknown Error", e)
        // Raahi change: a refused / timed-out connection almost always means the backend is not running or the URL is wrong.
        return Result.Error(NetworkError.SERVER_ERROR, serverUnreachable())
    }

    return responseToResult(response)
}

fun serverUnreachable(): String =
    "Can't reach the Shravan server at ${BaseUrl.value}. Start the backend and check the address."
