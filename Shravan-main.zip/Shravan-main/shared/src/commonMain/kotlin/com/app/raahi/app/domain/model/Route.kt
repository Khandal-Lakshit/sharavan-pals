package com.app.raahi.app.domain.model

data class Place(val name: String, val point: GeoPoint)

data class RouteStep(val text: String, val distanceM: Int)

/** Age in days of the newest street photo of one footpath segment. null = never photographed. */
/**
 * Round one only: the demo map is Jaipur, so a point near it is "Jaipur". Round two replaces this with a reverse
 * geocode from the backend. Used where the app says which city you are in.
 */
object DemoArea {
    const val CITY = "Jaipur"
    /** Round one: where the demo user stands, a few steps from the bus stop. Round two uses the real GPS fix. */
    val USER_POINT = GeoPoint(26.842420, 75.804420)
    private const val CENTER_LAT = 26.8432
    private const val CENTER_LON = 75.8072
    private const val RADIUS_DEG = 0.25   // roughly 25 km

    fun cityFor(point: GeoPoint): String? =
        if (kotlin.math.abs(point.lat - CENTER_LAT) < RADIUS_DEG && kotlin.math.abs(point.lon - CENTER_LON) < RADIUS_DEG) CITY else null
}

data class SegmentImagery(val segmentId: String, val ageDays: Int?)

enum class ConfidenceLevel(val label: String) { HIGH("High"), MEDIUM("Medium"), LOW("Low") }

/**
 * How much we can trust a route, from the age and coverage of the street photos behind it.
 * Each segment scores 1.0 with a photo from today, falling in a straight line to 0 at 180 days, and 0 when it
 * has no photo at all. Route confidence is the average, so old photos and missing photos both pull it down.
 * A segment with no photo, or one older than 90 days, counts as "no recent imagery".
 */
data class RouteImagery(
    val confidencePct: Int,
    val segmentCount: Int,
    val noRecentCount: Int,
    val typicalAgeDays: Int,
) {
    val level: ConfidenceLevel
        get() = when {
            confidencePct >= 75 -> ConfidenceLevel.HIGH
            confidencePct >= 50 -> ConfidenceLevel.MEDIUM
            else -> ConfidenceLevel.LOW
        }
    val recentCount: Int get() = segmentCount - noRecentCount

    companion object {
        const val RECENT_DAYS = 90
        const val FADE_DAYS = 180
        val EMPTY = RouteImagery(0, 0, 0, 0)

        fun from(segments: List<SegmentImagery>): RouteImagery {
            if (segments.isEmpty()) return EMPTY
            val scores = segments.map { s ->
                val age = s.ageDays ?: return@map 0.0
                (1.0 - age.toDouble() / FADE_DAYS).coerceIn(0.0, 1.0)
            }
            val ages = segments.mapNotNull { it.ageDays }.sorted()
            return RouteImagery(
                confidencePct = (scores.average() * 100).toInt(),
                segmentCount = segments.size,
                noRecentCount = segments.count { it.ageDays == null || it.ageDays > RECENT_DAYS },
                typicalAgeDays = if (ages.isEmpty()) 0 else ages[ages.size / 2],
            )
        }
    }
}

data class RouteLeg(
    val polyline: List<GeoPoint>,
    val distanceM: Int,
    val durationMin: Int,
    val barriers: List<Barrier>,
    val steps: List<RouteStep>,
    val imagery: RouteImagery = RouteImagery.EMPTY,
)

data class RoutePlan(
    val routeId: String,
    val baseline: RouteLeg,
    val safe: RouteLeg,
    val extraDistanceM: Int,
)
