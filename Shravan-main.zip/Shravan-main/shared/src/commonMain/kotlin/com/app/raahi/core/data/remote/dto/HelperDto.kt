package com.app.raahi.core.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class HelpRequestDto(
    val id: String,
    val userId: String,
    val userName: String = "User",
    val status: String,
    val title: String,
    val polyline: List<List<Double>> = emptyList(),
    val createdAt: String? = null,
)

@Serializable data class CompleteRequestDto(val helperId: String)
@Serializable data class AiSuggestionDto(val type: String, val confidence: Double = 0.0)

@Serializable
data class ReportResponseDto(
    val reportId: String,
    val segmentId: String,
    val snapDistanceM: Double = 0.0,
    val aiSuggestion: AiSuggestionDto? = null,
    val verified: Boolean = true,
    val expiresAt: String? = null,
    val barrier: BarrierDto? = null,
)
