package com.app.raahi.core.data.remote.source

import com.app.raahi.core.data.remote.dto.UserDto
import com.app.raahi.core.domain.util.NetworkError
import com.app.raahi.core.domain.util.Result

interface AuthDataSource {
    suspend fun login(role: String): Result<UserDto, NetworkError>
}
