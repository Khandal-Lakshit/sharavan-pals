package com.app.raahi.core.domain.util

interface CallError