package com.app.raahi.app.domain.usecase.routeusecase

import com.app.raahi.app.domain.model.Alert
import com.app.raahi.app.domain.model.Barrier
import com.app.raahi.app.domain.model.Booking
import com.app.raahi.app.domain.model.HelpKind
import com.app.raahi.app.domain.model.Venue
import com.app.raahi.app.domain.model.GeoPoint
import com.app.raahi.app.domain.model.HelpRequest
import com.app.raahi.app.domain.model.Place
import com.app.raahi.app.domain.model.RoutePlan
import com.app.raahi.app.domain.repository.RouteRepo
import com.app.raahi.core.domain.util.NetworkError
import com.app.raahi.core.domain.util.Result
import kotlinx.coroutines.flow.Flow

class SearchPlacesUseCase(private val routeRepo: RouteRepo) {
    suspend operator fun invoke(query: String): Result<List<Place>, NetworkError> = routeRepo.searchPlaces(query)
}

class PlanRouteUseCase(private val routeRepo: RouteRepo) {
    suspend operator fun invoke(from: GeoPoint, to: GeoPoint, userId: String?): Result<RoutePlan, NetworkError> =
        routeRepo.planRoute(from, to, userId)
}

class RequestRouteCheckUseCase(private val routeRepo: RouteRepo) {
    suspend operator fun invoke(userId: String, from: GeoPoint, to: GeoPoint, title: String): Result<HelpRequest, NetworkError> =
        routeRepo.requestRouteCheck(userId, from, to, title)
}

class MarkAlertReadUseCase(private val routeRepo: RouteRepo) {
    suspend operator fun invoke(id: String): Result<Unit, NetworkError> = routeRepo.markAlertRead(id)
}

class ObserveAlertsUseCase(private val routeRepo: RouteRepo) {
    operator fun invoke(userId: String): Flow<Result<List<Alert>, NetworkError>> = routeRepo.observeAlerts(userId)
}

class ObserveMapBarriersUseCase(private val routeRepo: RouteRepo) {
    operator fun invoke(): Flow<Result<List<Barrier>, NetworkError>> = routeRepo.observeBarriers()
}

class GetVenuesUseCase(private val routeRepo: RouteRepo) {
    suspend operator fun invoke(): Result<List<Venue>, NetworkError> = routeRepo.getVenues()
}

class GetBookingsUseCase(private val routeRepo: RouteRepo) {
    suspend operator fun invoke(userId: String): Result<List<Booking>, NetworkError> = routeRepo.getBookings(userId)
}

class BookHelperUseCase(private val routeRepo: RouteRepo) {
    suspend operator fun invoke(userId: String, kind: HelpKind, destination: String, slot: String, note: String, minutes: Int): Result<Booking, NetworkError> =
        routeRepo.bookHelper(userId, kind, destination, slot, note, minutes)
}

class CancelBookingUseCase(private val routeRepo: RouteRepo) {
    suspend operator fun invoke(id: String): Result<Booking, NetworkError> = routeRepo.cancelBooking(id)
}

data class RouteUseCases(
    val searchPlaces: SearchPlacesUseCase,
    val planRoute: PlanRouteUseCase,
    val requestRouteCheck: RequestRouteCheckUseCase,
    val markAlertRead: MarkAlertReadUseCase,
    val observeAlerts: ObserveAlertsUseCase,
    val observeMapBarriers: ObserveMapBarriersUseCase,
    val getVenues: GetVenuesUseCase,
    val getBookings: GetBookingsUseCase,
    val bookHelper: BookHelperUseCase,
    val cancelBooking: CancelBookingUseCase,
)
