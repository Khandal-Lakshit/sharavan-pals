package com.app.raahi.core.data.fake

import com.app.raahi.core.data.remote.dto.AiSuggestionDto
import com.app.raahi.core.data.remote.dto.AlertDto
import com.app.raahi.core.data.remote.dto.BarrierDto
import com.app.raahi.core.data.remote.dto.BookingDto
import com.app.raahi.core.data.remote.dto.BookingRequestDto
import com.app.raahi.core.data.remote.dto.CheckRequestDto
import com.app.raahi.core.data.remote.dto.VenueDto
import com.app.raahi.core.data.remote.dto.HelpRequestDto
import com.app.raahi.core.data.remote.dto.OkDto
import com.app.raahi.core.data.remote.dto.PlaceDto
import com.app.raahi.core.data.remote.dto.ReportResponseDto
import com.app.raahi.core.data.remote.dto.RouteRequestDto
import com.app.raahi.core.data.remote.dto.RouteResponseDto
import com.app.raahi.core.data.remote.dto.UserDto
import com.app.raahi.core.data.remote.source.AuthDataSource
import com.app.raahi.core.data.remote.source.HelperDataSource
import com.app.raahi.core.data.remote.source.RouteDataSource
import com.app.raahi.core.domain.util.NetworkError
import com.app.raahi.core.domain.util.Result
import kotlinx.coroutines.delay

private const val LATENCY_MS = 400L

class FakeAuthDataSource : AuthDataSource {
    override suspend fun login(role: String): Result<UserDto, NetworkError> {
        delay(LATENCY_MS)
        return Result.Success(
            if (role == "HELPER") UserDto("cg_01", "Shravan", "HELPER", "Verified driver") else UserDto("u_01", "Asha", "USER"),
        )
    }
}

class FakeRouteDataSource(private val world: FakeWorld, private val planner: RoutePlanner) : RouteDataSource {
    override suspend fun searchPlaces(query: String): Result<List<PlaceDto>, NetworkError> =
        Result.Success(world.places.filter { it.name.contains(query, ignoreCase = true) })

    override suspend fun planRoute(body: RouteRequestDto): Result<RouteResponseDto, NetworkError> {
        val from = body.origin.lat to body.origin.lon
        val to = body.to.lat to body.to.lon
        if (metres(from, to) < 30) return Result.Error(NetworkError.BAD_REQUEST, "Pick two different places.")

        val baseline = planner.baseline(from, to)
        if (baseline == null) {      // no internet: fall back to the saved Bus stop to Metro walk, otherwise say so
            val saved = world.offlineRoutes(from, to)
                ?: return Result.Error(NetworkError.NO_INTERNET, "Can't reach the routing service. Check your internet connection.")
            world.noteRoute(from, to)
            return Result.Success(world.response(saved.first, saved.second))
        }
        world.noteRoute(from, to)
        world.ensureBarrierOn(baseline)
        val safe = planner.clearOf(from, to, baseline, world.barrierPoints())
        return Result.Success(world.response(baseline, safe))
    }

    override suspend fun getBarriers(): Result<List<BarrierDto>, NetworkError> = Result.Success(world.barriers())

    override suspend fun createCheckRequest(body: CheckRequestDto): Result<HelpRequestDto, NetworkError> {
        delay(LATENCY_MS)
        val req = HelpRequestDto(
            id = world.nextId("rr"), userId = body.userId, userName = "Asha", status = "OPEN",
            title = body.title ?: "Bus stop to Metro station",
            polyline = world.lastBaseline.map { listOf(it.first, it.second) },
        )
        world.requests.add(req)
        return Result.Success(req)
    }

    override suspend fun getAlerts(userId: String): Result<List<AlertDto>, NetworkError> =
        Result.Success(world.alerts.toList())

    override suspend fun getVenues(): Result<List<VenueDto>, NetworkError> = Result.Success(world.venues)

    override suspend fun createBooking(body: BookingRequestDto): Result<BookingDto, NetworkError> {
        delay(LATENCY_MS * 2)
        return Result.Success(world.book(body.userId, body.kind, body.destination, body.slot, body.note, body.minutes))
    }

    override suspend fun getBookings(userId: String): Result<List<BookingDto>, NetworkError> =
        Result.Success(world.bookingsFor(userId))

    override suspend fun cancelBooking(id: String): Result<BookingDto, NetworkError> {
        delay(LATENCY_MS)
        val b = world.cancelBooking(id) ?: return Result.Error(NetworkError.NOT_FOUND, "That booking no longer exists.")
        return Result.Success(b)
    }

    override suspend fun markAlertRead(id: String): Result<OkDto, NetworkError> {
        val i = world.alerts.indexOfFirst { it.id == id }
        if (i >= 0) world.alerts[i] = world.alerts[i].copy(read = true)
        return Result.Success(OkDto(true))
    }
}

class FakeHelperDataSource(private val world: FakeWorld) : HelperDataSource {
    override suspend fun getOpenRequests(): Result<List<HelpRequestDto>, NetworkError> =
        Result.Success(world.requests.toList())

    override suspend fun completeRequest(id: String, helperId: String): Result<HelpRequestDto, NetworkError> {
        delay(LATENCY_MS)
        val req = world.requests.firstOrNull { it.id == id }
            ?: return Result.Error(NetworkError.NOT_FOUND, "That request is already closed.")
        world.completeRequest(id)
        return Result.Success(req.copy(status = "DONE"))
    }

    override suspend fun createReport(
        lat: Double, lon: Double, status: String, reporterId: String,
        note: String?, requestId: String?, photo: ByteArray?,
    ): Result<ReportResponseDto, NetworkError> {
        delay(LATENCY_MS * 2)
        val b = world.addReport(status, note, lat, lon)
        return Result.Success(
            ReportResponseDto(
                reportId = world.nextId("rep"), segmentId = b.segmentId, snapDistanceM = 4.0,
                aiSuggestion = if (photo != null) AiSuggestionDto(status, 0.82) else null,
                verified = true, barrier = b,
            ),
        )
    }
}
