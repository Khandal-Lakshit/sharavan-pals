package com.app.raahi.app.data.mapper

import com.app.raahi.app.domain.model.Role
import com.app.raahi.app.domain.model.User
import com.app.raahi.core.data.remote.dto.UserDto

fun UserDto.toDomain() = User(userId, name, if (role.equals("HELPER", true)) Role.HELPER else Role.USER, badge)
