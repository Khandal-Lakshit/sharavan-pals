package com.app.raahi.app.data.mapper

import com.app.raahi.app.domain.model.BarrierType
import com.app.raahi.app.domain.model.HelpRequest
import com.app.raahi.app.domain.model.ReportResult
import com.app.raahi.core.data.remote.dto.HelpRequestDto
import com.app.raahi.core.data.remote.dto.ReportResponseDto

fun HelpRequestDto.toDomain() = HelpRequest(id, userName, title, polyline.toGeoPoints())

fun ReportResponseDto.toDomain() = ReportResult(
    reportId = reportId,
    segmentId = segmentId,
    snapDistanceM = snapDistanceM,
    aiSuggestion = aiSuggestion?.let { "${BarrierType.fromApi(it.type).label} (${(it.confidence * 100).toInt()}%)" },
    verified = verified,
    barrier = barrier?.toDomain(),
)
