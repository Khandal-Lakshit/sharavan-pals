package com.app.raahi.app.domain.repository

import com.app.raahi.app.domain.model.Role
import com.app.raahi.app.domain.model.User
import com.app.raahi.core.domain.util.NetworkError
import com.app.raahi.core.domain.util.Result

interface AuthRepo {
    suspend fun login(role: Role): Result<User, NetworkError>
}
