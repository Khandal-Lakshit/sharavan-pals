package com.app.raahi.core.data.fake

import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

/**
 * Picks the two routes the user sees: the plain road route, and the shortest road route that keeps clear of every known
 * barrier. Round two moves this onto the backend (Dijkstra with a penalty per barrier type); the idea is the same.
 */
class RoutePlanner(private val osrm: OsrmClient) {

    suspend fun baseline(from: LatLon, to: LatLon): List<LatLon>? = osrm.routes(listOf(from, to)).firstOrNull()

    /**
     * Tries the alternatives OSRM offers first. If every one of them still touches a barrier, it pushes the route away
     * from the barrier by forcing a waypoint 150, 250 then 350 m to either side of it. Best effort: when nothing is
     * clear it returns the candidate with the fewest barriers.
     */
    suspend fun clearOf(from: LatLon, to: LatLon, baseline: List<LatLon>, barriers: List<LatLon>): List<LatLon> {
        fun hits(path: List<LatLon>) = barriers.count { distanceToPath(it, path) <= HIT_M }
        fun cleanest(list: List<List<LatLon>>) = list.filter { hits(it) == 0 }.minByOrNull { lengthM(it) }

        val tried = mutableListOf(baseline)
        tried += osrm.routes(listOf(from, to), alternatives = true)
        cleanest(tried)?.let { return it }

        val middle = pointAlong(baseline, 0.5)
        val pivot = barriers.filter { distanceToPath(it, baseline) <= HIT_M }
            .minByOrNull { metres(it, middle) } ?: return baseline
        for (d in listOf(150.0, 250.0, 350.0)) {
            val found = coroutineScope {
                listOf(1, -1)
                    .map { side -> async { osrm.routes(listOf(from, offsetFrom(pivot, baseline, d, side), to)) } }
                    .awaitAll()
            }.flatten()
            tried += found
            cleanest(found)?.let { return it }
        }
        return tried.minWith(compareBy<List<LatLon>>({ hits(it) }, { lengthM(it) }))
    }
}
