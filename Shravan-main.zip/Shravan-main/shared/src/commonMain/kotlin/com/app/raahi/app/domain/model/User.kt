package com.app.raahi.app.domain.model

enum class Role { USER, HELPER }

data class User(val id: String, val name: String, val role: Role, val badge: String? = null)
