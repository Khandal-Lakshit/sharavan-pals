package com.app.raahi.core.data.remote.source

import com.app.raahi.core.data.networking.constructUrl
import com.app.raahi.core.data.networking.safeCall
import com.app.raahi.core.data.remote.dto.AlertDto
import com.app.raahi.core.data.remote.dto.BookingDto
import com.app.raahi.core.data.remote.dto.BookingRequestDto
import com.app.raahi.core.data.remote.dto.VenueDto
import com.app.raahi.core.data.remote.dto.BarrierDto
import com.app.raahi.core.data.remote.dto.CheckRequestDto
import com.app.raahi.core.data.remote.dto.HelpRequestDto
import com.app.raahi.core.data.remote.dto.OkDto
import com.app.raahi.core.data.remote.dto.PlaceDto
import com.app.raahi.core.data.remote.dto.RouteRequestDto
import com.app.raahi.core.data.remote.dto.RouteResponseDto
import com.app.raahi.core.domain.util.NetworkError
import com.app.raahi.core.domain.util.Result
import io.ktor.client.HttpClient
import io.ktor.client.request.get
import io.ktor.client.request.parameter
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.contentType

class RemoteRouteDataSource(private val httpClient: HttpClient) : RouteDataSource {

    override suspend fun searchPlaces(query: String): Result<List<PlaceDto>, NetworkError> =
        safeCall<List<PlaceDto>> {
            httpClient.get(urlString = constructUrl("/search")) { parameter("q", query) }
        }

    override suspend fun planRoute(body: RouteRequestDto): Result<RouteResponseDto, NetworkError> =
        safeCall<RouteResponseDto> {
            httpClient.post(urlString = constructUrl("/route")) {
                contentType(ContentType.Application.Json)
                setBody(body)
            }
        }

    override suspend fun getBarriers(): Result<List<BarrierDto>, NetworkError> =
        safeCall<List<BarrierDto>> { httpClient.get(urlString = constructUrl("/barriers")) }

    override suspend fun createCheckRequest(body: CheckRequestDto): Result<HelpRequestDto, NetworkError> =
        safeCall<HelpRequestDto> {
            httpClient.post(urlString = constructUrl("/route-requests")) {
                contentType(ContentType.Application.Json)
                setBody(body)
            }
        }

    override suspend fun getAlerts(userId: String): Result<List<AlertDto>, NetworkError> =
        safeCall<List<AlertDto>> {
            httpClient.get(urlString = constructUrl("/notifications")) { parameter("userId", userId) }
        }

    override suspend fun markAlertRead(id: String): Result<OkDto, NetworkError> =
        safeCall<OkDto> { httpClient.post(urlString = constructUrl("/notifications/$id/read")) }

    override suspend fun getVenues(): Result<List<VenueDto>, NetworkError> =
        safeCall<List<VenueDto>> { httpClient.get(urlString = constructUrl("/venues")) }

    override suspend fun createBooking(body: BookingRequestDto): Result<BookingDto, NetworkError> =
        safeCall<BookingDto> {
            httpClient.post(urlString = constructUrl("/bookings")) {
                contentType(ContentType.Application.Json)
                setBody(body)
            }
        }

    override suspend fun getBookings(userId: String): Result<List<BookingDto>, NetworkError> =
        safeCall<List<BookingDto>> {
            httpClient.get(urlString = constructUrl("/bookings")) { parameter("userId", userId) }
        }

    override suspend fun cancelBooking(id: String): Result<BookingDto, NetworkError> =
        safeCall<BookingDto> { httpClient.post(urlString = constructUrl("/bookings/$id/cancel")) }
}
