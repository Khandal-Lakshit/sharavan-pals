package com.app.raahi.app.domain.model

data class HelpRequest(
    val id: String,
    val userName: String,
    val title: String,
    val polyline: List<GeoPoint>,
)

class ReportDraft(
    val point: GeoPoint,
    val status: BarrierType,
    val note: String,
    val requestId: String?,
    val photo: ByteArray?,
)

data class ReportResult(
    val reportId: String,
    val segmentId: String,
    val snapDistanceM: Double,
    val aiSuggestion: String?,
    val verified: Boolean,
    val barrier: Barrier?,
)
