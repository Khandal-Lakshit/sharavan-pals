package com.app.raahi.app.domain.repository

import com.app.raahi.app.domain.model.Alert
import com.app.raahi.app.domain.model.Barrier
import com.app.raahi.app.domain.model.Booking
import com.app.raahi.app.domain.model.HelpKind
import com.app.raahi.app.domain.model.Venue
import com.app.raahi.app.domain.model.GeoPoint
import com.app.raahi.app.domain.model.HelpRequest
import com.app.raahi.app.domain.model.Place
import com.app.raahi.app.domain.model.RoutePlan
import com.app.raahi.core.domain.util.NetworkError
import com.app.raahi.core.domain.util.Result
import kotlinx.coroutines.flow.Flow

interface RouteRepo {
    suspend fun searchPlaces(query: String): Result<List<Place>, NetworkError>
    suspend fun planRoute(from: GeoPoint, to: GeoPoint, userId: String?): Result<RoutePlan, NetworkError>
    suspend fun requestRouteCheck(userId: String, from: GeoPoint, to: GeoPoint, title: String): Result<HelpRequest, NetworkError>
    suspend fun markAlertRead(id: String): Result<Unit, NetworkError>
    suspend fun getVenues(): Result<List<Venue>, NetworkError>
    suspend fun bookHelper(userId: String, kind: HelpKind, destination: String, slot: String, note: String, minutes: Int): Result<Booking, NetworkError>
    suspend fun getBookings(userId: String): Result<List<Booking>, NetworkError>
    suspend fun cancelBooking(id: String): Result<Booking, NetworkError>

    /** The prototype backend has no push, so this repository Flow polls every few seconds. */
    fun observeAlerts(userId: String): Flow<Result<List<Alert>, NetworkError>>

    /** Every reported barrier, for the Home map. Polls like alerts until the backend has push. */
    fun observeBarriers(): Flow<Result<List<Barrier>, NetworkError>>
}
