package com.app.raahi.core.data.remote.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable data class PointDto(val lat: Double, val lon: Double)
@Serializable data class PlaceDto(val name: String, val lat: Double, val lon: Double)

@Serializable
data class RouteRequestDto(
    @SerialName("from") val origin: PointDto,
    val to: PointDto,
    val userId: String? = null,
)

@Serializable
data class BarrierDto(
    val id: String,
    val type: String,
    val lat: Double,
    val lon: Double,
    val segmentId: String,
    val confidence: Double = 1.0,
    val verified: Boolean = false,
    val imageUrl: String? = null,
    val note: String? = null,
    val reporterName: String? = null,
    val reporterBadge: String? = null,
    val createdAt: String? = null,
    val expiresAt: String? = null,
)

@Serializable data class SegmentImageryDto(val segmentId: String, val ageDays: Int? = null)
@Serializable data class StepDto(val text: String, val distanceM: Int = 0)

@Serializable
data class RouteLegDto(
    val polyline: List<List<Double>>,
    val distanceM: Int,
    val durationMin: Int,
    val barriers: List<BarrierDto> = emptyList(),
    val steps: List<StepDto> = emptyList(),
    val imagery: List<SegmentImageryDto> = emptyList(),
)

@Serializable
data class RouteResponseDto(
    val routeId: String,
    val baseline: RouteLegDto,
    val safe: RouteLegDto,
    val extraDistanceM: Int = 0,
)

@Serializable data class RerouteDto(val extraDistanceM: Int = 0, val newDistanceM: Int = 0)

@Serializable
data class AlertDto(
    val id: String,
    val userId: String,
    val type: String,
    val segmentId: String? = null,
    val reportId: String? = null,
    val message: String,
    val createdAt: String,
    val read: Boolean = false,
    val reroute: RerouteDto? = null,
    /** What was reported, when this alert is about a barrier on the user's route. */
    val barrier: BarrierDto? = null,
    /** Who sent it, for example the helper who reported or checked. */
    val senderName: String? = null,
    val senderBadge: String? = null,
    /** Where it is, in words, for example "Your route: Bus stop to Metro station". */
    val placeLabel: String? = null,
)

@Serializable
data class CheckRequestDto(
    @SerialName("from") val origin: PointDto,
    val to: PointDto,
    val userId: String,
    val title: String? = null,
)

@Serializable
data class VerificationDto(val videoTopics: List<String> = emptyList(), val qaDone: Int = 0, val qaTotal: Int = 12)

@Serializable
data class ReviewDto(
    val id: String,
    val author: String,
    val need: String = "",
    val rating: Int = 5,
    val text: String = "",
    val whenLabel: String = "",
)

@Serializable
data class VenueDto(
    val id: String,
    val name: String,
    val category: String,
    val lat: Double,
    val lon: Double,
    val address: String = "",
    val features: List<String> = emptyList(),
    val rating: Double = 0.0,
    val note: String = "",
    val verification: VerificationDto = VerificationDto(),
    val reviews: List<ReviewDto> = emptyList(),
)

@Serializable
data class BookingRequestDto(
    val userId: String,
    val kind: String,
    val destination: String,
    val slot: String,
    val note: String,
    val minutes: Int = 60,
)

@Serializable
data class BookingDto(
    val id: String,
    val userId: String = "",
    val helperName: String,
    val helperBadge: String? = null,
    val kind: String = "TRAVEL",
    val destination: String = "",
    val slot: String,
    val note: String = "",
    val status: String = "CONFIRMED",
    val minutes: Int = 60,
    val price: Int = 199,
)
