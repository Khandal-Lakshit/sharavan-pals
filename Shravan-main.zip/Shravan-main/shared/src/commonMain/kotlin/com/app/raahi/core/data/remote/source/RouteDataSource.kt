package com.app.raahi.core.data.remote.source

import com.app.raahi.core.data.remote.dto.AlertDto
import com.app.raahi.core.data.remote.dto.BookingDto
import com.app.raahi.core.data.remote.dto.BookingRequestDto
import com.app.raahi.core.data.remote.dto.VenueDto
import com.app.raahi.core.data.remote.dto.BarrierDto
import com.app.raahi.core.data.remote.dto.CheckRequestDto
import com.app.raahi.core.data.remote.dto.HelpRequestDto
import com.app.raahi.core.data.remote.dto.OkDto
import com.app.raahi.core.data.remote.dto.PlaceDto
import com.app.raahi.core.data.remote.dto.RouteRequestDto
import com.app.raahi.core.data.remote.dto.RouteResponseDto
import com.app.raahi.core.domain.util.NetworkError
import com.app.raahi.core.domain.util.Result

interface RouteDataSource {
    suspend fun searchPlaces(query: String): Result<List<PlaceDto>, NetworkError>
    suspend fun planRoute(body: RouteRequestDto): Result<RouteResponseDto, NetworkError>
    suspend fun getBarriers(): Result<List<BarrierDto>, NetworkError>
    suspend fun createCheckRequest(body: CheckRequestDto): Result<HelpRequestDto, NetworkError>
    suspend fun getAlerts(userId: String): Result<List<AlertDto>, NetworkError>
    suspend fun markAlertRead(id: String): Result<OkDto, NetworkError>
    suspend fun getVenues(): Result<List<VenueDto>, NetworkError>
    suspend fun createBooking(body: BookingRequestDto): Result<BookingDto, NetworkError>
    suspend fun getBookings(userId: String): Result<List<BookingDto>, NetworkError>
    suspend fun cancelBooking(id: String): Result<BookingDto, NetworkError>
}
