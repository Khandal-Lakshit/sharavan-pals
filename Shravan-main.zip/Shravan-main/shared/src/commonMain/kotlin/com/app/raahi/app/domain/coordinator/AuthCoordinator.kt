package com.app.raahi.app.domain.coordinator

import com.app.raahi.app.domain.model.Role
import com.app.raahi.app.Events
import com.app.raahi.app.StateReflector
import com.app.raahi.app.domain.usecase.authusecase.AuthUseCases
import com.app.raahi.app.fluxdeck.AuthFluxDeck
import com.app.raahi.app.handleResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

class AuthCoordinator(
    private val authUseCases: AuthUseCases,
    private val fluxDeck: AuthFluxDeck,
    private val scope: CoroutineScope,
) {
    val reflector = StateReflector<Events>(scope)
    val events = reflector.events

    fun login(role: Role) {
        scope.launch {
            if (fluxDeck.isLoading.value) return@launch
            fluxDeck.setLoading(true)
            reflector.handleResult(authUseCases.loginUseCase(role)) { user -> fluxDeck.setUser(user) }
            fluxDeck.setLoading(false)
        }
    }

    fun logout() {
        fluxDeck.setUser(null)
    }

}
