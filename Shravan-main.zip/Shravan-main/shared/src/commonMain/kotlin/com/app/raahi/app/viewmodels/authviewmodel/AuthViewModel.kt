package com.app.raahi.app.viewmodels.authviewmodel

import androidx.lifecycle.ViewModel
import com.app.raahi.app.domain.coordinator.AuthCoordinator
import com.app.raahi.app.domain.model.Role
import com.app.raahi.app.fluxdeck.AuthFluxDeck
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AuthViewModel(
    private val coordinator: AuthCoordinator,
    private val fluxDeck: AuthFluxDeck,
) : ViewModel() {

    // ephemeral screen state
    private val _onboardingDone = MutableStateFlow(false)
    val onboardingDone: StateFlow<Boolean> = _onboardingDone.asStateFlow()

    val events = coordinator.events
    val user = fluxDeck.user
    val isLoading = fluxDeck.isLoading

    fun finishOnboarding() { _onboardingDone.value = true }
    fun login(role: Role) = coordinator.login(role)
    fun logout() = coordinator.logout()
}
