package com.app.raahi.core.domain.util

expect fun logError(message: String, throwable: Throwable? = null)
expect fun logDebug(message: String)
