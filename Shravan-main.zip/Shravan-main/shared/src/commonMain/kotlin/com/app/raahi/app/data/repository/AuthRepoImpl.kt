package com.app.raahi.app.data.repository

import com.app.raahi.app.data.mapper.toDomain
import com.app.raahi.app.domain.model.Role
import com.app.raahi.app.domain.model.User
import com.app.raahi.app.domain.repository.AuthRepo
import com.app.raahi.core.data.remote.source.AuthDataSource
import com.app.raahi.core.domain.util.NetworkError
import com.app.raahi.core.domain.util.Result
import com.app.raahi.core.domain.util.map

class AuthRepoImpl(private val remote: AuthDataSource) : AuthRepo {
    override suspend fun login(role: Role): Result<User, NetworkError> =
        remote.login(role.name).map { it.toDomain() }
}
