package com.app.raahi.app.domain.model

/** Exact status values the backend understands. [short] is drawn on the map so meaning never relies on colour. */
enum class BarrierType(val label: String, val symbol: String, val short: String) {
    STEPS("Steps", "🪜", "STEPS"),
    MISSING_KERB_RAMP("No kerb ramp", "⛔", "NO RAMP"),
    BROKEN_SURFACE("Broken surface", "🕳", "BROKEN"),
    MISSING_FOOTPATH("No footpath", "🚧", "NO PATH"),
    POLE_OBSTRUCTION("Pole in the way", "📍", "POLE"),
    PARKED_VEHICLE("Parked vehicle", "🚗", "VEHICLE"),
    HEAVY_TRAFFIC("Heavy traffic", "🚦", "TRAFFIC"),
    TEMP_BLOCKED("Blocked right now", "⛔", "BLOCKED"),
    CROWDED("Crowded", "👥", "CROWD"),
    CLEAR("All clear", "✅", "CLEAR");

    companion object {
        fun fromApi(value: String): BarrierType = entries.firstOrNull { it.name == value } ?: BROKEN_SURFACE
    }
}

data class GeoPoint(val lat: Double, val lon: Double)

data class Barrier(
    val id: String,
    val type: BarrierType,
    val point: GeoPoint,
    val segmentId: String,
    val confidence: Double,
    val verified: Boolean,
    val imageUrl: String?,
    val note: String?,
    val reporterName: String? = null,
    val reporterBadge: String? = null,
)
