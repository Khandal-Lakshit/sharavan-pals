package com.app.raahi.app.data.mapper

import com.app.raahi.app.domain.model.Alert
import com.app.raahi.app.domain.model.Booking
import com.app.raahi.app.domain.model.HelpKind
import com.app.raahi.app.domain.model.BookingStatus
import com.app.raahi.app.domain.model.Venue
import com.app.raahi.app.domain.model.VenueCategory
import com.app.raahi.app.domain.model.AlertType
import com.app.raahi.app.domain.model.Barrier
import com.app.raahi.app.domain.model.BarrierType
import com.app.raahi.app.domain.model.GeoPoint
import com.app.raahi.app.domain.model.Place
import com.app.raahi.app.domain.model.Verification
import com.app.raahi.app.domain.model.VenueReview
import com.app.raahi.app.domain.model.RouteImagery
import com.app.raahi.app.domain.model.RouteLeg
import com.app.raahi.app.domain.model.RoutePlan
import com.app.raahi.app.domain.model.RouteStep
import com.app.raahi.app.domain.model.SegmentImagery
import com.app.raahi.core.data.networking.constructUrl
import com.app.raahi.core.data.remote.dto.AlertDto
import com.app.raahi.core.data.remote.dto.BarrierDto
import com.app.raahi.core.data.remote.dto.BookingDto
import com.app.raahi.core.data.remote.dto.PlaceDto
import com.app.raahi.core.data.remote.dto.VenueDto
import com.app.raahi.core.data.remote.dto.RouteLegDto
import com.app.raahi.core.data.remote.dto.RouteResponseDto

internal fun List<List<Double>>.toGeoPoints() = map { GeoPoint(it[0], it[1]) }

fun PlaceDto.toDomain() = Place(name, GeoPoint(lat, lon))

/** "/uploads/x.jpg" -> full URL on the current server (constructUrl keeps absolute URLs unchanged). */
fun BarrierDto.toDomain() = Barrier(
    id = id,
    type = BarrierType.fromApi(type),
    point = GeoPoint(lat, lon),
    segmentId = segmentId,
    confidence = confidence,
    verified = verified,
    imageUrl = imageUrl?.let { constructUrl(it) },
    note = note,
    reporterName = reporterName,
    reporterBadge = reporterBadge,
)

fun RouteLegDto.toDomain() = RouteLeg(
    polyline = polyline.toGeoPoints(),
    distanceM = distanceM,
    durationMin = durationMin,
    barriers = barriers.map { it.toDomain() },
    steps = steps.map { RouteStep(it.text, it.distanceM) },
    imagery = RouteImagery.from(imagery.map { SegmentImagery(it.segmentId, it.ageDays) }),
)

fun RouteResponseDto.toDomain() = RoutePlan(routeId, baseline.toDomain(), safe.toDomain(), extraDistanceM)

fun AlertDto.toDomain() = Alert(
    id = id,
    type = when (type) {
        "ROUTE_ISSUE" -> AlertType.ROUTE_ISSUE
        "ROUTE_CHECKED" -> AlertType.ROUTE_CHECKED
        else -> AlertType.OTHER
    },
    message = message,
    createdAt = createdAt,
    isRead = read,
    extraDistanceM = reroute?.extraDistanceM,
    barrier = barrier?.toDomain(),
    senderName = senderName ?: barrier?.reporterName,
    senderBadge = senderBadge ?: barrier?.reporterBadge,
    placeLabel = placeLabel,
)

fun VenueDto.toDomain() = Venue(
    id = id, name = name, category = VenueCategory.fromApi(category), point = GeoPoint(lat, lon),
    address = address, features = features, rating = rating, note = note,
    verification = Verification(verification.videoTopics, verification.qaDone, verification.qaTotal),
    reviews = reviews.map { VenueReview(it.id, it.author, it.need, it.rating, it.text, it.whenLabel) },
)

fun BookingDto.toDomain() = Booking(
    id = id, helperName = helperName, helperBadge = helperBadge,
    kind = HelpKind.fromApi(kind), destination = destination, slot = slot, note = note,
    status = if (status == "CANCELLED") BookingStatus.CANCELLED else BookingStatus.CONFIRMED,
    minutes = minutes, price = price,
)
