package com.app.raahi.app.domain.model

enum class AlertType { ROUTE_ISSUE, ROUTE_CHECKED, OTHER }

data class Alert(
    val id: String,
    val type: AlertType,
    val message: String,
    val createdAt: String,
    val isRead: Boolean,
    val extraDistanceM: Int?,
    val barrier: Barrier? = null,
    val senderName: String? = null,
    val senderBadge: String? = null,
    val placeLabel: String? = null,
)
