package com.app.raahi.app.data.repository

import com.app.raahi.app.domain.model.ChatMessage
import com.app.raahi.app.domain.model.CommunityGroup
import com.app.raahi.app.domain.model.GroupMember
import com.app.raahi.app.domain.repository.CommunityRepo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class CommunityRepoImpl : CommunityRepo {

    private val defaultMembers = listOf(
        GroupMember("u1", "Asha (You)", "Shravan Traveler · Member", isMe = true, isVerified = true),
        GroupMember("u2", "Ravi Driver", "Verified Helping Hand · Group Admin", isMe = false, isVerified = true),
        GroupMember("u3", "Meera NGO", "Jaipur NGO Coordinator", isMe = false, isVerified = true),
        GroupMember("u4", "Dr. Sharma", "Medical Consultant", isMe = false, isVerified = true),
        GroupMember("u5", "Sanjay Gupta", "Barrier Auditor", isMe = false, isVerified = true),
        GroupMember("u6", "Pooja Verma", "Active Traveler", isMe = false, isVerified = false),
    )

    private val defaultGroups = listOf(
        CommunityGroup(
            id = "c1",
            name = "Jaipur Barrier-Free Travelers",
            description = "Community for sharing accessible routes, ramp updates, and daily travel tips across Jaipur.",
            symbol = "🧭",
            memberCount = 142,
            unreadCount = 2,
            lastMessage = "Ravi: The ramp near Jawahar Circle bus stop is cleared and ready!",
            members = defaultMembers,
        ),
        CommunityGroup(
            id = "c2",
            name = "Shravan Wheelchair Circle",
            description = "Wheelchair users & caretaker network discussing power wheelchair battery points and accessible places.",
            symbol = "♿",
            memberCount = 98,
            unreadCount = 1,
            lastMessage = "Asha: Central Park main gate has a smooth wide entrance now.",
            members = defaultMembers,
        ),
        CommunityGroup(
            id = "c3",
            name = "Verified Helpers Network",
            description = "Drivers and NGO volunteers coordinating barrier verification and helping hand assistance.",
            symbol = "🤝",
            memberCount = 64,
            unreadCount = 0,
            lastMessage = "Meera: Verified 3 new reports near Metro station.",
            members = defaultMembers,
        ),
    )

    private val defaultMessages = mapOf(
        "c1" to listOf(
            ChatMessage("m1", "c1", "Ravi Driver", "R", "Hello everyone! The ramp near Jawahar Circle bus stop is cleared and open now.", "10:15 AM", false),
            ChatMessage("m2", "c1", "Asha", "A", "That's fantastic news! Thanks Ravi for checking so quickly.", "10:18 AM", true),
            ChatMessage("m3", "c1", "Meera NGO", "M", "If anyone needs assistance near the Metro station today, I'll be around until 5 PM.", "10:30 AM", false),
        ),
        "c2" to listOf(
            ChatMessage("m4", "c2", "Asha", "A", "Central Park main gate has a smooth wide entrance now.", "09:45 AM", true),
            ChatMessage("m5", "c2", "Vikram", "V", "Thanks Asha! Is the side path step-free as well?", "09:50 AM", false),
        ),
        "c3" to listOf(
            ChatMessage("m6", "c3", "Meera NGO", "M", "Verified 3 new reports near Metro station.", "Yesterday", false),
            ChatMessage("m7", "c3", "Ravi Driver", "R", "I can check the Jawahar Circle segment tomorrow morning.", "Yesterday", false),
        )
    )

    private val _groups = MutableStateFlow(defaultGroups)
    override val groups: StateFlow<List<CommunityGroup>> = _groups.asStateFlow()

    private val _messages = MutableStateFlow(defaultMessages)
    override val messages: StateFlow<Map<String, List<ChatMessage>>> = _messages.asStateFlow()

    private var msgCounter = 100

    override fun sendMessage(groupId: String, text: String, senderName: String) {
        if (text.isBlank()) return
        val newMessage = ChatMessage(
            id = "m_${msgCounter++}",
            groupId = groupId,
            senderName = if (senderName.isBlank()) "You" else senderName,
            senderAvatar = if (senderName.isBlank()) "Y" else senderName.first().uppercase(),
            text = text,
            timestamp = "Just now",
            isMe = true,
        )
        val current = _messages.value.toMutableMap()
        val list = (current[groupId] ?: emptyList()) + newMessage
        current[groupId] = list
        _messages.value = current

        // Update last message in group
        val groupList = _groups.value.map { g ->
            if (g.id == groupId) g.copy(lastMessage = "${newMessage.senderName}: ${newMessage.text}") else g
        }
        _groups.value = groupList
    }

    override fun markGroupRead(groupId: String) {
        val groupList = _groups.value.map { g ->
            if (g.id == groupId) g.copy(unreadCount = 0) else g
        }
        _groups.value = groupList
    }
}
