package com.app.raahi.app.fluxdeck

import com.app.raahi.app.domain.model.Barrier
import com.app.raahi.app.domain.model.BarrierType
import com.app.raahi.app.domain.model.GeoPoint
import com.app.raahi.app.domain.model.HelpRequest
import com.app.raahi.app.domain.model.ReportDraft
import com.app.raahi.app.domain.model.ReportResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map

/** Model for the helper's "walk the route and report" feature. The report draft lives here. */
class HelperFluxDeck {
    private val _submitIntent = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val submitIntent = _submitIntent.asSharedFlow()

    private val _requests = MutableStateFlow<List<HelpRequest>>(emptyList())
    val requests: StateFlow<List<HelpRequest>> = _requests.asStateFlow()

    private val _selectedRequestId = MutableStateFlow<String?>(null)
    val selectedRequestId: StateFlow<String?> = _selectedRequestId.asStateFlow()

    /** Requests the helper has already seen the alert card for (accepted or "Later"). */
    private val _dismissedAlertIds = MutableStateFlow<Set<String>>(emptySet())

    private val _barriers = MutableStateFlow<List<Barrier>>(emptyList())
    val barriers: StateFlow<List<Barrier>> = _barriers.asStateFlow()

    private val _location = MutableStateFlow<GeoPoint?>(null)
    val location: StateFlow<GeoPoint?> = _location.asStateFlow()

    private val _status = MutableStateFlow<BarrierType?>(null)
    val status: StateFlow<BarrierType?> = _status.asStateFlow()

    private val _note = MutableStateFlow("")
    val note: StateFlow<String> = _note.asStateFlow()

    private val _photo = MutableStateFlow<ByteArray?>(null)
    val photo: StateFlow<ByteArray?> = _photo.asStateFlow()

    private val _isSubmitting = MutableStateFlow(false)
    val isSubmitting: StateFlow<Boolean> = _isSubmitting.asStateFlow()

    private val _lastResult = MutableStateFlow<ReportResult?>(null)
    val lastResult: StateFlow<ReportResult?> = _lastResult.asStateFlow()

    // ---- Formulas ----
    val selectedRequest: Flow<HelpRequest?> = combine(_requests, _selectedRequestId) { list, id ->
        list.firstOrNull { it.id == id }
    }

    /** The newest request the helper has not acknowledged yet: "this person needs help around here". */
    val incomingAlert: Flow<HelpRequest?> = combine(_requests, _dismissedAlertIds) { list, seen ->
        list.firstOrNull { it.id !in seen }
    }

    val requestedRoute: Flow<List<GeoPoint>> = selectedRequest.map { it?.polyline.orEmpty() }

    val canSubmit: Flow<Boolean> = combine(_location, _status, _isSubmitting) { loc, st, busy ->
        loc != null && st != null && !busy
    }

    // ---- intents ----
    fun submit() { _submitIntent.tryEmit(Unit) }

    // ---- state writers ----
    fun updateRequests(list: List<HelpRequest>) {
        _requests.value = list
        if (_selectedRequestId.value !in list.map { it.id }) _selectedRequestId.value = null
    }

    fun selectRequest(id: String?) { _selectedRequestId.value = id }
    fun dismissAlert(id: String) { _dismissedAlertIds.value = _dismissedAlertIds.value + id }
    fun updateBarriers(list: List<Barrier>) { _barriers.value = list }
    fun updateLocation(point: GeoPoint?) { _location.value = point }
    fun updateStatus(type: BarrierType?) { _status.value = type }
    fun updateNote(text: String) { _note.value = text }
    fun updatePhoto(bytes: ByteArray?) { _photo.value = bytes }
    fun setSubmitting(value: Boolean) { _isSubmitting.value = value }
    fun updateLastResult(result: ReportResult?) { _lastResult.value = result }

    fun currentDraft(): ReportDraft? {
        val loc = _location.value ?: return null
        val st = _status.value ?: return null
        return ReportDraft(loc, st, _note.value, _selectedRequestId.value, _photo.value)
    }

    fun clearDraft() { _status.value = null; _note.value = ""; _photo.value = null }

    fun clear() {
        _requests.value = emptyList(); _selectedRequestId.value = null; _dismissedAlertIds.value = emptySet(); _barriers.value = emptyList()
        _location.value = null; clearDraft(); _isSubmitting.value = false; _lastResult.value = null
    }
}
