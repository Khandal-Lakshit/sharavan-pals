package com.app.raahi.core.data.fake

import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/** latitude to longitude */
typealias LatLon = Pair<Double, Double>

/** A barrier closer than this to a route counts as being on it. */
internal const val HIT_M = 25.0

private const val EARTH_R = 6_371_000.0
private const val M_PER_DEG_LAT = 111_320.0

internal fun metres(a: LatLon, b: LatLon): Double {
    fun rad(d: Double) = d * PI / 180.0
    val dLat = rad(b.first - a.first)
    val dLon = rad(b.second - a.second)
    val h = sin(dLat / 2) * sin(dLat / 2) + cos(rad(a.first)) * cos(rad(b.first)) * sin(dLon / 2) * sin(dLon / 2)
    return 2 * EARTH_R * atan2(sqrt(h), sqrt(1 - h))
}

internal fun lengthM(path: List<LatLon>): Int = path.zipWithNext { a, b -> metres(a, b) }.sum().roundToInt()

/** Index of the path segment closest to [p], and the distance to it in metres. */
private fun nearestSegment(p: LatLon, path: List<LatLon>): Pair<Int, Double> {
    val mLon = M_PER_DEG_LAT * cos(p.first * PI / 180.0)
    var bestIndex = 0
    var best = Double.MAX_VALUE
    for (i in 0 until path.size - 1) {
        val ax = (path[i].second - p.second) * mLon
        val ay = (path[i].first - p.first) * M_PER_DEG_LAT
        val bx = (path[i + 1].second - p.second) * mLon
        val by = (path[i + 1].first - p.first) * M_PER_DEG_LAT
        val dx = bx - ax
        val dy = by - ay
        val len2 = dx * dx + dy * dy
        val t = if (len2 == 0.0) 0.0 else ((-ax * dx - ay * dy) / len2).coerceIn(0.0, 1.0)
        val d = hypot(ax + t * dx, ay + t * dy)
        if (d < best) { best = d; bestIndex = i }
    }
    return bestIndex to best
}

/** Shortest distance in metres from [p] to the polyline. */
internal fun distanceToPath(p: LatLon, path: List<LatLon>): Double = when {
    path.isEmpty() -> Double.MAX_VALUE
    path.size == 1 -> metres(p, path[0])
    else -> nearestSegment(p, path).second
}

/** The point [fraction] (0..1) of the way along the path. */
internal fun pointAlong(path: List<LatLon>, fraction: Double): LatLon {
    if (path.size < 2) return path.first()
    var remaining = path.zipWithNext { a, b -> metres(a, b) }.sum() * fraction.coerceIn(0.0, 1.0)
    for (i in 0 until path.size - 1) {
        val seg = metres(path[i], path[i + 1])
        if (remaining <= seg || i == path.size - 2) {
            val t = if (seg == 0.0) 0.0 else min(1.0, remaining / seg)
            return (path[i].first + (path[i + 1].first - path[i].first) * t) to
                (path[i].second + (path[i + 1].second - path[i].second) * t)
        }
        remaining -= seg
    }
    return path.last()
}

/** A point [distanceM] away from [p], at right angles to the path where it passes [p]. [side] is 1 or -1. */
internal fun offsetFrom(p: LatLon, path: List<LatLon>, distanceM: Double, side: Int): LatLon {
    if (path.size < 2) return p
    val i = nearestSegment(p, path).first
    val mLon = M_PER_DEG_LAT * cos(p.first * PI / 180.0)
    val dx = (path[i + 1].second - path[i].second) * mLon     // east
    val dy = (path[i + 1].first - path[i].first) * M_PER_DEG_LAT // north
    val len = hypot(dx, dy)
    if (len == 0.0) return p
    val px = -dy / len * side   // perpendicular, east
    val py = dx / len * side    // perpendicular, north
    return (p.first + py * distanceM / M_PER_DEG_LAT) to (p.second + px * distanceM / mLon)
}
