package com.app.raahi.core.data.fake

import com.app.raahi.core.domain.util.logError
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.parameter
import io.ktor.http.HttpHeaders
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.serialization.Serializable

@Serializable private class OsrmGeometry(val coordinates: List<List<Double>> = emptyList())
@Serializable private class OsrmRoute(val geometry: OsrmGeometry = OsrmGeometry())
@Serializable private class OsrmResponse(val code: String = "", val routes: List<OsrmRoute> = emptyList())

/**
 * Round-one stand-in for the Raahi backend's routing: asks the public OpenStreetMap (OSRM) demo server for the real
 * road geometry between any points. Needs internet. Returns an empty list when it can't be reached.
 */
class OsrmClient(private val http: HttpClient) {

    /** Tries twice: the free demo server sometimes drops a request when several arrive close together. */
    suspend fun routes(stops: List<LatLon>, alternatives: Boolean = false): List<List<LatLon>> {
        repeat(2) { attempt ->
            val found = fetch(stops, alternatives)
            if (found.isNotEmpty()) return found
            if (attempt == 0) delay(700)
        }
        return emptyList()
    }

    private suspend fun fetch(stops: List<LatLon>, alternatives: Boolean): List<List<LatLon>> {
        val coords = stops.joinToString(";") { "${it.second},${it.first}" }
        return try {
            val response: OsrmResponse = http.get("$BASE/$coords") {
                header(HttpHeaders.UserAgent, "Raahi-prototype")
                parameter("overview", "full")
                parameter("geometries", "geojson")
                if (alternatives) parameter("alternatives", "3")
            }.body()
            response.routes.map { route -> route.geometry.coordinates.filter { it.size >= 2 }.map { it[1] to it[0] } }
                .filter { it.size >= 2 }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            logError("OSRM request failed", e)
            emptyList()
        }
    }

    private companion object {
        const val BASE = "https://router.project-osrm.org/route/v1/foot"
    }
}
