package com.app.raahi.core.data.remote.source

import com.app.raahi.core.data.networking.constructUrl
import com.app.raahi.core.data.networking.safeCall
import com.app.raahi.core.data.remote.dto.LoginRequestDto
import com.app.raahi.core.data.remote.dto.UserDto
import com.app.raahi.core.domain.util.NetworkError
import com.app.raahi.core.domain.util.Result
import io.ktor.client.HttpClient
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.contentType

class RemoteAuthDataSource(private val httpClient: HttpClient) : AuthDataSource {
    override suspend fun login(role: String): Result<UserDto, NetworkError> = safeCall<UserDto> {
        httpClient.post(urlString = constructUrl("/login/demo")) {
            contentType(ContentType.Application.Json)
            setBody(LoginRequestDto(role))
        }
    }
}
