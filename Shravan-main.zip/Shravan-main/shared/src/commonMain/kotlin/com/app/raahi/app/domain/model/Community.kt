package com.app.raahi.app.domain.model

data class GroupMember(
    val id: String,
    val name: String,
    val role: String,
    val isMe: Boolean = false,
    val isVerified: Boolean = true,
)

data class CommunityGroup(
    val id: String,
    val name: String,
    val description: String,
    val symbol: String,
    val memberCount: Int,
    val unreadCount: Int = 0,
    val lastMessage: String = "",
    val members: List<GroupMember> = emptyList(),
)

data class ChatMessage(
    val id: String,
    val groupId: String,
    val senderName: String,
    val senderAvatar: String,
    val text: String,
    val timestamp: String,
    val isMe: Boolean = false,
)
