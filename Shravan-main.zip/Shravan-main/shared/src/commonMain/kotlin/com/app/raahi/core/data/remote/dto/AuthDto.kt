package com.app.raahi.core.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable data class LoginRequestDto(val role: String)
@Serializable data class UserDto(val userId: String, val name: String, val role: String, val badge: String? = null)
@Serializable data class OkDto(val ok: Boolean = true)
