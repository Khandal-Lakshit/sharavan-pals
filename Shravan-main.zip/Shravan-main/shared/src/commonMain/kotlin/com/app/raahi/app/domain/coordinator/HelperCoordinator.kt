package com.app.raahi.app.domain.coordinator

import com.app.raahi.app.Events
import com.app.raahi.app.StateReflector
import com.app.raahi.app.domain.model.Role
import com.app.raahi.app.domain.model.User
import com.app.raahi.app.domain.usecase.helperusecase.HelperUseCases
import com.app.raahi.app.fluxdeck.AuthFluxDeck
import com.app.raahi.app.fluxdeck.HelperFluxDeck
import com.app.raahi.app.handleResult
import com.app.raahi.core.domain.util.NetworkError
import com.app.raahi.core.domain.util.Result
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/** Operation layer for the helper feature. Idle until a HELPER logs in; cleared on logout. */
class HelperCoordinator(
    private val helperUseCases: HelperUseCases,
    private val fluxDeck: HelperFluxDeck,
    private val authFluxDeck: AuthFluxDeck,
    private val scope: CoroutineScope,
) {
    val reflector = StateReflector<Events>(scope)
    val events = reflector.events

    init {
        sync()
        scope.launch { fluxDeck.submitIntent.collect { submit() } }
    }

    private fun sync() {
        scope.launch {
            authFluxDeck.user
                .map { it?.takeIf { u -> u.role == Role.HELPER } }
                .distinctUntilChanged()
                .collectLatest { user ->
                    fluxDeck.clear()
                    if (user != null) runFor()
                }
        }
    }

    private suspend fun runFor() = coroutineScope {
        launch {
            helperUseCases.observeBarriers().collect { result ->
                if (result is Result.Success) fluxDeck.updateBarriers(result.data)   // FluxDeck follows the Repo Flow
            }
        }
        launch {
            helperUseCases.observeOpenRequests().collect { result ->
                if (result is Result.Success) fluxDeck.updateRequests(result.data)   // polling errors stay silent
            }
        }
    }

    private suspend fun submit() {
        val user: User = authFluxDeck.user.value ?: return
        val draft = fluxDeck.currentDraft()
        if (draft == null) {
            reflector.emitEvent(Events.Error(NetworkError.BAD_REQUEST, "Set your location and pick what you see first"))
            return
        }
        if (fluxDeck.isSubmitting.value) return
        fluxDeck.setSubmitting(true)
        reflector.handleResult(helperUseCases.submitReport(user.id, draft)) { result ->
            fluxDeck.updateLastResult(result)
            fluxDeck.clearDraft()
            reflector.emitEvent(Events.Success("Report saved and matched to the footpath"))
        }
        fluxDeck.setSubmitting(false)
    }

    fun markRouteChecked() {
        scope.launch { completeSelectedRequest() }
    }

    private suspend fun completeSelectedRequest() {
        val user = authFluxDeck.user.value ?: return
        val id = fluxDeck.selectedRequestId.value
        if (id == null) {
            reflector.emitEvent(Events.Error(NetworkError.BAD_REQUEST, "Select a route request first"))
            return
        }
        reflector.handleResult(helperUseCases.completeRouteCheck(id, user.id)) {
            fluxDeck.selectRequest(null)
            reflector.emitEvent(Events.Success("Route marked as checked. The user has been told."))
        }
    }
}
