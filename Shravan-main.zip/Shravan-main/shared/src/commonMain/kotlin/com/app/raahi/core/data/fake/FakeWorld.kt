package com.app.raahi.core.data.fake

import com.app.raahi.core.data.remote.dto.AlertDto
import com.app.raahi.core.data.remote.dto.BookingDto
import com.app.raahi.core.data.remote.dto.VenueDto
import com.app.raahi.core.data.remote.dto.ReviewDto
import com.app.raahi.core.data.remote.dto.VerificationDto
import com.app.raahi.core.data.remote.dto.BarrierDto
import com.app.raahi.core.data.remote.dto.HelpRequestDto
import com.app.raahi.core.data.remote.dto.PlaceDto
import com.app.raahi.core.data.remote.dto.RouteLegDto
import com.app.raahi.core.data.remote.dto.RouteResponseDto
import com.app.raahi.core.data.remote.dto.SegmentImageryDto
import com.app.raahi.core.data.remote.dto.StepDto
import kotlin.math.ceil

/**
 * Round-one demo data. Routes are NOT hard-coded: for any two places below the geometry comes from OpenStreetMap
 * routing (see [OsrmClient]) and [RoutePlanner] finds the barrier-free one. What is made up is the barriers, the
 * helpers and the photo ages. One object is shared by the three Fake data sources so a helper's report really shows
 * up as an alert and a new route for the user. Round two swaps these for the Remote sources.
 */
private const val RAVI = "Shravan"
private const val MEERA = "Meera"
private const val IMRAN = "Imran"
private const val DRIVER = "Verified driver"
private const val NGO = "Verified NGO Helping Hand"

private const val WALK_M_PER_MIN = 70.0 // about 4.2 km/h, an easy pace for a wheelchair or a slow walker

private val BASE_AGES = listOf<Int?>(4, 12, null, 150, 30, null, 9, 75)
private val SAFE_AGES = listOf<Int?>(6, 14, 3, 20, 45, null, 9, 60, 30, 11)
private val SAFE_AGES_AFTER_REPORT = listOf<Int?>(6, 14, 0, 20, 45, 100, 9, 60, 30, 11, 2)

/** Barriers invented for routes that do not meet any seeded one, so every route in the demo has something to avoid. */
private val DEMO_KINDS = listOf(
    Triple("STEPS", "Three steps, no ramp", RAVI to DRIVER),
    Triple("MISSING_KERB_RAMP", "No kerb ramp at crossing", MEERA to NGO),
    Triple("BROKEN_SURFACE", "Broken paving, wheelchair wheels get stuck", IMRAN to DRIVER),
    Triple("POLE_OBSTRUCTION", "Electric pole in the middle of the path", MEERA to NGO),
)

/** The four things a place shares on video to earn the Shravan Verified badge. */
/** What one hour of a Helping Hand costs, in rupees. */
private const val HOURLY_RATE = 199

private val ALL_TOPICS = listOf("Entrance and ramp", "Washroom", "Safety", "Hospitality")

class FakeWorld {
    /** Snapped to the road network, so the A and B markers sit on a street. */
    val places = listOf(
        PlaceDto("Bus stop, Jawahar Circle", 26.842392, 75.804368),
        PlaceDto("Metro station", 26.845173, 75.810214),
        PlaceDto("City hospital", 26.844106, 75.806853),
        PlaceDto("Market square", 26.840911, 75.808991),
    )

    /** Friendly places around the demo user. Made up, but placed on real roads so the route to each one is real. */
    val venues = listOf(
        VenueDto("v1", "Kesar Cafe", "CAFE", 26.843776, 75.807971, "Main road, near the market",
            listOf("Step-free entrance", "Ramp", "Wide door", "Quiet corner"), 4.6, "Staff are trained to help. Ask for the ground-floor table.",
            verification = VerificationDto(ALL_TOPICS, 12, 12),
            reviews = listOf(
                ReviewDto("rv1", "Anil K.", "Wheelchair user", 5, "Staff moved a chair without being asked. The washroom door is wide enough for my chair and nobody stared.", "2 weeks ago"),
                ReviewDto("rv2", "Sana R.", "Blind or low vision", 5, "The waiter read the menu aloud and described every dish. I never felt rushed.", "1 month ago"),
                ReviewDto("rv3", "Vikram S.", "Deaf or hard of hearing", 4, "Staff face you when they speak and write the order down. A little loud in the evening.", "2 months ago"),
            )),
        VenueDto("v2", "Sunrise Cafe", "CAFE", 26.844534, 75.809412, "Opposite the metro station",
            listOf("Step-free entrance", "Accessible toilet", "Braille menu", "Sign-language friendly"), 4.4, "Braille and picture menus at the counter.",
            verification = VerificationDto(ALL_TOPICS, 12, 12),
            reviews = listOf(
                ReviewDto("rv4", "Priya M.", "Blind or low vision", 5, "Braille menu at the counter, and the owner walked me to my table.", "3 weeks ago"),
                ReviewDto("rv5", "Rahul D.", "Wheelchair user", 4, "Clean accessible toilet. One step into the back garden, so ask for a front table.", "1 month ago"),
                ReviewDto("rv6", "Meena T.", "Deaf or hard of hearing", 5, "The team knows basic sign language and was patient with my order.", "5 weeks ago"),
            )),
        VenueDto("v3", "Green Leaf Cafe", "CAFE", 26.842018, 75.805702, "Two minutes from Jawahar Circle",
            listOf("Ramp", "Picture menu", "Outdoor seating", "Low noise"), 4.2, "Calm in the mornings. Picture menu helps with ordering.",
            verification = VerificationDto(listOf("Entrance and ramp", "Hospitality"), 7, 12),
            reviews = listOf(
                ReviewDto("rv7", "Kabir N.", "Other", 4, "Low noise and a picture menu made ordering easy. Staff gave me time.", "1 week ago"),
                ReviewDto("rv8", "Farah A.", "Wheelchair user", 3, "The ramp is steep and the washroom is upstairs. Staff were kind though.", "3 weeks ago"),
            )),
        VenueDto("v4", "Shanti Park", "PARK", 26.841577, 75.808294, "South of the market",
            listOf("Flat paved paths", "Benches every 50 m", "Accessible toilet", "Shaded"), 4.5, "Flat loop of about 600 m with places to rest.",
            reviews = listOf(ReviewDto("rv9", "Anil K.", "Wheelchair user", 5, "Smooth loop and a bench whenever I need to rest.", "1 month ago"))),
        VenueDto("v5", "Lake View Garden", "PARK", 26.845583, 75.806194, "North lane, past the crossing",
            listOf("Smooth paving", "Tactile paving", "Seating", "Quiet"), 4.7, "Tactile paving guides to the pond and the benches.",
            reviews = listOf(ReviewDto("rv10", "Priya M.", "Blind or low vision", 5, "The tactile paving leads all the way to the pond. I walk here alone.", "2 weeks ago"))),
        VenueDto("v6", "Community Library", "LIBRARY", 26.844994, 75.807024, "Next to the city hospital",
            listOf("Lift", "Ramp", "Large-print books", "Quiet reading room"), 4.3, "Lift to every floor. Audio books at the desk.",
            reviews = listOf(ReviewDto("rv11", "Sana R.", "Blind or low vision", 4, "The desk set me up with audio books in five minutes.", "1 month ago"))),
    )

    private val bookings = mutableListOf<BookingDto>()
    private val bookingHelpers = listOf(RAVI to DRIVER, MEERA to NGO, IMRAN to DRIVER)

    fun book(userId: String, kind: String, destination: String, slot: String, note: String, minutes: Int): BookingDto {
        val (name, badge) = bookingHelpers[bookings.size % bookingHelpers.size]
        val m = minutes.coerceAtLeast(30)
        val b = BookingDto(nextId("bk"), userId, name, badge, kind, destination, slot, note, "CONFIRMED", m, (HOURLY_RATE * m + 59) / 60)
        bookings.add(0, b)
        return b
    }

    fun bookingsFor(userId: String) = bookings.filter { it.userId == userId }

    fun cancelBooking(id: String): BookingDto? {
        val i = bookings.indexOfFirst { it.id == id }
        if (i < 0) return null
        bookings[i] = bookings[i].copy(status = "CANCELLED")
        return bookings[i]
    }

    private val steps = barrier("b1", "STEPS", 26.84315, 75.80660, "seg_12", "Three steps, no ramp", RAVI, DRIVER)
    private val kerb = barrier("b2", "MISSING_KERB_RAMP", 26.84327, 75.80740, "seg_18", "No kerb ramp at crossing", MEERA, NGO)

    /** Seeded reports, so the Home map has a real spread of pins. */
    private val seeded = listOf(
        barrier("b3", "BROKEN_SURFACE", 26.839788, 75.805474, "seg_03", "Broken paving, wheelchair wheels get stuck", MEERA, NGO),
        barrier("b4", "MISSING_FOOTPATH", 26.846330, 75.807449, "seg_31", "Footpath ends, walk on the road", RAVI, DRIVER),
        barrier("b5", "POLE_OBSTRUCTION", 26.840739, 75.809018, "seg_07", "Electric pole in the middle of the path", IMRAN, DRIVER),
        barrier("b6", "PARKED_VEHICLE", 26.845637, 75.811750, "seg_40", "Bikes parked across the footpath", MEERA, NGO),
    )
    private val demoBarriers = mutableListOf<BarrierDto>()
    private val reported = mutableListOf<BarrierDto>()

    /** The routes last shown to the user. A helper's report is placed on [lastSafe]; a check request carries [lastBaseline]. */
    var lastBaseline: List<LatLon> = emptyList()
        private set
    var lastSafe: List<LatLon> = emptyList()
        private set

    /** "Bus stop, Jawahar Circle to Metro station", set each time a route is planned; used to say where an alert applies. */
    var lastRouteTitle: String = "your route"
        private set

    fun noteRoute(from: LatLon, to: LatLon) {
        val named = places.map { Triple(it.name, it.lat, it.lon) } + venues.map { Triple(it.name, it.lat, it.lon) }
        fun nameAt(p: LatLon) = named.minByOrNull { metres(p, it.second to it.third) }
            ?.takeIf { metres(p, it.second to it.third) < 80 }?.first ?: "your start"
        lastRouteTitle = "${nameAt(from)} to ${nameAt(to).let { if (it == "your start") "your destination" else it }}"
    }

    val alerts = mutableListOf<AlertDto>()
    val requests = mutableListOf<HelpRequestDto>()
    private var counter = 0
    fun nextId(prefix: String) = "${prefix}_${++counter}"

    private fun barrier(
        id: String, type: String, lat: Double, lon: Double, seg: String, note: String, reporter: String, badge: String,
    ) = BarrierDto(
        id = id, type = type, lat = lat, lon = lon, segmentId = seg, confidence = 0.9, verified = true, note = note,
        reporterName = reporter, reporterBadge = badge,
    )

    private fun allBarriers(): List<BarrierDto> = listOf(steps, kerb) + seeded + demoBarriers + reported

    fun barriers(): List<BarrierDto> = allBarriers()
    fun barrierPoints(): List<LatLon> = allBarriers().map { it.lat to it.lon }
    fun hasNewReport() = reported.isNotEmpty()

    private fun barriersNear(path: List<LatLon>) =
        allBarriers().filter { distanceToPath(it.lat to it.lon, path) <= HIT_M }

    /** Makes sure the route has at least one barrier on it to avoid; invents one part-way along when it has none. */
    fun ensureBarrierOn(path: List<LatLon>) {
        if (path.size < 2 || barriersNear(path).isNotEmpty()) return
        val at = pointAlong(path, 0.45)
        val (type, note, who) = DEMO_KINDS[demoBarriers.size % DEMO_KINDS.size]
        demoBarriers += barrier(nextId("bd"), type, at.first, at.second, "seg_d${demoBarriers.size + 1}", note, who.first, who.second)
    }

    private fun imagery(prefix: String, ages: List<Int?>, distanceM: Int) =
        List((distanceM / 100).coerceIn(4, 14)) { i -> SegmentImageryDto("${prefix}_${i + 1}", ages[i % ages.size]) }

    private fun minutes(distanceM: Int) = ceil(distanceM / WALK_M_PER_MIN).toInt().coerceAtLeast(1)

    fun response(baseline: List<LatLon>, safe: List<LatLon>): RouteResponseDto {
        lastBaseline = baseline
        lastSafe = safe
        val afterReport = hasNewReport()
        val baseDistance = lengthM(baseline)
        val safeDistance = lengthM(safe)
        return RouteResponseDto(
            routeId = nextId("route"),
            baseline = RouteLegDto(
                polyline = baseline.map { listOf(it.first, it.second) },
                distanceM = baseDistance, durationMin = minutes(baseDistance),
                barriers = barriersNear(baseline),
                steps = listOf(StepDto("Follow the main road, the way most people walk", baseDistance), StepDto("You have arrived")),
                imagery = imagery("seg_a", BASE_AGES, baseDistance),
            ),
            safe = RouteLegDto(
                polyline = safe.map { listOf(it.first, it.second) },
                distanceM = safeDistance, durationMin = minutes(safeDistance),
                barriers = barriersNear(safe),
                steps = listOf(
                    StepDto(if (afterReport) "Take the alternative lane, around the reported blockage" else "Take the lane that avoids the barriers on the main road", safeDistance * 45 / 100),
                    StepDto("Cross where there is a ramp", safeDistance * 20 / 100),
                    StepDto("Continue on the main road to the entrance with a ramp", safeDistance - safeDistance * 65 / 100),
                    StepDto("You have arrived"),
                ),
                imagery = imagery("seg_b", if (afterReport) SAFE_AGES_AFTER_REPORT else SAFE_AGES, safeDistance),
            ),
            extraDistanceM = safeDistance - baseDistance,
        )
    }

    /** Used only when the routing service cannot be reached: saved routes for the Bus stop to Metro station walk. */
    fun offlineRoutes(from: LatLon, to: LatLon): Pair<List<LatLon>, List<LatLon>>? {
        val a = OFFLINE_BASELINE.first()
        val b = OFFLINE_BASELINE.last()
        val forward = metres(from, a) < 60 && metres(to, b) < 60
        val backward = metres(from, b) < 60 && metres(to, a) < 60
        if (!forward && !backward) return null
        val safe = if (hasNewReport()) OFFLINE_SAFE_AFTER_REPORT else OFFLINE_SAFE
        return if (forward) OFFLINE_BASELINE to safe else OFFLINE_BASELINE.reversed() to safe.reversed()
    }

    /**
     * A helper reported something. The barrier is saved on the barrier-free route the user was last shown, so the
     * user's next route has to go round it. (The helper's own coordinates are only used when no route exists yet.)
     */
    fun addReport(type: String, note: String?, lat: Double, lon: Double): BarrierDto {
        val at = if (lastSafe.size >= 2) pointAlong(lastSafe, 0.5) else lat to lon
        val b = BarrierDto(
            id = nextId("b"), type = type, lat = at.first, lon = at.second, segmentId = "seg_24",
            confidence = 1.0, verified = true, note = note, reporterName = RAVI, reporterBadge = DRIVER,
        )
        if (type != "CLEAR") {
            reported += b
            alerts.add(0, AlertDto(
                id = nextId("al"), userId = "u_01", type = "ROUTE_ISSUE", segmentId = "seg_24",
                message = "$RAVI ($DRIVER) reported ${type.lowercase().replace('_', ' ')} on your route.",
                createdAt = "2026-10-24T12:00:00+05:30", read = false,
                barrier = b, senderName = RAVI, senderBadge = DRIVER, placeLabel = "On your route: $lastRouteTitle",
            ))
        }
        return b
    }

    fun completeRequest(id: String) {
        alerts.add(0, AlertDto(
            id = nextId("al"), userId = "u_01", type = "ROUTE_CHECKED",
            message = "$RAVI ($DRIVER) finished checking your route.", createdAt = "2026-10-24T12:05:00+05:30", read = false,
            senderName = RAVI, senderBadge = DRIVER,
            placeLabel = requests.firstOrNull { it.id == id }?.title?.let { "Route: $it" },
        ))
        requests.removeAll { it.id == id }
    }
}

/** Offline fallback only: saved road geometry for the Bus stop to Metro station walk, used when the routing service cannot be reached. */
private val OFFLINE_BASELINE = listOf(
    26.842392 to 75.804368, 26.842615 to 75.805615, 26.843008 to 75.805556, 26.843036 to 75.805810,
    26.843048 to 75.805915, 26.843288 to 75.807514, 26.843350 to 75.807984, 26.843352 to 75.808025,
    26.843776 to 75.807971, 26.844013 to 75.807932, 26.844223 to 75.807895, 26.844256 to 75.807891,
    26.844586 to 75.807855, 26.844674 to 75.807846, 26.844814 to 75.807856, 26.844969 to 75.807866,
    26.845268 to 75.807966, 26.845064 to 75.808336, 26.845056 to 75.808342, 26.844882 to 75.808704,
    26.844838 to 75.808780, 26.844630 to 75.809194, 26.844534 to 75.809412, 26.844458 to 75.809582,
    26.844395 to 75.809850, 26.844379 to 75.809983, 26.844431 to 75.809999, 26.844681 to 75.810069,
    26.844762 to 75.810093, 26.845173 to 75.810214,
)

/** Barrier-free route: leaves the normal road early, loops north, rejoins near the end. About 1.24 km. */
private val OFFLINE_SAFE = listOf(
    26.842392 to 75.804368, 26.842615 to 75.805615, 26.843008 to 75.805556, 26.843376 to 75.805477,
    26.843634 to 75.805436, 26.843798 to 75.805382, 26.844012 to 75.805332, 26.844432 to 75.805253,
    26.844774 to 75.805136, 26.845045 to 75.805093, 26.845157 to 75.805076, 26.845325 to 75.805079,
    26.845610 to 75.805084, 26.845609 to 75.805338, 26.845583 to 75.806194, 26.845583 to 75.806202,
    26.845568 to 75.807036, 26.845280 to 75.807030, 26.845254 to 75.807030, 26.844994 to 75.807024,
    26.844850 to 75.807021, 26.844590 to 75.807024, 26.844582 to 75.807256, 26.844582 to 75.807338,
    26.844584 to 75.807499, 26.844586 to 75.807855, 26.844674 to 75.807846, 26.844814 to 75.807856,
    26.844969 to 75.807866, 26.845268 to 75.807966, 26.845064 to 75.808336, 26.845056 to 75.808342,
    26.844882 to 75.808704, 26.844838 to 75.808780, 26.844630 to 75.809194, 26.844534 to 75.809412,
    26.844458 to 75.809582, 26.844395 to 75.809850, 26.844379 to 75.809983, 26.844431 to 75.809999,
    26.844681 to 75.810069, 26.844762 to 75.810093, 26.845173 to 75.810214,
)

/** Route after the northern lane is reported blocked: goes south instead. About 1.26 km. */
private val OFFLINE_SAFE_AFTER_REPORT = listOf(
    26.842392 to 75.804368, 26.842615 to 75.805615, 26.842363 to 75.805651, 26.842328 to 75.805656,
    26.842018 to 75.805702, 26.841672 to 75.805753, 26.841250 to 75.805815, 26.841380 to 75.806803,
    26.841577 to 75.808294, 26.841585 to 75.808358, 26.842041 to 75.808271, 26.842980 to 75.808094,
    26.843352 to 75.808025, 26.843776 to 75.807971, 26.844013 to 75.807932, 26.844223 to 75.807895,
    26.844256 to 75.807891, 26.844586 to 75.807855, 26.844674 to 75.807846, 26.844814 to 75.807856,
    26.844969 to 75.807866, 26.845268 to 75.807966, 26.845064 to 75.808336, 26.845056 to 75.808342,
    26.844882 to 75.808704, 26.844838 to 75.808780, 26.844630 to 75.809194, 26.844534 to 75.809412,
    26.844458 to 75.809582, 26.844395 to 75.809850, 26.844379 to 75.809983, 26.844431 to 75.809999,
    26.844681 to 75.810069, 26.844762 to 75.810093, 26.845173 to 75.810214,
)
