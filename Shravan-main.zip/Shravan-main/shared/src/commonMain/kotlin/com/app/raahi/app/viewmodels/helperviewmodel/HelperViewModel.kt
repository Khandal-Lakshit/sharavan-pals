package com.app.raahi.app.viewmodels.helperviewmodel

import androidx.lifecycle.ViewModel
import com.app.raahi.app.fluxdeck.AuthFluxDeck
import kotlinx.coroutines.flow.map
import androidx.lifecycle.viewModelScope
import com.app.raahi.app.domain.coordinator.HelperCoordinator
import com.app.raahi.app.domain.model.Barrier
import com.app.raahi.app.domain.model.BarrierType
import com.app.raahi.app.domain.model.GeoPoint
import com.app.raahi.app.domain.model.HelpRequest
import com.app.raahi.app.domain.model.ReportResult
import com.app.raahi.app.fluxdeck.HelperFluxDeck
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

/** Reflector for the helper feature. */
class HelperViewModel(
    private val coordinator: HelperCoordinator,
    private val fluxDeck: HelperFluxDeck,
    authFluxDeck: AuthFluxDeck,
) : ViewModel() {

    val events = coordinator.events
    val userName = authFluxDeck.user.map { it?.name.orEmpty() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")
    val userBadge = authFluxDeck.user.map { it?.badge.orEmpty() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    private fun <T> Flow<T>.reflect(initial: T): StateFlow<T> =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), initial)

    val requests = fluxDeck.requests
    val incomingAlert = fluxDeck.incomingAlert.reflect(null)
    val selectedRequestId = fluxDeck.selectedRequestId
    val requestedRoute = fluxDeck.requestedRoute.reflect(emptyList<GeoPoint>())
    val barriers = fluxDeck.barriers
    val location = fluxDeck.location
    val status = fluxDeck.status
    val note = fluxDeck.note
    val photo = fluxDeck.photo
    val isSubmitting = fluxDeck.isSubmitting
    val canSubmit = fluxDeck.canSubmit.reflect(false)
    val lastResult = fluxDeck.lastResult

    fun selectRequest(id: String?) = fluxDeck.selectRequest(id)
    /** "Check route" on the alert: open that route on the map and close the alert. */
    fun acceptAlert(id: String) { fluxDeck.selectRequest(id); fluxDeck.dismissAlert(id) }
    fun dismissAlert(id: String) = fluxDeck.dismissAlert(id)
    fun setLocation(point: GeoPoint) = fluxDeck.updateLocation(point)
    fun clearLocation() = fluxDeck.updateLocation(null)
    fun setStatus(type: BarrierType) = fluxDeck.updateStatus(type)
    fun setNote(text: String) = fluxDeck.updateNote(text)
    fun setPhoto(bytes: ByteArray?) = fluxDeck.updatePhoto(bytes)
    fun submit() = fluxDeck.submit()
    fun markRouteChecked() = coordinator.markRouteChecked()
}
