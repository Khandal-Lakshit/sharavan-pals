package com.app.raahi.core.data.networking

object BaseUrl {
    var value: String = ""
}
