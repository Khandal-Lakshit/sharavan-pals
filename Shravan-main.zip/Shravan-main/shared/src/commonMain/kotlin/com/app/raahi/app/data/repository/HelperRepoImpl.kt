package com.app.raahi.app.data.repository

import com.app.raahi.app.data.mapper.toDomain
import com.app.raahi.app.domain.model.Barrier
import com.app.raahi.app.domain.model.HelpRequest
import com.app.raahi.app.domain.model.ReportDraft
import com.app.raahi.app.domain.model.ReportResult
import com.app.raahi.app.domain.repository.HelperRepo
import com.app.raahi.core.data.remote.source.HelperDataSource
import com.app.raahi.core.data.remote.source.RouteDataSource
import com.app.raahi.core.domain.util.NetworkError
import com.app.raahi.core.domain.util.Result
import com.app.raahi.core.domain.util.map
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class HelperRepoImpl(
    private val remote: HelperDataSource,
    private val routeRemote: RouteDataSource,
) : HelperRepo {

    override fun observeBarriers(): Flow<Result<List<Barrier>, NetworkError>> = flow {
        while (true) {
            emit(routeRemote.getBarriers().map { list -> list.map { it.toDomain() } })
            delay(POLL_MS)
        }
    }

    override suspend fun submitReport(reporterId: String, draft: ReportDraft): Result<ReportResult, NetworkError> =
        remote.createReport(
            lat = draft.point.lat,
            lon = draft.point.lon,
            status = draft.status.name,
            reporterId = reporterId,
            note = draft.note,
            requestId = draft.requestId,
            photo = draft.photo,
        ).map { it.toDomain() }

    override suspend fun completeRouteCheck(requestId: String, helperId: String): Result<Unit, NetworkError> =
        remote.completeRequest(requestId, helperId).map { }

    override fun observeOpenRequests(): Flow<Result<List<HelpRequest>, NetworkError>> = flow {
        while (true) {
            emit(remote.getOpenRequests().map { list -> list.map { it.toDomain() } })
            delay(POLL_MS)
        }
    }

    private companion object {
        const val POLL_MS = 4_000L
    }
}
