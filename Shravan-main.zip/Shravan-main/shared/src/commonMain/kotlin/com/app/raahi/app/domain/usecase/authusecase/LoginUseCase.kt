package com.app.raahi.app.domain.usecase.authusecase

import com.app.raahi.app.domain.model.Role
import com.app.raahi.app.domain.model.User
import com.app.raahi.app.domain.repository.AuthRepo
import com.app.raahi.core.domain.util.NetworkError
import com.app.raahi.core.domain.util.Result

class LoginUseCase(private val authRepo: AuthRepo) {
    suspend operator fun invoke(role: Role): Result<User, NetworkError> = authRepo.login(role)
}
