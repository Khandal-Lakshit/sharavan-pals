package com.app.raahi.app.fluxdeck

import com.app.raahi.app.domain.model.Role
import com.app.raahi.app.domain.model.User
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

/** Model for the session: who is logged in (User or Helper). */
class AuthFluxDeck {
    private val _user = MutableStateFlow<User?>(null)
    val user: StateFlow<User?> = _user.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    fun setUser(user: User?) { _user.value = user }
    fun setLoading(loading: Boolean) { _isLoading.value = loading }
}
