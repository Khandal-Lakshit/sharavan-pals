package com.app.raahi.app.domain.coordinator

import com.app.raahi.app.Events
import com.app.raahi.app.StateReflector
import com.app.raahi.app.domain.model.Alert
import com.app.raahi.app.domain.model.AlertType
import com.app.raahi.app.domain.model.HelpKind
import com.app.raahi.app.domain.model.durationLabel
import com.app.raahi.app.domain.model.Place
import com.app.raahi.app.domain.model.Role
import com.app.raahi.app.domain.model.User
import com.app.raahi.app.domain.model.Venue
import com.app.raahi.app.domain.model.VenueReview
import com.app.raahi.app.domain.usecase.routeusecase.RouteUseCases
import com.app.raahi.app.fluxdeck.AuthFluxDeck
import com.app.raahi.app.fluxdeck.RouteFluxDeck
import com.app.raahi.app.handleResult
import com.app.raahi.core.domain.util.Result
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * Operation layer for the user's route feature. Registered as a singleton like your other coordinators, but it does
 * nothing (no network, no polling) until a USER logs in; logging out cancels everything and clears the FluxDeck.
 */
class RouteCoordinator(
    private val routeUseCases: RouteUseCases,
    private val fluxDeck: RouteFluxDeck,
    private val authFluxDeck: AuthFluxDeck,
    private val scope: CoroutineScope,
) {
    val reflector = StateReflector<Events>(scope)
    val events = reflector.events
    private var firstAlertBatch = true

    init {
        sync()
    }

    fun planRoute() { scope.launch { plan(silent = false) } }
    fun bookHelper(kind: HelpKind, destination: String, slot: String, note: String, minutes: Int) { scope.launch { book(kind, destination, slot, note, minutes) } }
    fun cancelBooking(id: String) { scope.launch { cancel(id) } }

    /** Demo: the review is kept in memory. With the backend (round two) this becomes a POST to /venues/{id}/reviews. */
    fun postReview(venueId: String, rating: Int, need: String, text: String) {
        val user = authFluxDeck.user.value ?: return
        val count = fluxDeck.venues.value.sumOf { it.reviews.size } + 1
        fluxDeck.addReview(venueId, VenueReview("rv_new_$count", user.name, need, rating.coerceIn(1, 5), text.trim(), "Just now"))
        reflector.emitEvent(Events.Success("Thanks. Your review is posted."))
    }

    /** Route from the user's location to a place picked in Explore. */
    fun goTo(venue: Venue) {
        scope.launch {
            fluxDeck.updateOrigin(Place("Your location", fluxDeck.userLocation.value))
            fluxDeck.updateDestination(Place(venue.name, venue.point))
            plan(silent = false)
        }
    }

    fun requestRouteCheck() { scope.launch { sendCheckRequest() } }
    fun markAllAlertsRead() { scope.launch { markAllRead() } }

    private fun sync() {
        scope.launch {
            authFluxDeck.user
                .map { it?.takeIf { u -> u.role == Role.USER } }
                .distinctUntilChanged()
                .collectLatest { user ->
                    fluxDeck.clear()
                    if (user != null) runFor(user)
                }
        }
    }

    private suspend fun runFor(user: User) = coroutineScope {
        firstAlertBatch = true
        launch {
            val venues = (routeUseCases.getVenues() as? Result.Success)?.data.orEmpty()
            fluxDeck.updateVenues(venues)
            reflector.handleResult(routeUseCases.searchPlaces("")) { places ->
                // "Your location" and the Explore places can also be picked in From / To
                fluxDeck.updatePlaces(
                    places + Place("Your location", fluxDeck.userLocation.value) + venues.map { Place(it.name, it.point) },
                )
                // demo defaults so the first tap on "Find safe route" just works
                places.firstOrNull { it.name.contains("Bus", true) }?.let { fluxDeck.updateOrigin(it) }
                places.firstOrNull { it.name.contains("Metro", true) }?.let { fluxDeck.updateDestination(it) }
            }
        }
        launch {
            (routeUseCases.getBookings(user.id) as? Result.Success)?.let { fluxDeck.updateBookings(it.data) }
        }
        launch {
            routeUseCases.observeMapBarriers().collect { result ->
                if (result is Result.Success) fluxDeck.updateAllBarriers(result.data)   // polling errors stay silent
            }
        }
        launch {
            routeUseCases.observeAlerts(user.id).collect { result ->
                if (result is Result.Success) onAlerts(result.data)   // polling errors stay silent
            }
        }
    }

    private suspend fun onAlerts(list: List<Alert>) {
        fluxDeck.updateAlerts(list)
        val issues = list.filter { it.type == AlertType.ROUTE_ISSUE }
        if (firstAlertBatch) {            // alerts from before this login must not trigger a reroute
            firstAlertBatch = false
            fluxDeck.markIssuesHandled(issues.map { it.id }.toSet())
            return
        }
        val fresh = issues.filter { it.id !in fluxDeck.handledIssueIds.value }
        if (fresh.isEmpty()) return
        fluxDeck.markIssuesHandled(fresh.map { it.id }.toSet())
        if (fluxDeck.plan.value != null) {
            val extra = fresh.first().extraDistanceM
            val banner = fresh.first().message +
                if (extra != null && extra != 0) " New route is $extra m longer." else " New route shown."
            plan(silent = true)
            fluxDeck.updateRerouteBanner(banner)
        }
    }

    private suspend fun plan(silent: Boolean) {
        val user = authFluxDeck.user.value ?: return
        val from = fluxDeck.origin.value ?: return
        val to = fluxDeck.destination.value ?: return
        if (!silent) {
            fluxDeck.setPlanning(true)
            fluxDeck.updateRerouteBanner(null)
        }
        reflector.handleResult(routeUseCases.planRoute(from.point, to.point, user.id)) { plan ->
            fluxDeck.updatePlan(plan)
        }
        fluxDeck.setPlanning(false)
    }

    private suspend fun sendCheckRequest() {
        val user = authFluxDeck.user.value ?: return
        val from = fluxDeck.origin.value ?: return
        val to = fluxDeck.destination.value ?: return
        reflector.handleResult(routeUseCases.requestRouteCheck(user.id, from.point, to.point, "${from.name} to ${to.name}")) {
            fluxDeck.setCheckRequested(true)
            reflector.emitEvent(Events.Success("Helping Hands around this route were alerted."))
        }
    }

    private suspend fun markAllRead() {
        fluxDeck.alerts.value.filter { !it.isRead }.forEach { routeUseCases.markAlertRead(it.id) }
    }

    private suspend fun book(kind: HelpKind, destination: String, slot: String, note: String, minutes: Int) {
        val user = authFluxDeck.user.value ?: return
        reflector.handleResult(routeUseCases.bookHelper(user.id, kind, destination.trim(), slot, note.trim(), minutes)) { booking ->
            fluxDeck.upsertBooking(booking)
            reflector.emitEvent(Events.Success("Booked. ${booking.helperName} will meet you ${slot.replaceFirstChar { it.lowercase() }}. ₹${booking.price} for ${durationLabel(booking.minutes)}."))
        }
    }

    private suspend fun cancel(id: String) {
        reflector.handleResult(routeUseCases.cancelBooking(id)) { booking ->
            fluxDeck.upsertBooking(booking)
            reflector.emitEvent(Events.Success("Booking cancelled."))
        }
    }
}
