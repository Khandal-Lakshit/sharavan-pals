package com.app.raahi.app.di

import com.app.raahi.app.data.repository.AuthRepoImpl
import com.app.raahi.app.data.repository.CommunityRepoImpl
import com.app.raahi.app.data.repository.HelperRepoImpl
import com.app.raahi.app.data.repository.RouteRepoImpl
import com.app.raahi.app.domain.coordinator.AuthCoordinator
import com.app.raahi.app.domain.coordinator.HelperCoordinator
import com.app.raahi.app.domain.coordinator.RouteCoordinator
import com.app.raahi.app.domain.repository.AuthRepo
import com.app.raahi.app.domain.repository.CommunityRepo
import com.app.raahi.app.domain.repository.HelperRepo
import com.app.raahi.app.domain.repository.RouteRepo
import com.app.raahi.app.domain.usecase.authusecase.AuthUseCases
import com.app.raahi.app.domain.usecase.authusecase.LoginUseCase
import com.app.raahi.app.domain.usecase.helperusecase.CompleteRouteCheckUseCase
import com.app.raahi.app.domain.usecase.helperusecase.ObserveBarriersUseCase
import com.app.raahi.app.domain.usecase.helperusecase.HelperUseCases
import com.app.raahi.app.domain.usecase.helperusecase.ObserveOpenRequestsUseCase
import com.app.raahi.app.domain.usecase.helperusecase.SubmitReportUseCase
import com.app.raahi.app.domain.usecase.routeusecase.BookHelperUseCase
import com.app.raahi.app.domain.usecase.routeusecase.CancelBookingUseCase
import com.app.raahi.app.domain.usecase.routeusecase.GetBookingsUseCase
import com.app.raahi.app.domain.usecase.routeusecase.GetVenuesUseCase
import com.app.raahi.app.domain.usecase.routeusecase.MarkAlertReadUseCase
import com.app.raahi.app.domain.usecase.routeusecase.ObserveAlertsUseCase
import com.app.raahi.app.domain.usecase.routeusecase.ObserveMapBarriersUseCase
import com.app.raahi.app.domain.usecase.routeusecase.PlanRouteUseCase
import com.app.raahi.app.domain.usecase.routeusecase.RequestRouteCheckUseCase
import com.app.raahi.app.domain.usecase.routeusecase.RouteUseCases
import com.app.raahi.app.domain.usecase.routeusecase.SearchPlacesUseCase
import com.app.raahi.app.fluxdeck.AuthFluxDeck
import com.app.raahi.app.fluxdeck.HelperFluxDeck
import com.app.raahi.app.fluxdeck.RouteFluxDeck
import com.app.raahi.app.viewmodels.authviewmodel.AuthViewModel
import com.app.raahi.app.viewmodels.helperviewmodel.HelperViewModel
import com.app.raahi.app.viewmodels.routeviewmodel.RouteViewModel
import com.app.raahi.core.data.fake.FakeAuthDataSource
import com.app.raahi.core.data.fake.FakeHelperDataSource
import com.app.raahi.core.data.fake.FakeRouteDataSource
import com.app.raahi.core.data.fake.FakeWorld
import com.app.raahi.core.data.fake.OsrmClient
import com.app.raahi.core.data.fake.RoutePlanner
import com.app.raahi.core.data.networking.HttpClientFactory
import com.app.raahi.core.data.remote.source.AuthDataSource
import com.app.raahi.core.data.remote.source.HelperDataSource
import com.app.raahi.core.data.remote.source.RemoteAuthDataSource
import com.app.raahi.core.data.remote.source.RemoteHelperDataSource
import com.app.raahi.core.data.remote.source.RemoteRouteDataSource
import com.app.raahi.core.data.remote.source.RouteDataSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import org.koin.core.module.dsl.singleOf
import org.koin.core.qualifier.named
import org.koin.dsl.bind
import org.koin.dsl.module

const val USE_FAKE_DATA = true

/** Needs one platform binding: an HttpClientEngine (OkHttp on Android, Darwin on iOS), same as your Koshpal setup. */
val sharedModule = module {
    single(named("MainScope")) { CoroutineScope(SupervisorJob() + Dispatchers.Main) }

    // Networking
    single { HttpClientFactory.create(get()) }

    // DataSources
    // Round one: hard-coded demo data. Round two: set USE_FAKE_DATA = false and nothing else changes.
    if (USE_FAKE_DATA) {
        single { FakeWorld() }
        single { OsrmClient(get()) }
        single { RoutePlanner(get()) }
        singleOf(::FakeAuthDataSource).bind<AuthDataSource>()
        singleOf(::FakeRouteDataSource).bind<RouteDataSource>()
        singleOf(::FakeHelperDataSource).bind<HelperDataSource>()
    } else {
        singleOf(::RemoteAuthDataSource).bind<AuthDataSource>()
        singleOf(::RemoteRouteDataSource).bind<RouteDataSource>()
        singleOf(::RemoteHelperDataSource).bind<HelperDataSource>()
    }

    // Repositories
    single<AuthRepo> { AuthRepoImpl(get()) }
    single<RouteRepo> { RouteRepoImpl(get()) }
    single<HelperRepo> { HelperRepoImpl(get(), get()) }
    single<CommunityRepo> { CommunityRepoImpl() }

    // UseCases
    factory { LoginUseCase(get()) }
    factory { AuthUseCases(get()) }
    factory { SearchPlacesUseCase(get()) }
    factory { PlanRouteUseCase(get()) }
    factory { RequestRouteCheckUseCase(get()) }
    factory { MarkAlertReadUseCase(get()) }
    factory { ObserveAlertsUseCase(get()) }
    factory { ObserveMapBarriersUseCase(get()) }
    factory { GetVenuesUseCase(get()) }
    factory { GetBookingsUseCase(get()) }
    factory { BookHelperUseCase(get()) }
    factory { CancelBookingUseCase(get()) }
    factory { RouteUseCases(get(), get(), get(), get(), get(), get(), get(), get(), get(), get()) }
    factory { ObserveBarriersUseCase(get()) }
    factory { SubmitReportUseCase(get()) }
    factory { CompleteRouteCheckUseCase(get()) }
    factory { ObserveOpenRequestsUseCase(get()) }
    factory { HelperUseCases(get(), get(), get(), get()) }

    // FluxDecks
    single { AuthFluxDeck() }
    single { RouteFluxDeck() }
    single { HelperFluxDeck() }

    // Coordinators (idle until the matching role logs in, so createdAtStart costs nothing)
    single(createdAtStart = true) { AuthCoordinator(get(), get(), get(named("MainScope"))) }
    single(createdAtStart = true) { RouteCoordinator(get(), get(), get(), get(named("MainScope"))) }
    single(createdAtStart = true) { HelperCoordinator(get(), get(), get(), get(named("MainScope"))) }

    // ViewModels (Reflectors)
    factory { AuthViewModel(get(), get()) }
    factory { RouteViewModel(get(), get(), get(), get()) }
    factory { HelperViewModel(get(), get(), get()) }
}
