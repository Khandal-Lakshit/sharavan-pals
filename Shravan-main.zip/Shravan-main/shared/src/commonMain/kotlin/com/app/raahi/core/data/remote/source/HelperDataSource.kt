package com.app.raahi.core.data.remote.source

import com.app.raahi.core.data.remote.dto.HelpRequestDto
import com.app.raahi.core.data.remote.dto.ReportResponseDto
import com.app.raahi.core.domain.util.NetworkError
import com.app.raahi.core.domain.util.Result

interface HelperDataSource {
    suspend fun getOpenRequests(): Result<List<HelpRequestDto>, NetworkError>
    suspend fun completeRequest(id: String, helperId: String): Result<HelpRequestDto, NetworkError>
    suspend fun createReport(
        lat: Double,
        lon: Double,
        status: String,
        reporterId: String,
        note: String?,
        requestId: String?,
        photo: ByteArray?,
    ): Result<ReportResponseDto, NetworkError>
}
