import SwiftUI

extension Color {
    init(hex: String) {
        let cleanHex = hex.replacingOccurrences(of: "0x", with: "")
                          .replacingOccurrences(of: "#", with: "")
                          .trimmingCharacters(in: .whitespacesAndNewlines)
        var int: UInt64 = 0
        Scanner(string: cleanHex).scanHexInt64(&int)

        let a, r, g, b: UInt64
        switch cleanHex.count {
        case 6:
            (a, r, g, b) = (255, (int >> 16) & 0xFF, (int >> 8) & 0xFF, int & 0xFF)
        case 8:
            (a, r, g, b) = ((int >> 24) & 0xFF, (int >> 16) & 0xFF, (int >> 8) & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 128, 128, 128)
        }

        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue: Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}

/// One palette for the whole app: iOS Messages green on white (same tokens as Android Color.kt).
/// Bright green = big fills and icons. Deep green = anything that is small text on white.
struct RaahiTheme {
    static let primary = Color(hex: "0xFF34C759")   // Messages green: buttons, active tab, chips
    static let deep = Color(hex: "0xFF248A3D")      // green text, avatars, ticks, the barrier-free route
    static let tint = Color(hex: "0xFFD4F4DE")      // soft green background
    static let safe = deep                          // barrier-free route line
    static let success = deep
    static let warn = Color(hex: "0xFFD55E00")      // normal route, warnings (Okabe-Ito vermillion)
    static let grouped = Color(.systemGroupedBackground)           // background of every screen (F2F2F7 / black)
    static let surface = Color(.secondarySystemGroupedBackground) // cards (white / 1C1C1E)
    static let fill = Color(.tertiarySystemGroupedBackground)     // inputs and tiles inside a card
    static let hairline = Color(.separator)                       // the 0.5 pt card border
    static let amber = Color(hex: "0xFF946B00")                   // "Medium" confidence (the word always accompanies it)
}
