import Foundation
import SharedCore

// Kotlin generics reach Swift as Any?, so every StateFlow value is cast here, in one place.
func asBool(_ value: Any?) -> Bool { (value as? KotlinBoolean)?.boolValue ?? false }
func asInt(_ value: Any?) -> Int { Int((value as? KotlinInt)?.intValue ?? 0) }

/// Owns the FlowWatchers of a bridge and cancels them together.
final class WatcherBag {
    private var items: [FlowWatcher] = []
    func add(_ watcher: FlowWatcher) { items.append(watcher) }
    func cancelAll() { items.forEach { $0.cancel() }; items.removeAll() }
    deinit { items.forEach { $0.cancel() } }
}

func formatTime(_ iso: String) -> String {
    guard let date = ISO8601DateFormatter().date(from: iso) else { return "" }
    return date.formatted(date: .omitted, time: .shortened)
}
