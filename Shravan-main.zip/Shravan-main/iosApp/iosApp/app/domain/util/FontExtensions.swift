import SwiftUI
import CoreText

private enum FontRegistrar {
    static let registerFonts: Void = {
        let fontFiles = [
            "poppins_regular", "poppins_medium", "poppins_semibold", "poppins_bold",
            "inter_regular", "inter_medium", "inter_semibold"
        ]
        for file in fontFiles {
            if let url = Bundle.main.url(forResource: file, withExtension: "ttf") {
                CTFontManagerRegisterFontsForURL(url as CFURL, .process, nil)
            }
        }
    }()
}

extension Font {
    /// Every size in the app is written at the old scale; this takes about 10% off body text and 16% off titles so more of the map stays visible.
    static func compact(_ size: CGFloat) -> CGFloat { max(11, (size * (size >= 18 ? 0.84 : 0.9)).rounded()) }

    /// Parent text: titles, headings, buttons. Poppins.
    static func poppins(_ rawSize: CGFloat, weight: Font.Weight = .bold) -> Font {
        _ = FontRegistrar.registerFonts
        let size = Font.compact(rawSize)
        let fontName: String
        switch weight {
        case .bold, .heavy, .black:
            fontName = "Poppins-Bold"
        case .semibold:
            fontName = "Poppins-SemiBold"
        case .medium:
            fontName = "Poppins-Medium"
        default:
            fontName = "Poppins-Regular"
        }
        if UIFont(name: fontName, size: size) != nil {
            return .custom(fontName, size: size)
        }
        return .system(size: size, weight: weight)
    }

    /// Child text: paragraphs and labels. Inter.
    static func inter(_ rawSize: CGFloat, weight: Font.Weight = .regular) -> Font {
        _ = FontRegistrar.registerFonts
        let size = Font.compact(rawSize)
        let fontName: String
        switch weight {
        case .bold, .heavy, .black, .semibold:
            fontName = "Inter-SemiBold"
        case .medium:
            fontName = "Inter-Medium"
        default:
            fontName = "Inter-Regular"
        }
        if UIFont(name: fontName, size: size) != nil {
            return .custom(fontName, size: size)
        }
        return .system(size: size, weight: weight)
    }
}
