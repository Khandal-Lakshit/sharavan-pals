import SwiftUI
import Combine
import SharedCore

@MainActor
class RouteViewModelBridge: ObservableObject {
    private let viewModel = AppModuleKt.getRouteViewModel()
    private let watchers = WatcherBag()

    @Published var userName: String = ""
    @Published var cityName: String = ""
    @Published var showDirections: Bool = false
    @Published var places: [SharedCore.Place] = []
    @Published var origin: SharedCore.Place? = nil
    @Published var destination: SharedCore.Place? = nil
    @Published var plan: RoutePlan? = nil
    @Published var isPlanning: Bool = false
    @Published var alerts: [SharedCore.Alert] = []
    @Published var rerouteBanner: String? = nil
    @Published var checkRequested: Bool = false
    @Published var canPlan: Bool = false
    @Published var unreadCount: Int = 0
    @Published var barriersOnMap: [Barrier] = []
    @Published var selectedBarrier: Barrier? = nil
    @Published var fitPoints: [GeoPoint] = []
    @Published var homeBarriers: [Barrier] = []
    @Published var mapFit: [GeoPoint] = []
    @Published var searchCollapsed: Bool = false
    @Published var homeFilter: HomeFilter = HomeFilter.all
    let homeFilters: [HomeFilter] = (AppModuleKt.getHomeFilters() as? [HomeFilter]) ?? []
    @Published var tab: UserTab = UserTab.home
    @Published var nearby: [NearbyVenue] = []
    @Published var exploreFilter: ExploreFilter = ExploreFilter.all
    let exploreFilters: [ExploreFilter] = (AppModuleKt.getExploreFilters() as? [ExploreFilter]) ?? []
    let bookingSlots: [String] = (AppModuleKt.getBookingSlots() as? [String]) ?? []
    let helpKinds: [HelpKind] = (AppModuleKt.getHelpKinds() as? [HelpKind]) ?? []
    let bookingMinutes: [Int] = ((AppModuleKt.getBookingMinutes() as? [NSNumber]) ?? []).map { $0.intValue }
    let bookingTerms: [String] = (AppModuleKt.getBookingTerms() as? [String]) ?? []
    let pricePerHour: Int = Int(AppModuleKt.getHelpPricePerHour())
    let verificationTopics: [String] = (AppModuleKt.getVerificationTopics() as? [String]) ?? []
    let reviewerNeeds: [String] = (AppModuleKt.getReviewerNeeds() as? [String]) ?? []
    @Published var activeBooking: Booking? = nil
    @Published var communityGroups: [CommunityGroup] = []
    @Published var communityMessages: [String: [ChatMessage]] = [:]
    @Published var selectedGroupId: String = "c1"
    @Published var isChatOpen: Bool = false
    @Published var errorMessage: String? = nil
    @Published var toast: String? = nil

    init() {
        watchers.add(FlowWatcherKt.watch(flow: viewModel.userName) { [weak self] v in self?.userName = (v as? String) ?? "" })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.cityName) { [weak self] v in self?.cityName = (v as? String) ?? "" })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.showDirections) { [weak self] v in self?.showDirections = asBool(v) })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.places) { [weak self] v in self?.places = (v as? [SharedCore.Place]) ?? [] })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.origin) { [weak self] v in self?.origin = v as? SharedCore.Place })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.destination) { [weak self] v in self?.destination = v as? SharedCore.Place })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.plan) { [weak self] v in self?.plan = v as? RoutePlan })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.isPlanning) { [weak self] v in self?.isPlanning = asBool(v) })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.alerts) { [weak self] v in self?.alerts = (v as? [SharedCore.Alert]) ?? [] })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.rerouteBanner) { [weak self] v in self?.rerouteBanner = v as? String })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.checkRequested) { [weak self] v in self?.checkRequested = asBool(v) })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.canPlan) { [weak self] v in self?.canPlan = asBool(v) })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.unreadCount) { [weak self] v in self?.unreadCount = asInt(v) })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.barriersOnMap) { [weak self] v in self?.barriersOnMap = (v as? [Barrier]) ?? [] })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.selectedBarrier) { [weak self] v in self?.selectedBarrier = v as? Barrier })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.fitPoints) { [weak self] v in self?.fitPoints = (v as? [GeoPoint]) ?? [] })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.mapFit) { [weak self] v in self?.mapFit = (v as? [GeoPoint]) ?? [] })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.searchCollapsed) { [weak self] v in self?.searchCollapsed = asBool(v) })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.homeBarriers) { [weak self] v in self?.homeBarriers = (v as? [Barrier]) ?? [] })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.homeFilter) { [weak self] v in self?.homeFilter = (v as? HomeFilter) ?? HomeFilter.all })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.tab) { [weak self] v in self?.tab = (v as? UserTab) ?? UserTab.home })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.nearby) { [weak self] v in self?.nearby = (v as? [NearbyVenue]) ?? [] })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.exploreFilter) { [weak self] v in self?.exploreFilter = (v as? ExploreFilter) ?? ExploreFilter.all })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.activeBooking) { [weak self] v in self?.activeBooking = v as? Booking })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.communityGroups) { [weak self] v in self?.communityGroups = (v as? [CommunityGroup]) ?? [] })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.communityMessages) { [weak self] v in self?.communityMessages = (v as? [String: [ChatMessage]]) ?? [:] })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.selectedGroupId) { [weak self] v in self?.selectedGroupId = (v as? String) ?? "c1" })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.isChatOpen) { [weak self] v in self?.isChatOpen = asBool(v) })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.events) { [weak self] v in
            if let error = v as? EventsError { self?.errorMessage = error.message ?? "Something went wrong" }
            if let ok = v as? EventsSuccess { self?.toast = ok.message ?? "Done" }
        })
    }

    deinit { watchers.cancelAll() }

    // ACTIONS FORWARDED TO SHARED VIEWMODEL
    func setTab(_ tab: UserTab) { viewModel.setTab(tab: tab) }
    func setHomeFilter(_ filter: HomeFilter) { viewModel.setHomeFilter(filter: filter) }
    func toggleDirections() { viewModel.toggleDirections() }
    func chooseOrigin(_ place: SharedCore.Place) { viewModel.chooseOrigin(place: place) }
    func chooseDestination(_ place: SharedCore.Place) { viewModel.chooseDestination(place: place) }
    func selectBarrier(_ id: String?) { viewModel.selectBarrier(id: id) }
    func showOnMap(_ barrierId: String) { viewModel.showOnMap(barrierId: barrierId) }
    func setExploreFilter(_ filter: ExploreFilter) { viewModel.setExploreFilter(filter: filter) }
    func goTo(_ venue: Venue) { viewModel.goTo(venue: venue) }
    func bookHelper(_ kind: HelpKind, destination: String, slot: String, note: String, minutes: Int) {
        viewModel.bookHelper(kind: kind, destination: destination, slot: slot, note: note, minutes: Int32(minutes))
    }
    func cancelBooking(_ id: String) { viewModel.cancelBooking(id: id) }
    func postReview(_ venueId: String, rating: Int, need: String, text: String) {
        viewModel.postReview(venueId: venueId, rating: Int32(rating), need: need, text: text)
    }
    func dismissBanner() { viewModel.dismissBanner() }
    func editSearch() { viewModel.editSearch() }
    func findRoute() { viewModel.findRoute() }
    func askHelperToCheck() { viewModel.askHelperToCheck() }
    func selectCommunityGroup(_ id: String) { viewModel.selectCommunityGroup(groupId: id) }
    func setChatOpen(_ open: Bool) { viewModel.setChatOpen(open: open) }
    func sendCommunityMessage(_ text: String) { viewModel.sendCommunityMessage(text: text) }
}
