import SwiftUI
import Combine
import SharedCore

@MainActor
class AuthViewModelBridge: ObservableObject {
    private let viewModel = AppModuleKt.getAuthViewModel()
    private let watchers = WatcherBag()

    @Published var user: SharedCore.User? = nil
    @Published var isLoading: Bool = false
    @Published var onboardingDone: Bool = false
    @Published var errorMessage: String? = nil

    init() {
        watchers.add(FlowWatcherKt.watch(flow: viewModel.user) { [weak self] value in
            self?.user = value as? SharedCore.User
        })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.isLoading) { [weak self] value in
            self?.isLoading = asBool(value)
        })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.onboardingDone) { [weak self] value in
            self?.onboardingDone = asBool(value)
        })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.events) { [weak self] value in
            if let error = value as? EventsError {
                self?.errorMessage = error.message ?? "Something went wrong"
            }
        })
    }

    deinit { watchers.cancelAll() }

    // ACTIONS FORWARDED TO SHARED VIEWMODEL
    func finishOnboarding() { viewModel.finishOnboarding() }
    func loginAsUser() { viewModel.login(role: Role.user) }
    func loginAsHelper() { viewModel.login(role: Role.helper) }
    func logout() { viewModel.logout() }
}
