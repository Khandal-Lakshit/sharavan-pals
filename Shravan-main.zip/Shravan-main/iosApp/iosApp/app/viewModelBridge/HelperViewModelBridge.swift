import SwiftUI
import Combine
import SharedCore

@MainActor
class HelperViewModelBridge: ObservableObject {
    private let viewModel = AppModuleKt.getHelperViewModel()
    private let watchers = WatcherBag()

    @Published var userName: String = ""
    @Published var userBadge: String = ""
    @Published var requests: [HelpRequest] = []
    @Published var incomingAlert: HelpRequest? = nil
    @Published var selectedRequestId: String? = nil
    @Published var requestedRoute: [GeoPoint] = []
    @Published var barriers: [Barrier] = []
    @Published var location: GeoPoint? = nil
    @Published var status: BarrierType? = nil
    @Published var note: String = ""
    @Published var hasPhoto: Bool = false
    @Published var isSubmitting: Bool = false
    @Published var canSubmit: Bool = false
    @Published var lastResult: ReportResult? = nil
    @Published var errorMessage: String? = nil

    let barrierTypes: [BarrierType] = (AppModuleKt.getBarrierTypes() as? [BarrierType]) ?? []

    init() {
        watchers.add(FlowWatcherKt.watch(flow: viewModel.userName) { [weak self] v in self?.userName = (v as? String) ?? "" })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.userBadge) { [weak self] v in self?.userBadge = (v as? String) ?? "" })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.requests) { [weak self] v in self?.requests = (v as? [HelpRequest]) ?? [] })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.incomingAlert) { [weak self] v in self?.incomingAlert = v as? HelpRequest })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.selectedRequestId) { [weak self] v in self?.selectedRequestId = v as? String })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.requestedRoute) { [weak self] v in self?.requestedRoute = (v as? [GeoPoint]) ?? [] })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.barriers) { [weak self] v in self?.barriers = (v as? [Barrier]) ?? [] })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.location) { [weak self] v in self?.location = v as? GeoPoint })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.status) { [weak self] v in self?.status = v as? BarrierType })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.note) { [weak self] v in self?.note = (v as? String) ?? "" })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.photo) { [weak self] v in self?.hasPhoto = (v != nil) })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.isSubmitting) { [weak self] v in self?.isSubmitting = asBool(v) })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.canSubmit) { [weak self] v in self?.canSubmit = asBool(v) })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.lastResult) { [weak self] v in self?.lastResult = v as? ReportResult })
        watchers.add(FlowWatcherKt.watch(flow: viewModel.events) { [weak self] v in
            if let error = v as? EventsError { self?.errorMessage = error.message ?? "Something went wrong" }
        })
    }

    deinit { watchers.cancelAll() }

    // ACTIONS FORWARDED TO SHARED VIEWMODEL
    func selectRequest(_ id: String?) { viewModel.selectRequest(id: id) }
    func acceptAlert(_ id: String) { viewModel.acceptAlert(id: id) }
    func dismissAlert(_ id: String) { viewModel.dismissAlert(id: id) }
    func setLocation(_ lat: Double, _ lon: Double) { viewModel.setLocation(point: GeoPoint(lat: lat, lon: lon)) }
    func clearLocation() { viewModel.clearLocation() }
    func setStatus(_ type: BarrierType) { viewModel.setStatus(type: type) }
    func setNote(_ text: String) { viewModel.setNote(text: text) }
    func setPhoto(jpegBase64: String?) {
        if let value = jpegBase64 {
            viewModel.setPhoto(bytes: PhotoBridgeKt.photoFromBase64(value: value))
        } else {
            viewModel.setPhoto(bytes: nil)
        }
    }
    func submit() { viewModel.submit() }
    func markRouteChecked() { viewModel.markRouteChecked() }
}
