import SwiftUI
import CoreLocation
import SharedCore

struct HelperHomeView: View {
    let onLogout: () -> Void
    @StateObject private var bridge = HelperViewModelBridge()
    @StateObject private var location = LocationProvider()
    @State private var showPicker = false
    @State private var showProfile = false
    @State private var pickedImage: UIImage? = nil
    @State private var gpsFocus: GeoPoint? = nil
    @State private var placeName: String? = nil

    var body: some View {
        ZStack(alignment: .top) {
            RaahiMapView(
                safe: bridge.requestedRoute,
                barriers: bridge.barriers,
                marker: bridge.location,
                focus: gpsFocus,
                fitTo: bridge.requestedRoute,
                onMapTap: { bridge.setLocation($0.lat, $0.lon) }
            )
            .ignoresSafeArea()

            VStack {
                FloatingTopCard(
                    title: bridge.userName.isEmpty ? "🧭 Shravan Helping Hand" : "🧭 Shravan · Hello, \(bridge.userName)",
                    subtitle: bridge.userBadge.isEmpty ? "Report what you see on the ground" : "✓ \(bridge.userBadge) · Report what you see",
                    onLogout: { showProfile = true }
                ) {
                    if let point = bridge.location {
                        // The location is set: the GPS button gives way to a status line with a way to change it.
                        HStack(spacing: 10) {
                            GlyphBadge(glyph: "📍", size: 40, tint: RaahiTheme.primary)
                            VStack(alignment: .leading, spacing: 2) {
                                let place = placeName ?? DemoArea.shared.cityFor(point: point)
                                Text(place ?? "Location set").font(.poppins(15, weight: .semibold)).lineLimit(1)
                                Text((place != nil ? "Location set · " : "") + String(format: "%.5f, %.5f", point.lat, point.lon))
                                    .font(.inter(13)).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Button("Change") {
                                gpsFocus = nil
                                bridge.clearLocation()
                            }
                            .font(.inter(15, weight: .semibold))
                            .buttonStyle(.glass)
                        }
                        .accessibilityElement(children: .combine)
                    } else {
                        HStack(spacing: 12) {
                            Button {
                                location.request { lat, lon in
                                    bridge.setLocation(lat, lon)
                                    gpsFocus = GeoPoint(lat: lat, lon: lon)
                                }
                            } label: {
                                Label("Use my GPS", systemImage: "location.fill")
                                    .font(.poppins(15, weight: .semibold))
                                    .frame(minHeight: 30)
                            }
                            .buttonStyle(.glassProminent)
                            .tint(RaahiTheme.primary)

                            Text("Or tap the map")
                                .font(.inter(14))
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                if let request = bridge.incomingAlert {
                    HelpAlertCard(
                        request: request,
                        onCheck: { bridge.acceptAlert(request.id) },
                        onLater: { bridge.dismissAlert(request.id) }
                    )
                }
                Spacer()
            }
        }
        .sheet(isPresented: .constant(true)) {
            ScrollView {
                HelperPanelContent(
                    bridge: bridge,
                    pickedImage: $pickedImage,
                    showPicker: $showPicker
                )
                .padding(.horizontal, 20)
                .padding(.top, 16)
                .padding(.bottom, 24)
            }
            .scrollDismissesKeyboard(.interactively)
            .presentationDetents([.height(180), .fraction(0.75), .large])
            .presentationBackgroundInteraction(.enabled)
            .presentationDragIndicator(.visible)
            .presentationCornerRadius(32)
            .presentationBackground(RaahiTheme.surface)
            .interactiveDismissDisabled(true)
        }
        .sheet(isPresented: $showPicker) {
            ImagePicker { image in
                pickedImage = image
                bridge.setPhoto(jpegBase64: image.jpegBase64ForUpload())
            }
            .ignoresSafeArea()
        }
        .sheet(isPresented: $showProfile) {
            HelperProfileSheet(
                userName: bridge.userName,
                userBadge: bridge.userBadge,
                onLogout: { showProfile = false; onLogout() },
                onDismiss: { showProfile = false }
            )
            .presentationDetents([.medium, .large])
            .presentationDragIndicator(.visible)
            .presentationCornerRadius(28)
        }
        .task(id: bridge.location?.lat) {
            placeName = nil
            guard let point = bridge.location else { return }
            // City / area name for the chosen point; falls back to coordinates when offline.
            let marks = try? await CLGeocoder().reverseGeocodeLocation(CLLocation(latitude: point.lat, longitude: point.lon))
            if let m = marks?.first {
                let parts = [m.subLocality ?? m.thoroughfare, m.locality].compactMap { $0 }
                placeName = parts.isEmpty ? nil : Array(NSOrderedSet(array: parts)).compactMap { $0 as? String }.joined(separator: ", ")
            }
        }
        .onChange(of: bridge.hasPhoto) { _, has in
            if !has { pickedImage = nil }
        }
        .onChange(of: location.failed) { _, failed in
            if failed { bridge.errorMessage = "Could not get a GPS fix. Tap the map instead." }
        }
        .errorAlert($bridge.errorMessage)
    }
}

/// "Asha needs help around this route": shown when a user asks for a check; Check route opens it on the map.
private struct HelpAlertCard: View {
    let request: HelpRequest
    let onCheck: () -> Void
    let onLater: () -> Void

    var body: some View {
        let city = request.polyline.first.flatMap { DemoArea.shared.cityFor(point: $0) }
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top, spacing: 12) {
                Text("🔔")
                    .font(.system(size: 20))
                    .frame(width: 40, height: 40)
                    .background(RaahiTheme.surface, in: Circle())
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 2) {
                    Text("\(request.userName) needs help").font(.poppins(15, weight: .semibold))
                    Text("Please check this route: \(request.title)" + (city.map { " · \($0)" } ?? ""))
                        .font(.inter(14))
                }
            }
            HStack(spacing: 10) {
                Button(action: onCheck) {
                    Text("Check route").font(.poppins(15, weight: .semibold)).frame(minHeight: 32)
                }
                .buttonStyle(.glassProminent)
                .tint(RaahiTheme.primary)
                Button("Later", action: onLater)
                    .font(.inter(15, weight: .medium))
                    .frame(minHeight: 44)
            }
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RaahiTheme.tint, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(RaahiTheme.primary.opacity(0.6), lineWidth: 0.5))
        .padding(.horizontal, 16)
        .accessibilityElement(children: .contain)
    }
}

private struct HelperPanelContent: View {
    @ObservedObject var bridge: HelperViewModelBridge
    @Binding var pickedImage: UIImage?
    @Binding var showPicker: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            section("What do you see?") {
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
                    ForEach(bridge.barrierTypes, id: \.name) { type in
                        typeTile(type)
                    }
                }
            }

            section("Route to check") {
                if bridge.requests.isEmpty {
                    Text("No open requests right now. You can still report any barrier you see.")
                        .font(.inter(15))
                        .foregroundStyle(.secondary)
                } else {
                    VStack(spacing: 8) {
                        ForEach(bridge.requests, id: \.id) { request in
                            requestRow(request)
                        }
                        Button(action: bridge.markRouteChecked) {
                            Text("Mark route checked")
                                .font(.poppins(16, weight: .semibold))
                                .frame(maxWidth: .infinity, minHeight: 30)
                        }
                        .buttonStyle(.glass)
                        .controlSize(.regular)
                        .disabled(bridge.selectedRequestId == nil)
                    }
                }
            }

            section("Photo and note") {
                HStack(spacing: 12) {
                    Button { showPicker = true } label: {
                        Label(bridge.hasPhoto ? "Retake photo" : "Take photo", systemImage: "camera")
                            .font(.poppins(15, weight: .semibold))
                            .frame(minHeight: 30)
                    }
                    .buttonStyle(.glass)
                    if let image = pickedImage {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 48, height: 48)
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                            .accessibilityLabel("Preview of the photo you took")
                    }
                }
                TextField("Note (optional)", text: Binding(get: { bridge.note }, set: { bridge.setNote($0) }))
                    .font(.inter(16))
                    .padding(14)
                    .flatSurface(RoundedRectangle(cornerRadius: 16, style: .continuous), fill: RaahiTheme.fill)
            }

            Button(action: bridge.submit) {
                Group {
                    if bridge.isSubmitting { ProgressView() }
                    else { Text("Submit report").font(.poppins(17, weight: .semibold)) }
                }
                .frame(maxWidth: .infinity, minHeight: 32)
            }
            .buttonStyle(.glassProminent)
            .tint(RaahiTheme.primary)
            .controlSize(.regular)
            .disabled(!bridge.canSubmit)

            if let result = bridge.lastResult {
                FlatCard(tint: RaahiTheme.success) {
                    HStack(alignment: .top, spacing: 12) {
                        GlyphBadge(glyph: "✅", size: 40, tint: RaahiTheme.success)
                        VStack(alignment: .leading, spacing: 4) {
                            HStack(spacing: 8) {
                                Text("Report saved").font(.poppins(16, weight: .semibold))
                                if result.verified { Pill(text: "Verified", tint: RaahiTheme.success) }
                            }
                            Text("Matched to footpath \(result.segmentId), \(Int(result.snapDistanceM)) m from your point.")
                                .font(.inter(15))
                            if let suggestion = result.aiSuggestion {
                                Text("Demo detection: \(suggestion)").font(.inter(13)).foregroundStyle(.secondary)
                            }
                        }
                    }
                }
            }
        }
    }

    private func section<Content: View>(_ title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionTitle(text: title)
            content()
        }
    }

    /// One barrier type: round icon and label. Selected = green outline on a green tint.
    private func typeTile(_ type: BarrierType) -> some View {
        let selected = bridge.status == type
        return Button { bridge.setStatus(type) } label: {
            HStack(spacing: 10) {
                Text(type.symbol)
                    .font(.system(size: 18))
                    .frame(width: 36, height: 36)
                    .background(RaahiTheme.surface, in: Circle())
                    .accessibilityHidden(true)
                Text(type.label)
                    .font(.inter(14, weight: .medium))
                    .foregroundStyle(.primary)
                    .multilineTextAlignment(.leading)
                    .lineLimit(2)
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .frame(maxWidth: .infinity, minHeight: 48, alignment: .leading)
            .background(selected ? RaahiTheme.tint : RaahiTheme.fill, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(selected ? RaahiTheme.primary : RaahiTheme.hairline, lineWidth: selected ? 2 : 0.5)
            )
        }
        .buttonStyle(.plain)
        .accessibilityLabel(type.label)
        .accessibilityAddTraits(selected ? .isSelected : [])
    }

    private func requestRow(_ request: HelpRequest) -> some View {
        let selected = bridge.selectedRequestId == request.id
        return Button {
            bridge.selectRequest(selected ? nil : request.id)
        } label: {
            HStack(spacing: 12) {
                Avatar(name: request.userName, size: 40)
                VStack(alignment: .leading, spacing: 2) {
                    Text(request.userName).font(.poppins(15, weight: .semibold)).foregroundStyle(.primary)
                    Text(request.title).font(.inter(14)).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: selected ? "largecircle.fill.circle" : "circle")
                    .foregroundStyle(selected ? RaahiTheme.primary : Color.secondary)
            }
            .padding(10)
            .frame(maxWidth: .infinity, minHeight: 52, alignment: .leading)
            .background(selected ? RaahiTheme.tint : RaahiTheme.fill, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(selected ? RaahiTheme.primary : RaahiTheme.hairline, lineWidth: selected ? 2 : 0.5)
            )
        }
        .buttonStyle(.plain)
        .accessibilityLabel("\(request.userName) asks: \(request.title). \(selected ? "Selected." : "Double tap to select.")")
    }
}
