import SwiftUI
import SharedCore

/// Small rounded label, for statuses like NEW, Planned, Verified.
struct Pill: View {
    let text: String
    var tint: Color = RaahiTheme.deep

    var body: some View {
        Text(text)
            .font(.inter(12, weight: .medium))
            .foregroundStyle(tint)
            .padding(.horizontal, 10)
            .padding(.vertical, 4)
            .background(tint.opacity(0.12), in: Capsule())
    }
}

/// Round tinted badge that holds an emoji or a single glyph.
struct GlyphBadge: View {
    let glyph: String
    var size: CGFloat = 44
    var tint: Color = RaahiTheme.primary

    var body: some View {
        Text(glyph)
            .font(.system(size: size * 0.45))
            .frame(width: size, height: size)
            .background(tint.opacity(0.12), in: Circle())
            .accessibilityHidden(true)
    }
}

struct SectionTitle: View {
    let text: String
    var body: some View {
        Text(text)
            .font(.poppins(17, weight: .semibold))
            .foregroundStyle(.primary)
            .accessibilityAddTraits(.isHeader)
    }
}

extension View {
    /// Plain card: fill, 0.5 pt border, no shadow, no glass.
    func flatSurface<S: Shape>(_ shape: S, fill: Color = RaahiTheme.surface) -> some View {
        background(fill, in: shape).overlay(shape.stroke(RaahiTheme.hairline, lineWidth: 0.5))
    }
}

/// Flat tinted container, same role as RaahiCard on Android.
/// Bottom spacing that keeps content clear of the floating tab bar (40 pt buttons + 5 pt padding each side + 2 pt gap).
enum Metrics {
    static let tabBarClearance: CGFloat = 54      // screens that scroll under the bar
    static let cardAboveBar: CGFloat = 56         // floating cards sit 6 pt above the 50 pt bar
    static let bannerSpace: CGFloat = 58          // the floating booking card (50 pt) plus its gap
}

struct FlatCard<Content: View>: View {
    var tint: Color? = nil
    @ViewBuilder var content: () -> Content

    var body: some View {
        content()
            .padding(10)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(tint.map { $0.opacity(0.12) } ?? RaahiTheme.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(tint.map { $0.opacity(0.45) } ?? RaahiTheme.hairline, lineWidth: 0.5))
    }
}

/// One of two side-by-side route summaries.
struct RouteStat: View {
    let title: String
    let meters: Int
    let minutes: Int
    let barriers: Int
    let highlighted: Bool
    var extra: String? = nil
    var imagery: RouteImagery? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).font(.inter(14, weight: .medium))
            Text("\(meters) m").font(.poppins(24, weight: .bold))
            Text("about \(minutes) min").font(.inter(14))
            Text(barriers == 0 ? "No barriers" : "\(barriers) barrier\(barriers == 1 ? "" : "s")")
                .font(.poppins(14, weight: .semibold))
                .padding(.top, 4)
            if let extra { Text(extra).font(.inter(12)) }
            if let imagery, imagery.segmentCount > 0 {
                Text("\(imagery.confidencePct)% sure")
                    .font(.poppins(14, weight: .semibold))
                    .padding(.top, 6)
                Text(imagery.noRecentCount == 0
                     ? "Imagery up to date"
                     : "\(imagery.noRecentCount) of \(imagery.segmentCount) segments without recent imagery")
                    .font(.inter(12))
            }
        }
        .foregroundStyle(highlighted ? Color.white : Color.primary)
        .padding(10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .flatSurface(RoundedRectangle(cornerRadius: 20, style: .continuous), fill: highlighted ? RaahiTheme.deep : RaahiTheme.fill)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(title): \(meters) metres, about \(minutes) minutes, \(barriers) barriers. "
            + (imagery.map { "Confidence \($0.confidencePct) percent, \($0.noRecentCount) segments without recent imagery." } ?? ""))
    }
}

/// Legend swatch: the line style matches the map (solid blue = barrier-free, dashed orange = normal).
struct RouteLegend: View {
    var body: some View {
        HStack(spacing: 20) {
            item(RaahiTheme.safe, dashed: false, text: "Barrier-free")
            item(RaahiTheme.warn, dashed: true, text: "Normal route")
        }
    }

    private func item(_ color: Color, dashed: Bool, text: String) -> some View {
        HStack(spacing: 8) {
            Path { p in
                p.move(to: CGPoint(x: 0, y: 5))
                p.addLine(to: CGPoint(x: 32, y: 5))
            }
            .stroke(color, style: StrokeStyle(lineWidth: 5, lineCap: .round, dash: dashed ? [6, 6] : []))
            .frame(width: 32, height: 10)
            Text(text).font(.inter(13)).foregroundStyle(.secondary)
        }
    }
}

struct BarrierRow: View {
    let barrier: Barrier
    let onTap: () -> Void

    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 12) {
                GlyphBadge(glyph: barrier.type.symbol, size: 34, tint: RaahiTheme.warn)
                VStack(alignment: .leading, spacing: 2) {
                    Text(barrier.type.label).font(.poppins(15, weight: .semibold)).foregroundStyle(.primary)
                    Text(reporterLine(barrier))
                        .font(.inter(13)).foregroundStyle(.secondary)
                }
                Spacer()
                Pill(text: barrier.verified ? "Verified" : "AI ?", tint: barrier.verified ? RaahiTheme.success : RaahiTheme.warn)
            }
            .padding(10)
            .frame(maxWidth: .infinity, minHeight: 50)
            .flatSurface(RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
        .buttonStyle(.plain)
        .accessibilityLabel("\(barrier.type.label). \(reporterLine(barrier)). Double tap for details.")
    }
}

/// "How sure are we?": a confidence score per route (from photo age and coverage) and how many segments have
/// no recent imagery. Plain card, 0.5 pt border, no shadow. Words and numbers carry the meaning, colour only helps.
struct ConfidenceCard: View {
    let barrierFree: RouteImagery
    let normal: RouteImagery

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text("How sure are we?").font(.poppins(17, weight: .semibold))
                Text("Score from how old and how complete the street photos are.")
                    .font(.inter(13)).foregroundStyle(.secondary)
            }
            row("Barrier-free route", barrierFree)
            Divider().overlay(RaahiTheme.hairline)
            row("Normal route", normal)
            Text("No recent imagery means no street photo, or one older than 90 days.")
                .font(.inter(13)).foregroundStyle(.secondary)
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .flatSurface(RoundedRectangle(cornerRadius: 20, style: .continuous))
    }

    private func color(_ imagery: RouteImagery) -> Color {
        let pct = Int(imagery.confidencePct)
        if pct >= 75 { return RaahiTheme.deep }
        if pct >= 50 { return RaahiTheme.amber }
        return Color(.systemRed)
    }

    private func levelText(_ imagery: RouteImagery) -> String {
        let pct = Int(imagery.confidencePct)
        return pct >= 75 ? "High" : (pct >= 50 ? "Medium" : "Low")
    }

    private func gapText(_ imagery: RouteImagery) -> String {
        let gaps = Int(imagery.noRecentCount), total = Int(imagery.segmentCount)
        if total == 0 { return "No imagery information yet" }
        if gaps == 0 { return "All \(total) segments have recent imagery" }
        if gaps == 1 { return "1 of \(total) segments has no recent imagery" }
        return "\(gaps) of \(total) segments have no recent imagery"
    }

    private func row(_ title: String, _ imagery: RouteImagery) -> some View {
        let tint = color(imagery)
        let pct = Int(imagery.confidencePct)
        let gaps = Int(imagery.noRecentCount)
        return VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(title).font(.poppins(15, weight: .semibold))
                Spacer()
                Text("\(pct)%").font(.poppins(22, weight: .bold)).foregroundStyle(tint)
                Text(levelText(imagery)).font(.inter(14, weight: .medium)).foregroundStyle(tint)
            }
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(RaahiTheme.fill)
                    Capsule().fill(tint).frame(width: geo.size.width * CGFloat(pct) / 100)
                }
            }
            .frame(height: 8)
            Text(gapText(imagery))
                .font(.inter(15))
                .foregroundStyle(gaps > 0 ? Color.primary : Color.secondary)
            if Int(imagery.typicalAgeDays) > 0 {
                Text("Typical photo age: \(Int(imagery.typicalAgeDays)) days")
                    .font(.inter(13)).foregroundStyle(.secondary)
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(title). Confidence \(pct) percent, \(levelText(imagery)). \(gapText(imagery)).")
    }
}

/// Wrapping row for the barrier-type chips.
struct FlowLayout: Layout {
    var spacing: CGFloat = 8

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let maxWidth = proposal.width ?? .infinity
        var x: CGFloat = 0, y: CGFloat = 0, rowHeight: CGFloat = 0, width: CGFloat = 0
        for sub in subviews {
            let size = sub.sizeThatFits(.unspecified)
            if x + size.width > maxWidth, x > 0 {
                y += rowHeight + spacing
                x = 0
                rowHeight = 0
            }
            x += size.width + spacing
            rowHeight = max(rowHeight, size.height)
            width = max(width, x - spacing)
        }
        return CGSize(width: width, height: y + rowHeight)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        var x = bounds.minX, y = bounds.minY, rowHeight: CGFloat = 0
        for sub in subviews {
            let size = sub.sizeThatFits(.unspecified)
            if x + size.width > bounds.maxX, x > bounds.minX {
                y += rowHeight + spacing
                x = bounds.minX
                rowHeight = 0
            }
            sub.place(at: CGPoint(x: x, y: y), proposal: ProposedViewSize(size))
            x += size.width + spacing
            rowHeight = max(rowHeight, size.height)
        }
    }
}

/// Liquid Glass sheet that sits on top of the map and can be dragged between two heights.
struct BottomPanel<Content: View>: View {
    @Binding var expanded: Bool
    let collapsedHeight: CGFloat
    let expandedHeight: CGFloat
    @ViewBuilder var content: () -> Content
    @GestureState private var drag: CGFloat = 0

    var body: some View {
        let base = expanded ? expandedHeight : collapsedHeight
        let height = min(expandedHeight, max(collapsedHeight, base - drag))
        VStack(spacing: 0) {
            Capsule()
                .fill(Color.secondary.opacity(0.5))
                .frame(width: 40, height: 5)
                .frame(maxWidth: .infinity, minHeight: 32)
                .contentShape(Rectangle())
                .onTapGesture { withAnimation(.snappy) { expanded.toggle() } }
                .gesture(
                    DragGesture()
                        .updating($drag) { value, state, _ in state = value.translation.height }
                        .onEnded { value in
                            withAnimation(.snappy) {
                                if value.translation.height < -40 { expanded = true }
                                else if value.translation.height > 40 { expanded = false }
                            }
                        }
                )
                .accessibilityLabel(expanded ? "Collapse panel" : "Expand panel")
                .accessibilityAddTraits(.isButton)
            ScrollView {
                content()
                    .padding(.horizontal, 20)
                    .padding(.bottom, 24)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .scrollBounceBehavior(.basedOnSize)
            .scrollDismissesKeyboard(.interactively)
        }
        .frame(maxWidth: .infinity)
        .frame(height: height)
        .flatSurface(
            UnevenRoundedRectangle(topLeadingRadius: 32, bottomLeadingRadius: 0, bottomTrailingRadius: 0, topTrailingRadius: 32)
        )
    }
}

/// Floating Liquid Glass card at the top of the map: greeting, log out, and screen-specific controls.
struct FloatingTopCard<Content: View>: View {
    let title: String
    let subtitle: String
    let onLogout: () -> Void
    @ViewBuilder var content: () -> Content

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .center) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.poppins(20, weight: .bold))
                    Text(subtitle).font(.inter(14)).foregroundStyle(.secondary)
                }
                Spacer()
                Button(action: onLogout) {
                    Image(systemName: "rectangle.portrait.and.arrow.right")
                        .font(.system(size: 16, weight: .semibold))
                        .frame(width: 32, height: 32)
                }
                .buttonStyle(.glass)
                .accessibilityLabel("Log out")
            }
            content()
        }
        .padding(12)
        .flatSurface(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .padding(.horizontal, 16)
    }
}

/// iOS has no built-in toast, so errors use the system alert and short successes ("Booked. ... will meet you in 30 minutes.")
/// use this small capsule at the top of the screen, which hides itself after a moment.
extension View {
    func toast(_ message: Binding<String?>) -> some View {
        overlay(alignment: .top) {
            if let text = message.wrappedValue {
                Text(text)
                    .font(.inter(15, weight: .semibold))
                    .foregroundStyle(.white)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 18)
                    .padding(.vertical, 12)
                    .background(RaahiTheme.deep, in: Capsule())
                    .shadow(color: .black.opacity(0.2), radius: 8, y: 3)
                    .padding(.horizontal, 24)
                    .padding(.top, 8)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .accessibilityAddTraits(.updatesFrequently)
                    .task(id: text) {
                        try? await Task.sleep(nanoseconds: 2_500_000_000)
                        withAnimation(.snappy) { message.wrappedValue = nil }
                    }
            }
        }
        .animation(.snappy, value: message.wrappedValue)
    }

    func errorAlert(_ message: Binding<String?>) -> some View {
        alert(
            "Shravan",
            isPresented: Binding(get: { message.wrappedValue != nil }, set: { if !$0 { message.wrappedValue = nil } }),
            actions: { Button("OK", role: .cancel) {} },
            message: { Text(message.wrappedValue ?? "") }
        )
    }
}

// MARK: - Verified helpers (same pieces as Android: Avatar, ReporterLine, round pin, glass chips)

/// One sentence that says who reported a barrier and how far to trust it.
func reporterLine(_ barrier: Barrier) -> String {
    if let name = barrier.reporterName, let badge = barrier.reporterBadge { return "Reported by \(name) · \(badge)" }
    if let name = barrier.reporterName { return "Reported by \(name)" }
    if barrier.verified { return "Verified by a Helping Hand" }
    return "AI detected (\(Int(barrier.confidence * 100))% sure), not yet verified"
}

/// Round initial avatar. Helpers have no photos in the prototype, so the initial is the avatar everywhere.
struct Avatar: View {
    let name: String
    var size: CGFloat = 28

    var body: some View {
        Text(String(name.prefix(1)).uppercased())
            .font(.poppins(size * 0.45, weight: .bold))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(RaahiTheme.deep, in: Circle())
            .accessibilityHidden(true)
    }
}

/// Avatar + name + tick + badge, the "who told me this" line.
struct ReporterLine: View {
    let barrier: Barrier

    var body: some View {
        HStack(spacing: 8) {
            if let name = barrier.reporterName { Avatar(name: name, size: 28) }
            VStack(alignment: .leading, spacing: 1) {
                Text(barrier.reporterName ?? "AI suggestion").font(.poppins(15, weight: .semibold))
                if let badge = barrier.reporterBadge {
                    HStack(spacing: 4) {
                        Image(systemName: "checkmark.seal.fill").font(.system(size: 12)).foregroundStyle(RaahiTheme.deep)
                        Text(badge).font(.inter(13)).foregroundStyle(.secondary)
                    }
                }
            }
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel(reporterLine(barrier))
    }
}

/// The Home-map pin: white round badge with the barrier icon and the reporter's initial at the bottom right.
struct BarrierPin: View {
    let barrier: Barrier
    var selected: Bool = false

    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            Text(barrier.type.symbol)
                .font(.system(size: 19))
                .frame(width: 38, height: 38)
                .background(.white, in: Circle())
                .shadow(color: .black.opacity(0.25), radius: 4, y: 2)
            if let name = barrier.reporterName {
                Avatar(name: name, size: 18)
                    .overlay(Circle().stroke(.white, lineWidth: 2))
                    .offset(x: 4, y: 4)
            }
        }
        .overlay(alignment: .topTrailing) {
            if !barrier.verified {
                Text("?")
                    .font(.inter(11, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 16, height: 16)
                    .background(RaahiTheme.warn, in: Circle())
            }
        }
        .scaleEffect(selected ? 1.25 : 1)
        .animation(.spring(duration: 0.25), value: selected)
    }
}

/// Filter chip for the Home map. Plain white with a 0.5 pt border; selected = Messages green fill.
struct GlassChip: View {
    let label: String
    let selected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(label)
                .font(.poppins(15, weight: .semibold))
                .foregroundStyle(selected ? Color.white : Color.primary)
                .padding(.horizontal, 12)
                .frame(minHeight: 32)
        }
        .buttonStyle(.plain)
        .background(selected ? RaahiTheme.primary : RaahiTheme.surface, in: Capsule())
        .overlay(Capsule().stroke(selected ? Color.clear : RaahiTheme.hairline, lineWidth: 0.5))
        .accessibilityAddTraits(selected ? [.isSelected, .isButton] : .isButton)
    }
}

// MARK: - Floating tab bar

struct TabBarItem<ID: Hashable>: Identifiable {
    let id: ID
    let systemImage: String
    let label: String
    var badge: Int = 0
}

/// Floating pill. Deep green glass; icons are white and the active item sits in a white circle with a green icon. Icon-only, so each item has a label.
struct FloatingTabBar<ID: Hashable>: View {
    let items: [TabBarItem<ID>]
    @Binding var selection: ID

    var body: some View {
        HStack(spacing: 6) {
            ForEach(items) { item in
                let selected = item.id == selection
                Button {
                    withAnimation(.snappy) { selection = item.id }
                } label: {
                    Image(systemName: item.systemImage)
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(selected ? RaahiTheme.deep : Color.white)
                        .frame(width: 40, height: 40)
                        .background(selected ? Color.white : Color.clear, in: Circle())
                        .overlay(alignment: .topTrailing) {
                            if item.badge > 0 {
                                Text("\(item.badge)")
                                    .font(.inter(11, weight: .semibold))
                                    .foregroundStyle(.white)
                                    .padding(.horizontal, 5)
                                    .frame(minWidth: 18, minHeight: 18)
                                    .background(RaahiTheme.warn, in: Capsule())
                                    .offset(x: -2, y: 2)
                            }
                        }
                }
                .buttonStyle(.plain)
                .accessibilityLabel(item.label + (item.badge > 0 ? ", \(item.badge) unread" : ""))
                .accessibilityAddTraits(selected ? [.isButton, .isSelected] : .isButton)
            }
        }
        .padding(5)
        .glassEffect(.regular.tint(RaahiTheme.deep), in: Capsule())
        .padding(.bottom, 2)
    }
}
