import SwiftUI
import MapKit
import SharedCore

private func coordinate(_ point: GeoPoint) -> CLLocationCoordinate2D {
    CLLocationCoordinate2D(latitude: point.lat, longitude: point.lon)
}

/// Map used by both roles. Same contract as the Android RaahiMap: baseline (dashed), safe (solid), barriers, one marker.
struct RaahiMapView: View {
    var baseline: [GeoPoint] = []
    var safe: [GeoPoint] = []
    var barriers: [Barrier] = []
    /// Start (A) and end (B) of the planned route, drawn as lettered badges.
    var origin: GeoPoint? = nil
    var destination: GeoPoint? = nil
    var marker: GeoPoint? = nil
    /// When this changes to a non-null point the camera flies there (for example after "Use my GPS").
    var focus: GeoPoint? = nil
    var selectedBarrierId: String? = nil
    var fitTo: [GeoPoint] = []
    var onMapTap: ((GeoPoint) -> Void)? = nil
    var onBarrierTap: ((String) -> Void)? = nil

    // Demo area. The camera moves to the route as soon as there is one.
    private static let home = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 26.8432, longitude: 75.8072),
        span: MKCoordinateSpan(latitudeDelta: 0.012, longitudeDelta: 0.012)
    )

    @State private var camera: MapCameraPosition = .region(RaahiMapView.home)

    var body: some View {
        MapReader { proxy in
            Map(position: $camera) {
                if baseline.count > 1 {
                    MapPolyline(coordinates: baseline.map(coordinate))
                        .stroke(RaahiTheme.warn, style: StrokeStyle(lineWidth: 5, lineCap: .round, dash: [8, 8]))
                }
                if safe.count > 1 {
                    MapPolyline(coordinates: safe.map(coordinate))
                        .stroke(RaahiTheme.safe, style: StrokeStyle(lineWidth: 6, lineCap: .round))
                }
                if let origin {
                    Annotation("From", coordinate: coordinate(origin), anchor: .center) {
                        EndpointBadge(letter: "A", color: RaahiTheme.deep)
                    }
                }
                if let destination {
                    Annotation("To", coordinate: coordinate(destination), anchor: .center) {
                        EndpointBadge(letter: "B", color: Color(red: 0.11, green: 0.11, blue: 0.12))
                    }
                }
                ForEach(barriers, id: \.id) { barrier in
                    Annotation(barrier.type.label, coordinate: coordinate(barrier.point)) {
                        Button {
                            onBarrierTap?(barrier.id)
                        } label: {
                            BarrierPin(barrier: barrier, selected: barrier.id == selectedBarrierId)
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("\(barrier.type.label). \(reporterLine(barrier)). Double tap for details.")
                    }
                }
                if let marker {
                    Marker("You are here", coordinate: coordinate(marker)).tint(RaahiTheme.primary)
                }
            }
            .mapStyle(.standard(pointsOfInterest: .excludingAll))
            .mapControls { MapCompass() }
            .onTapGesture { screenPoint in
                guard let onMapTap, let tapped = proxy.convert(screenPoint, from: .local) else { return }
                onMapTap(GeoPoint(lat: tapped.latitude, lon: tapped.longitude))
            }
        }
        .onChange(of: fitKey) { _, _ in fit() }
        .onChange(of: focus?.lat) { _, _ in
            guard let focus else { return }
            withAnimation(.easeInOut) {
                camera = .region(MKCoordinateRegion(
                    center: coordinate(focus),
                    span: MKCoordinateSpan(latitudeDelta: 0.004, longitudeDelta: 0.004)
                ))
            }
        }
        .onAppear { fit() }
        .accessibilityLabel("Map. The normal route is dashed and the barrier-free route is solid. Barriers are listed in the panel.")
    }

    private var fitKey: String {
        "\(fitTo.count)-\(fitTo.first?.lat ?? 0)-\(fitTo.last?.lon ?? 0)"
    }

    private func fit() {
        guard fitTo.count > 1 else { return }
        let lats = fitTo.map { $0.lat }, lons = fitTo.map { $0.lon }
        guard let minLat = lats.min(), let maxLat = lats.max(), let minLon = lons.min(), let maxLon = lons.max() else { return }
        let center = CLLocationCoordinate2D(latitude: (minLat + maxLat) / 2, longitude: (minLon + maxLon) / 2)
        let span = MKCoordinateSpan(
            latitudeDelta: max(0.004, (maxLat - minLat) * 2.5),   // extra span: cards cover the top and bottom of the map
            longitudeDelta: max(0.004, (maxLon - minLon) * 1.7)
        )
        withAnimation(.easeInOut) { camera = .region(MKCoordinateRegion(center: center, span: span)) }
    }
}

/// Round letter badge for the From (A) and To (B) ends of a route.
private struct EndpointBadge: View {
    let letter: String
    let color: Color
    var body: some View {
        Text(letter)
            .font(.system(size: 15, weight: .bold))
            .foregroundStyle(.white)
            .frame(width: 32, height: 32)
            .background(color, in: Circle())
            .overlay(Circle().stroke(.white, lineWidth: 3))
            .accessibilityLabel(letter == "A" ? "Start of route" : "End of route")
    }
}
