import SwiftUI
import SharedCore

/// Helping Hand: book a verified person (a driver or an NGO partner) to help with travel, errands, a visit or reading.
/// It is its own feature and has nothing to do with the places in Explore. Once booked, the tab shows the booking
/// instead of the form, and the same booking floats above the tab bar on every tab.
struct HelpingHandTabView: View {
    @ObservedObject var bridge: RouteViewModelBridge

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Helping Hand").font(.poppins(26, weight: .bold))
                    Text("A verified person who helps you get around or get things done.")
                        .font(.inter(15)).foregroundStyle(.secondary)
                }
                .padding(.top, 8)

                if let booking = bridge.activeBooking {
                    Text("Your booking").font(.poppins(17, weight: .semibold))
                    FlatCard(tint: RaahiTheme.primary) {
                        BookingDetails(booking: booking) { bridge.cancelBooking(booking.id) }
                    }
                } else {
                    BookingForm(bridge: bridge)
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 24)
        }
        .scrollDismissesKeyboard(.interactively)
        .background(RaahiTheme.grouped)
    }
}

private struct BookingForm: View {
    @ObservedObject var bridge: RouteViewModelBridge
    @State private var kind: HelpKind? = nil
    @State private var slot: String = ""
    @State private var minutes: Int = 60
    @State private var destination = ""
    @State private var note = ""

    private var chosenKind: HelpKind? { kind ?? bridge.helpKinds.first }
    private var chosenSlot: String { slot.isEmpty ? (bridge.bookingSlots.first ?? "") : slot }

    private func price(_ m: Int) -> Int { (bridge.pricePerHour * m + 59) / 60 }
    private func durationLabel(_ m: Int) -> String {
        if m < 60 { return "\(m) minutes" }
        if m == 60 { return "1 hour" }
        return m % 60 == 0 ? "\(m / 60) hours" : "\(m / 60).5 hours"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            FlatCard(tint: RaahiTheme.primary) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Your price").font(.inter(12, weight: .medium)).foregroundStyle(.secondary)
                    Text("₹\(price(minutes))").font(.poppins(30, weight: .bold)).foregroundStyle(RaahiTheme.deep)
                    Text("for \(durationLabel(minutes)) with a verified Helping Hand. ₹\(bridge.pricePerHour) an hour, minimum 30 minutes. You pay them directly when you are done.")
                        .font(.inter(14))
                }
            }

            label("What do you need help with?")
            ForEach(bridge.helpKinds, id: \.name) { option in
                ChoiceRow(selected: option == chosenKind, title: option.label, subtitle: option.blurb, glyph: option.symbol) {
                    kind = option
                }
            }
            if let k = chosenKind {
                FlatCard {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("What you get").font(.poppins(15, weight: .semibold))
                        Text(k.detail).font(.inter(14)).foregroundStyle(.secondary)
                    }
                }
            }

            label("Where are you going? (optional)")
            TextField("A place, an address or a landmark", text: $destination)
                .font(.inter(16))
                .padding(.horizontal, 14)
                .frame(minHeight: 42)
                .background(RaahiTheme.surface, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(RaahiTheme.hairline, lineWidth: 0.5))

            label("When should they arrive?")
            ForEach(bridge.bookingSlots, id: \.self) { option in
                ChoiceRow(selected: option == chosenSlot, title: option, subtitle: nil, glyph: nil) { slot = option }
            }

            label("How long should they stay with you?")
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(bridge.bookingMinutes, id: \.self) { m in
                        GlassChip(label: "\(durationLabel(m)) · ₹\(price(m))", selected: m == minutes) { minutes = m }
                    }
                }
            }

            label("Anything they should know? (optional)")
            TextField("For example: I use a wheelchair", text: $note, axis: .vertical)
                .font(.inter(16))
                .lineLimit(2...4)
                .padding(14)
                .frame(minHeight: 60, alignment: .topLeading)
                .background(RaahiTheme.surface, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(RaahiTheme.hairline, lineWidth: 0.5))

            FlatCard {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Good to know").font(.poppins(15, weight: .semibold))
                    ForEach(bridge.bookingTerms, id: \.self) { line in
                        Text("•  \(line)").font(.inter(13)).foregroundStyle(.secondary)
                    }
                }
            }

            Button {
                if let k = chosenKind { bridge.bookHelper(k, destination: destination, slot: chosenSlot, note: note, minutes: minutes) }
            } label: {
                Text("Book for ₹\(price(minutes))").font(.poppins(17, weight: .semibold)).frame(maxWidth: .infinity, minHeight: 30)
            }
            .buttonStyle(.glassProminent)
            .tint(RaahiTheme.primary)
            .controlSize(.regular)
            .disabled(chosenKind == nil)
            .padding(.top, 4)
        }
    }

    private func label(_ text: String) -> some View {
        Text(text).font(.poppins(15, weight: .semibold)).padding(.top, 6)
    }
}

private struct ChoiceRow: View {
    let selected: Bool
    let title: String
    let subtitle: String?
    let glyph: String?
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                if let glyph { GlyphBadge(glyph: glyph, size: 34, tint: RaahiTheme.primary) }
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.poppins(15, weight: .semibold)).foregroundStyle(.primary)
                    if let subtitle { Text(subtitle).font(.inter(13)).foregroundStyle(.secondary) }
                }
                Spacer(minLength: 8)
                Image(systemName: selected ? "largecircle.fill.circle" : "circle")
                    .foregroundStyle(selected ? RaahiTheme.deep : Color.secondary)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .frame(minHeight: 44)
            .background(selected ? RaahiTheme.primary.opacity(0.14) : RaahiTheme.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .stroke(selected ? RaahiTheme.deep : RaahiTheme.hairline, lineWidth: selected ? 1 : 0.5)
            )
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(selected ? [.isButton, .isSelected] : .isButton)
    }
}

private func bookingDuration(_ m: Int32) -> String {
    let m = Int(m)
    if m < 60 { return "\(m) minutes" }
    if m == 60 { return "1 hour" }
    return m % 60 == 0 ? "\(m / 60) hours" : "\(m / 60).5 hours"
}

/// What the booking says, used inside the tab and inside the bottom sheet.
struct BookingDetails: View {
    let booking: Booking
    let onCancel: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 12) {
                Avatar(name: booking.helperName, size: 40)
                VStack(alignment: .leading, spacing: 2) {
                    Text(booking.helperName).font(.poppins(17, weight: .semibold))
                    if let badge = booking.helperBadge {
                        Label(badge, systemImage: "checkmark.seal.fill").font(.inter(12)).foregroundStyle(RaahiTheme.deep)
                    }
                }
                Spacer(minLength: 8)
                Pill(text: "Confirmed")
            }
            row("Helping with", "\(booking.kind.symbol)  \(booking.kind.label)")
            row("Meets you", booking.slot)
            row("How long", bookingDuration(booking.minutes))
            row("Price", "₹\(booking.price). Pay your Helping Hand by UPI or cash when you are done.")
            row("Going to", booking.destination.isEmpty ? "Not set. Tell them when they arrive." : booking.destination)
            if !booking.note.isEmpty { row("Your note", booking.note) }
            Button(action: onCancel) {
                Text("Cancel booking").font(.poppins(15, weight: .semibold)).foregroundStyle(.red).frame(maxWidth: .infinity, minHeight: 26)
            }
            .buttonStyle(.glass)
        }
    }

    private func row(_ title: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).font(.inter(12, weight: .medium)).foregroundStyle(.secondary)
            Text(value).font(.inter(16))
        }
        .accessibilityElement(children: .combine)
    }
}

/// The floating card above the tab bar. Tap it to open the booking.
struct BookingBanner: View {
    let booking: Booking
    let onTap: () -> Void

    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 12) {
                Avatar(name: booking.helperName, size: 34)
                VStack(alignment: .leading, spacing: 1) {
                    Text("Helping Hand booked").font(.poppins(15, weight: .semibold)).foregroundStyle(.primary)
                    Text("\(booking.helperName) · \(booking.slot)").font(.inter(14)).foregroundStyle(.secondary)
                }
                Spacer(minLength: 8)
                Image(systemName: "chevron.right").font(.system(size: 13, weight: .semibold)).foregroundStyle(RaahiTheme.deep)
            }
            .padding(.horizontal, 14)
            .frame(minHeight: 54)
            .background(RaahiTheme.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(RaahiTheme.deep.opacity(0.4), lineWidth: 0.5))
            .shadow(color: .black.opacity(0.18), radius: 10, y: 4)
        }
        .buttonStyle(.plain)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Helping Hand booked. \(booking.helperName) meets you \(booking.slot.prefix(1).lowercased() + booking.slot.dropFirst()).")
        .accessibilityHint("Shows the booking details")
    }
}

/// Content of the bottom sheet opened from the banner.
struct BookingSheet: View {
    let booking: Booking
    let onCancel: () -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                Text("Your Helping Hand").font(.poppins(24, weight: .bold))
                BookingDetails(booking: booking, onCancel: onCancel)
            }
            .padding(20)
        }
    }
}
