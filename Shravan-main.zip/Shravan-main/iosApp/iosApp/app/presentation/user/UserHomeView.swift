import SwiftUI
import SharedCore

private enum UserTabID: Hashable { case home, explore, community, help, alerts, planned }

struct UserHomeView: View {
    let onLogout: () -> Void
    @StateObject private var bridge = RouteViewModelBridge()
    @State private var selection: UserTabID = .home
    @State private var showBooking = false
    @State private var showProfile = false

    /// Room the floating booking card takes above the tab bar, so no screen hides content behind it.
    private var bannerSpace: CGFloat { bridge.activeBooking == nil ? 0 : Metrics.bannerSpace }

    var body: some View {
        ZStack(alignment: .bottom) {
            // Home stays alive behind the other tabs so the map keeps its camera.
            HomeTabView(bridge: bridge, onOpenProfile: { showProfile = true }, onLogout: onLogout)
                .opacity(selection == .home ? 1 : 0)
                .allowsHitTesting(selection == .home)
                .accessibilityHidden(selection != .home)
                .safeAreaInset(edge: .bottom, spacing: 0) { Color.clear.frame(height: bannerSpace) }
            if selection == .explore {
                ExploreTabView(bridge: bridge)
                    .safeAreaInset(edge: .bottom) { Color.clear.frame(height: Metrics.tabBarClearance + bannerSpace) }
            }
            if selection == .community {
                CommunityTabView(bridge: bridge)
                    .safeAreaInset(edge: .bottom) { Color.clear.frame(height: Metrics.tabBarClearance + bannerSpace) }
            }
            if selection == .help {
                HelpingHandTabView(bridge: bridge)
                    .safeAreaInset(edge: .bottom) { Color.clear.frame(height: Metrics.tabBarClearance + bannerSpace) }
            }
            if selection == .alerts {
                AlertsTabView(bridge: bridge)
                    .safeAreaInset(edge: .bottom) { Color.clear.frame(height: Metrics.tabBarClearance + bannerSpace) }
            }
            if selection == .planned {
                PlannedFeaturesView()
                    .safeAreaInset(edge: .bottom) { Color.clear.frame(height: Metrics.tabBarClearance + bannerSpace) }
            }
            if let booking = bridge.activeBooking {
                BookingBanner(booking: booking) { showBooking = true }
                    .padding(.horizontal, 16)
                    .padding(.bottom, Metrics.cardAboveBar)   // bar + gap + 8 between card and bar
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
            if !bridge.isChatOpen || selection != .community {
                FloatingTabBar(
                    items: [
                        TabBarItem(id: UserTabID.home, systemImage: "map.fill", label: "Home"),
                        TabBarItem(id: UserTabID.explore, systemImage: "safari.fill", label: "Explore places"),
                        TabBarItem(id: UserTabID.community, systemImage: "message.fill", label: "Community"),
                        TabBarItem(id: UserTabID.help, systemImage: "person.2.fill", label: "Helping Hand"),
                        TabBarItem(id: UserTabID.alerts, systemImage: "bell.fill", label: "Alerts", badge: bridge.unreadCount),
                        TabBarItem(id: UserTabID.planned, systemImage: "sparkles", label: "Coming next"),
                    ],
                    selection: $selection
                )
            }
        }
        .onChange(of: selection) { _, newValue in
            // Only tell the view model when the user changed tab here; a tab it switched itself (Route, Show on map) must not be reset.
            let wanted: UserTab
            switch newValue {
            case .home: wanted = UserTab.home
            case .explore: wanted = UserTab.explore
            case .community: wanted = UserTab.community
            case .help: wanted = UserTab.help
            case .alerts: wanted = UserTab.alerts
            case .planned: wanted = UserTab.planned
            }
            if wanted != bridge.tab { bridge.setTab(wanted) }
        }
        .onChange(of: bridge.tab) { _, newTab in
            // The view model switched tab itself, for example "Route" on a place or "Show on map" on an alert.
            let id: UserTabID
            switch newTab {
            case UserTab.home: id = .home
            case UserTab.explore: id = .explore
            case UserTab.community: id = .community
            case UserTab.help: id = .help
            case UserTab.alerts: id = .alerts
            default: id = .planned
            }
            if id != selection { withAnimation(.snappy) { selection = id } }
        }
        .animation(.snappy, value: bridge.activeBooking?.id)
        .sheet(isPresented: Binding(get: { showBooking && bridge.activeBooking != nil }, set: { showBooking = $0 })) {
            if let booking = bridge.activeBooking {
                BookingSheet(booking: booking) {
                    showBooking = false
                    bridge.cancelBooking(booking.id)
                }
                .presentationDetents([.medium, .large])
            }
        }
        .sheet(isPresented: $showProfile) {
            UserProfileSheet(
                userName: bridge.userName,
                city: bridge.cityName,
                onLogout: { showProfile = false; onLogout() },
                onDismiss: { showProfile = false }
            )
            .presentationDetents([.medium, .large])
            .presentationDragIndicator(.visible)
            .presentationCornerRadius(28)
        }
        .toast($bridge.toast)
        .errorAlert($bridge.errorMessage)
    }
}

// MARK: - Home tab (map, route search, route panel)

private struct HomeTabView: View {
    @ObservedObject var bridge: RouteViewModelBridge
    let onOpenProfile: () -> Void
    let onLogout: () -> Void

    var body: some View {
        ZStack {
            RaahiMapView(
                baseline: bridge.plan?.baseline.polyline ?? [],
                safe: bridge.plan?.safe.polyline ?? [],
                barriers: bridge.homeBarriers,
                origin: bridge.plan?.baseline.polyline.first,
                destination: bridge.plan?.baseline.polyline.last,
                selectedBarrierId: bridge.selectedBarrier?.id,
                fitTo: bridge.mapFit,
                onMapTap: { _ in bridge.selectBarrier(nil) },
                onBarrierTap: { bridge.selectBarrier($0) }
            )
            .ignoresSafeArea()

            VStack(spacing: 6) {
                HStack {
                    HStack(spacing: 6) {
                        Text("🧭").font(.system(size: 16))
                        Text("Shravan").font(.poppins(20, weight: .bold))
                    }
                    .foregroundStyle(RaahiTheme.deep)
                    .padding(.horizontal, 14)
                    .frame(minHeight: 34)
                    .flatSurface(Capsule())
                    Spacer()
                    Button(action: onOpenProfile) {
                        HStack(spacing: 8) {
                            Avatar(name: bridge.userName.isEmpty ? "A" : bridge.userName, size: 24)
                            Text(bridge.userName.isEmpty ? "Profile" : bridge.userName).font(.poppins(15, weight: .semibold))
                        }
                        .padding(.horizontal, 6)
                        .frame(minHeight: 34)
                    }
                    .buttonStyle(.plain)
                    .flatSurface(Capsule())
                }
                .padding(.horizontal, 16)

                Group {
                    if bridge.searchCollapsed {
                        CollapsedSearch(bridge: bridge)
                    } else {
                        ExpandedSearch(bridge: bridge)
                    }
                }
                .animation(.snappy, value: bridge.searchCollapsed)

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(bridge.homeFilters, id: \.name) { filter in
                            GlassChip(label: filter.label, selected: filter == bridge.homeFilter) {
                                bridge.setHomeFilter(filter)
                            }
                        }
                    }
                    .padding(.horizontal, 16)
                }

                Spacer()

                Group {
                    if let barrier = bridge.selectedBarrier {
                        BarrierCard(barrier: barrier, onClose: { bridge.selectBarrier(nil) })
                    } else if bridge.plan != nil && bridge.searchCollapsed {   // hidden while the user edits From / To
                        ViewThatFits(in: .vertical) {
                            RoutePanelContent(bridge: bridge)
                            ScrollView { RoutePanelContent(bridge: bridge) }
                        }
                        .frame(maxHeight: 200)
                    } else {
                        SummaryCard(barriers: bridge.homeBarriers, userName: bridge.userName, city: bridge.cityName)
                    }
                }
                .padding(8)
                .frame(maxWidth: .infinity, alignment: .leading)
                .flatSurface(RoundedRectangle(cornerRadius: 18, style: .continuous))
                .padding(.horizontal, 16)
                .padding(.bottom, Metrics.cardAboveBar)   // bar + gap + 8 between card and bar
            }
        }
    }
}

private struct ExpandedSearch: View {
    @ObservedObject var bridge: RouteViewModelBridge

    var body: some View {
        VStack(spacing: 6) {
            PlacePicker(label: "From", selected: bridge.origin, places: bridge.places, onSelect: bridge.chooseOrigin)
            PlacePicker(label: "To", selected: bridge.destination, places: bridge.places, onSelect: bridge.chooseDestination)
            Button(action: bridge.findRoute) {
                Group {
                    if bridge.isPlanning { ProgressView() }
                    else { Text("Find barrier-free route").font(.poppins(16, weight: .semibold)) }
                }
                .frame(maxWidth: .infinity, minHeight: 26)
            }
            .buttonStyle(.glassProminent)
            .tint(RaahiTheme.primary)
            .controlSize(.regular)
            .disabled(!bridge.canPlan || bridge.isPlanning)
        }
        .padding(8)
        .flatSurface(RoundedRectangle(cornerRadius: 18, style: .continuous))
        .padding(.horizontal, 16)
    }
}

/// After a search: just "From ... To ..." and an edit icon.
private struct CollapsedSearch: View {
    @ObservedObject var bridge: RouteViewModelBridge

    var body: some View {
        let from = bridge.origin?.name ?? ""
        let to = bridge.destination?.name ?? ""
        Button(action: bridge.editSearch) {
            HStack(spacing: 8) {
                VStack(alignment: .leading, spacing: 2) {
                    endpoint("From", from)
                    endpoint("To", to)
                }
                Spacer()
                Image(systemName: "pencil")
                    .font(.system(size: 15, weight: .semibold))
                    .frame(width: 32, height: 32)
                    .background(RaahiTheme.fill, in: Circle())
            }
            .padding(.leading, 14)
            .padding(.trailing, 6)
            .padding(.vertical, 6)
            .frame(maxWidth: .infinity)
        }
        .buttonStyle(.plain)
        .flatSurface(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .padding(.horizontal, 16)
        .accessibilityLabel("Route from \(from) to \(to). Double tap to edit.")
    }

    private func endpoint(_ label: String, _ name: String) -> some View {
        HStack(spacing: 10) {
            Text(label).font(.inter(12, weight: .medium)).foregroundStyle(.secondary).frame(width: 36, alignment: .leading)
            Text(name).font(.poppins(15, weight: .semibold)).lineLimit(1)
        }
    }
}

private struct SummaryCard: View {
    let barriers: [Barrier]
    let userName: String
    let city: String

    private var reporters: [String] {
        var seen: [String] = []
        for b in barriers { if let n = b.reporterName, !seen.contains(n) { seen.append(n) } }
        return seen
    }

    private var summary: String {
        if barriers.isEmpty { return "No reports for this filter" }
        if reporters.isEmpty { return "\(barriers.count) reports" }
        let names = reporters.prefix(2).joined(separator: " and ")
        let more = reporters.count > 2 ? " and \(reporters.count - 2) more" : ""
        return "\(barriers.count) reports by \(names)\(more)"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            if !city.isEmpty {
                Text("📍 \(city)").font(.inter(15, weight: .semibold)).foregroundStyle(RaahiTheme.deep)
            }
            Text(userName.isEmpty ? "Around you" : "Around you, \(userName)").font(.poppins(22, weight: .bold))
            HStack(spacing: 10) {
                HStack(spacing: -8) {
                    ForEach(Array(reporters.prefix(3).enumerated()), id: \.offset) { _, name in
                        Avatar(name: name, size: 24).overlay(Circle().stroke(.white, lineWidth: 2))
                    }
                }
                Text(summary).font(.inter(15)).foregroundStyle(.secondary)
            }
            Text("Tap a pin to see who reported it. Choose From and To above for a route that avoids them.")
                .font(.inter(13))
                .foregroundStyle(.secondary)
        }
    }
}

/// Selected pin. Round-one reports have no photos, so tinted tiles with the barrier icon stand in until imageUrl is set.
private struct BarrierCard: View {
    let barrier: Barrier
    let onClose: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                ForEach(0..<3, id: \.self) { i in
                    tile(i)
                }
            }
            HStack(spacing: 8) {
                Text(barrier.type.label).font(.poppins(22, weight: .bold))
                if barrier.verified {
                    Image(systemName: "checkmark.seal.fill")
                        .foregroundStyle(RaahiTheme.deep)
                        .accessibilityLabel("Verified report")
                }
                Spacer()
                Button(action: onClose) {
                    Image(systemName: "xmark")
                        .font(.system(size: 13, weight: .semibold))
                        .frame(width: 34, height: 34)
                }
                .buttonStyle(.glass)
                .accessibilityLabel("Close")
            }
            if let note = barrier.note, !note.isEmpty {
                Text(note).font(.inter(15)).foregroundStyle(.secondary)
            }
            ReporterLine(barrier: barrier)
        }
    }

    @ViewBuilder
    private func tile(_ i: Int) -> some View {
        if i == 0, let url = barrier.imageUrl, let imageURL = URL(string: url) {
            AsyncImage(url: imageURL) { image in
                image.resizable().scaledToFill()
            } placeholder: {
                RaahiTheme.fill
            }
            .frame(maxWidth: .infinity, minHeight: 44, maxHeight: 44)
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .accessibilityLabel("Photo of the barrier: \(barrier.type.label)")
        } else {
            Text(i == 0 ? barrier.type.symbol : "")
                .font(.system(size: 24))
                .frame(maxWidth: .infinity, minHeight: 44, maxHeight: 44)
                .background(i == 0 ? RaahiTheme.warn.opacity(0.14) : RaahiTheme.fill, in: RoundedRectangle(cornerRadius: 14))
                .accessibilityHidden(true)
        }
    }
}

private struct PlacePicker: View {
    let label: String
    let selected: SharedCore.Place?
    let places: [SharedCore.Place]
    let onSelect: (SharedCore.Place) -> Void

    var body: some View {
        Menu {
            ForEach(places, id: \.name) { place in
                Button(place.name) { onSelect(place) }
            }
        } label: {
            VStack(alignment: .leading, spacing: 2) {
                Text(label).font(.inter(12)).foregroundStyle(.secondary)
                Text(selected?.name ?? "Choose a place")
                    .font(.poppins(16, weight: .semibold))
                    .foregroundStyle(selected == nil ? Color.secondary : Color.primary)
                    .lineLimit(1)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 4)
            .frame(maxWidth: .infinity, minHeight: 40, alignment: .leading)
            .flatSurface(RoundedRectangle(cornerRadius: 12, style: .continuous), fill: RaahiTheme.fill)
        }
        .accessibilityLabel("\(label): \(selected?.name ?? "not chosen"). Double tap to change.")
    }
}

private struct RoutePanelContent: View {
    @ObservedObject var bridge: RouteViewModelBridge

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if let banner = bridge.rerouteBanner {
                FlatCard(tint: RaahiTheme.warn) {
                    HStack(alignment: .top, spacing: 12) {
                        GlyphBadge(glyph: "⚠️", size: 34, tint: RaahiTheme.warn)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Your route was updated").font(.poppins(16, weight: .semibold))
                            Text(banner).font(.inter(15))
                            Button("Dismiss", action: bridge.dismissBanner)
                                .font(.inter(15, weight: .medium))
                                .frame(minHeight: 34)
                        }
                    }
                }
            }

            if let plan = bridge.plan {
                Text("About \(plan.safe.durationMin) min · \(plan.safe.distanceM) m")
                    .font(.poppins(22, weight: .bold))
                HStack(spacing: 8) {
                    RouteStat(
                        title: "Barrier-free",
                        meters: Int(plan.safe.distanceM),
                        minutes: Int(plan.safe.durationMin),
                        barriers: plan.safe.barriers.count,
                        highlighted: true,
                        extra: plan.extraDistanceM > 0 ? "+\(plan.extraDistanceM) m longer" : nil,
                        imagery: plan.safe.imagery
                    )
                    RouteStat(
                        title: "Normal",
                        meters: Int(plan.baseline.distanceM),
                        minutes: Int(plan.baseline.durationMin),
                        barriers: plan.baseline.barriers.count,
                        highlighted: false,
                        imagery: plan.baseline.imagery
                    )
                }
                RouteLegend()
                ConfidenceCard(barrierFree: plan.safe.imagery, normal: plan.baseline.imagery)

                Button(action: bridge.askHelperToCheck) {
                    Text(bridge.checkRequested ? "Helping Hand asked ✓" : "Ask a Helping Hand to check this route")
                        .font(.poppins(16, weight: .semibold))
                        .frame(maxWidth: .infinity, minHeight: 26)
                }
                .buttonStyle(.glass)
                .controlSize(.regular)
                .disabled(bridge.checkRequested)

                if bridge.checkRequested {
                    Text("Helping Hands around this route were alerted. You will get an alert here when one has checked it.")
                        .font(.inter(13))
                        .foregroundStyle(.secondary)
                }

                if !bridge.barriersOnMap.isEmpty {
                    SectionTitle(text: "Barriers on the normal route")
                    VStack(spacing: 8) {
                        ForEach(bridge.barriersOnMap, id: \.id) { barrier in
                            BarrierRow(barrier: barrier) { bridge.selectBarrier(barrier.id) }
                        }
                    }
                }

                Button(bridge.showDirections ? "Hide directions" : "Show directions as text", action: bridge.toggleDirections)
                    .font(.inter(15, weight: .medium))
                    .frame(minHeight: 34)
                if bridge.showDirections {
                    VStack(alignment: .leading, spacing: 8) {
                        ForEach(Array(plan.safe.steps.enumerated()), id: \.offset) { index, step in
                            Text("\(index + 1). \(step.text)").font(.inter(16))
                        }
                    }
                }
            } else {
                Text("Barrier-free route").font(.poppins(22, weight: .bold))
                Text("Choose where you are and where you want to go. We will avoid steps and missing ramps.")
                    .font(.inter(16))
                    .foregroundStyle(.secondary)
            }
        }
    }
}

// MARK: - Alerts tab

private struct AlertsTabView: View {
    @ObservedObject var bridge: RouteViewModelBridge

    var body: some View {
        NavigationStack {
            Group {
                if bridge.alerts.isEmpty {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("No alerts yet").font(.poppins(22, weight: .bold))
                        Text("When a Helping Hand reports a problem on your route, or finishes checking it, it shows up here.")
                            .font(.inter(16))
                            .foregroundStyle(.secondary)
                    }
                    .padding(24)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                } else {
                    ScrollView {
                        LazyVStack(spacing: 12) {
                            ForEach(bridge.alerts, id: \.id) { alert in
                                AlertCardView(alert: alert, onShowOnMap: bridge.showOnMap)
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.top, 8)
                        .padding(.bottom, Metrics.tabBarClearance + 14)   // clear of the floating tab bar
                    }
                }
            }
            .background(RaahiTheme.grouped)
            .navigationTitle("Alerts")
        }
    }
}

/// One alert in full: what it is about, who sent it, where, what it did to the route, and a way to see it on the map.
private struct AlertCardView: View {
    let alert: SharedCore.Alert
    let onShowOnMap: (String) -> Void

    private var isWarning: Bool { alert.type == AlertType.routeIssue }
    private var caption: String {
        if alert.type == AlertType.routeIssue { return "WARNING ON YOUR ROUTE" }
        if alert.type == AlertType.routeChecked { return "ROUTE CHECKED" }
        return "UPDATE"
    }
    private var title: String {
        if let barrier = alert.barrier { return barrier.type.label }
        if alert.type == AlertType.routeChecked { return "A Helping Hand checked your route" }
        return alert.message
    }
    private var routeNote: String {
        guard let extra = alert.extraDistanceM?.intValue, extra != 0 else { return "Your route was updated" }
        return extra > 0 ? "Your route was updated, \(extra) m longer" : "Your route was updated, \(-extra) m shorter"
    }

    var body: some View {
        FlatCard(tint: alert.isRead ? nil : RaahiTheme.primary) {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 12) {
                    GlyphBadge(glyph: alert.barrier?.type.symbol ?? (isWarning ? "⚠️" : "✅"), size: 48, tint: isWarning ? RaahiTheme.warn : RaahiTheme.success)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(caption).font(.inter(12, weight: .semibold)).foregroundStyle(isWarning ? RaahiTheme.warn : RaahiTheme.deep)
                        Text(title).font(.poppins(20, weight: .bold))
                    }
                    Spacer(minLength: 8)
                    VStack(alignment: .trailing, spacing: 4) {
                        if !alert.isRead { Pill(text: "NEW") }
                        Text(formatTime(alert.createdAt)).font(.inter(13)).foregroundStyle(.secondary)
                    }
                }

                if let barrier = alert.barrier, let url = barrier.imageUrl, let imageURL = URL(string: url) {
                    AsyncImage(url: imageURL) { image in
                        image.resizable().scaledToFill()
                    } placeholder: {
                        RaahiTheme.fill
                    }
                    .frame(maxWidth: .infinity)
                    .aspectRatio(16.0 / 9.0, contentMode: .fit)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .accessibilityLabel("Photo from the Helping Hand: \(barrier.type.label)")
                }

                if let note = alert.barrier?.note, !note.isEmpty {
                    Text("\u{201C}\(note)\u{201D}").font(.inter(16))
                }

                if let place = alert.placeLabel {
                    HStack(alignment: .top, spacing: 8) {
                        Text("📍").accessibilityHidden(true)
                        Text(place).font(.inter(15)).foregroundStyle(.secondary)
                    }
                }

                if let name = alert.senderName {
                    HStack(spacing: 10) {
                        Avatar(name: name, size: 32)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(isWarning ? "Reported by \(name)" : "Checked by \(name)").font(.poppins(15, weight: .semibold))
                            if let badge = alert.senderBadge {
                                Label(badge, systemImage: "checkmark.seal.fill")
                                    .font(.inter(13))
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }

                if isWarning {
                    Text(routeNote)
                        .font(.inter(14, weight: .semibold))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(RaahiTheme.fill, in: Capsule())
                    if let barrier = alert.barrier {
                        Button { onShowOnMap(barrier.id) } label: {
                            Text("Show on map").font(.poppins(16, weight: .semibold)).frame(maxWidth: .infinity, minHeight: 28)
                        }
                        .buttonStyle(.glass)
                    }
                }
            }
            .accessibilityElement(children: .contain)
        }
    }
}

// MARK: - Coming next

private struct PlannedItem: Identifiable {
    let id = UUID()
    let glyph: String
    let title: String
    let body: String
}

private let plannedItems: [PlannedItem] = [
    PlannedItem(glyph: "🆘", title: "SOS with handling notes", body: "Hold for 3 seconds. Contacts get a push and a short link; the nearest partner hospital sees your location and your own instructions on how to move you."),
    PlannedItem(glyph: "🩺", title: "Medical and handling card", body: "You write how responders should help, for example \"do not lift under the arms\". Every field is optional and only shared during an SOS."),
    PlannedItem(glyph: "🚕", title: "Ride-app partners", body: "Verified drivers on ride apps report barriers as they drive. Needs a partnership with a ride company."),
    PlannedItem(glyph: "👥", title: "Friends and caretakers", body: "Trusted contacts, live location sharing, and verified Helping Hand partners."),
    PlannedItem(glyph: "🗣️", title: "Voice control", body: "\"Take me to the nearest cafe with a ramp\". Every voice action will also work by touch."),
]

private struct PlannedFeaturesView: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    Text("Designed with disabled users. Not live in this prototype.")
                        .font(.inter(16))
                        .foregroundStyle(.secondary)
                    ForEach(plannedItems) { item in
                        FlatCard {
                            HStack(alignment: .top, spacing: 12) {
                                GlyphBadge(glyph: item.glyph)
                                VStack(alignment: .leading, spacing: 4) {
                                    HStack {
                                        Text(item.title).font(.poppins(16, weight: .semibold))
                                        Pill(text: "Planned", tint: RaahiTheme.warn)
                                    }
                                    Text(item.body).font(.inter(14)).foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                    FlatCard {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Preview: card a responder would open").font(.poppins(15, weight: .semibold))
                            Text("Name: Asha (demo)").font(.inter(15))
                            Text("Uses: power wheelchair, battery is heavy").font(.inter(15))
                            Text("Handling: do not lift under the arms. Speak before touching.").font(.inter(15))
                            Text("Static mock. Nothing is sent anywhere.").font(.inter(12)).foregroundStyle(.secondary)
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 8)
                .padding(.bottom, Metrics.tabBarClearance + 14)   // clear of the floating tab bar
            }
            .background(RaahiTheme.grouped)
            .navigationTitle("Coming next")
        }
    }
}
