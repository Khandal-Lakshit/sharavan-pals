import SwiftUI
import SharedCore

private func distanceLabel(_ m: Int32) -> String {
    m < 1000 ? "\(m) m" : String(format: "%.1f km", Double(m) / 1000.0)
}

/// Friendly places around the user (demo data): access features, a Route button that opens the route from the user's
/// location on the Home map.
struct ExploreTabView: View {
    @ObservedObject var bridge: RouteViewModelBridge
    @State private var openVenueId: String? = nil

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 8) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Around you").font(.poppins(26, weight: .bold))
                    Text("Friendly places near your location. Demo data.")
                        .font(.inter(15)).foregroundStyle(.secondary)
                }
                .padding(.top, 8)

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(bridge.exploreFilters, id: \.name) { filter in
                            GlassChip(label: filter.label, selected: filter == bridge.exploreFilter) {
                                bridge.setExploreFilter(filter)
                            }
                        }
                    }
                }

                ForEach(bridge.nearby, id: \.venue.id) { item in
                    VenueCard(item: item, onRoute: { bridge.goTo(item.venue) }, onReviews: { openVenueId = item.venue.id })
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 24)
        }
        .background(RaahiTheme.grouped)
        .sheet(isPresented: Binding(get: { openVenueId != nil }, set: { if !$0 { openVenueId = nil } })) {
            if let id = openVenueId {
                VenueSheet(bridge: bridge, venueId: id)
                    .presentationDetents([.large])
                    .presentationDragIndicator(.visible)
            }
        }
    }
}

private struct VenueCard: View {
    let item: NearbyVenue
    let onRoute: () -> Void
    let onReviews: () -> Void

    var body: some View {
        let v = item.venue
        FlatCard {
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 10) {
                    GlyphBadge(glyph: v.category.symbol, size: 38, tint: RaahiTheme.primary)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(v.name).font(.poppins(17, weight: .semibold))
                        if v.isVerified { VerifiedBadge() }
                        Text("\(v.category.label) · \(distanceLabel(item.distanceM)) · ★ \(String(format: "%.1f", v.displayRating)) (\(v.reviews.count))")
                            .font(.inter(13)).foregroundStyle(.secondary)
                    }
                }
                FeatureWrap(features: v.features)
                Text(v.note).font(.inter(14)).foregroundStyle(.secondary)
                HStack(spacing: 10) {
                    Button(action: onRoute) {
                        Text("Route").font(.poppins(15, weight: .semibold)).frame(maxWidth: .infinity, minHeight: 26)
                    }
                    .buttonStyle(.glassProminent)
                    .tint(RaahiTheme.primary)
                    Button(action: onReviews) {
                        Text("Reviews").font(.poppins(15, weight: .semibold)).frame(maxWidth: .infinity, minHeight: 26)
                    }
                    .buttonStyle(.glass)
                    .tint(RaahiTheme.primary)
                }
            }
            .accessibilityElement(children: .contain)
        }
    }
}

/// The Shravan Verified mark: a place has shared its videos and answered the access Q&A.
private struct VerifiedBadge: View {
    var body: some View {
        Text("✓ Shravan Verified")
            .font(.inter(12, weight: .semibold))
            .foregroundStyle(RaahiTheme.primary)
            .padding(.horizontal, 8)
            .padding(.vertical, 2)
            .background(RaahiTheme.primary.opacity(0.14), in: Capsule())
            .accessibilityLabel("Shravan Verified")
    }
}

/// Verification checklist, reviews from other disabled visitors, and a way to add one.
private struct VenueSheet: View {
    @ObservedObject var bridge: RouteViewModelBridge
    let venueId: String
    @State private var writing = false
    @State private var stars = 5
    @State private var need = ""
    @State private var text = ""

    private var venue: Venue? { bridge.nearby.first { $0.venue.id == venueId }?.venue }

    var body: some View {
        ScrollView {
            if let v = venue {
                VStack(alignment: .leading, spacing: 14) {
                    HStack(spacing: 10) {
                        GlyphBadge(glyph: v.category.symbol, size: 40, tint: RaahiTheme.primary)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(v.name).font(.poppins(22, weight: .bold))
                            Text("★ \(String(format: "%.1f", v.displayRating)) from \(v.reviews.count) disabled visitors")
                                .font(.inter(13)).foregroundStyle(.secondary)
                        }
                    }

                    if v.category == VenueCategory.cafe { verification(v) }

                    Text("How other disabled visitors were treated").font(.poppins(16, weight: .semibold))
                    if v.reviews.isEmpty {
                        Text("No reviews yet. Be the first.").font(.inter(14)).foregroundStyle(.secondary)
                    }
                    ForEach(v.reviews, id: \.id) { r in reviewRow(r) }

                    if writing { form(v) } else {
                        Button { writing = true; if need.isEmpty { need = bridge.reviewerNeeds.first ?? "" } } label: {
                            Text("Write a review").font(.poppins(15, weight: .semibold)).frame(maxWidth: .infinity, minHeight: 28)
                        }
                        .buttonStyle(.glassProminent)
                        .tint(RaahiTheme.primary)
                    }
                }
                .padding(20)
            }
        }
        .background(RaahiTheme.grouped)
    }

    @ViewBuilder
    private func verification(_ v: Venue) -> some View {
        FlatCard {
            VStack(alignment: .leading, spacing: 6) {
                Text(v.isVerified ? "✓ Shravan Verified" : "Not verified yet")
                    .font(.poppins(16, weight: .semibold))
                    .foregroundStyle(v.isVerified ? RaahiTheme.primary : Color.primary)
                Text("A cafe earns this by sharing a video on each topic below and answering our access questions.")
                    .font(.inter(13)).foregroundStyle(.secondary)
                ForEach(bridge.verificationTopics, id: \.self) { topic in
                    let done = v.verification.videoTopics.contains(topic)
                    Text((done ? "✓  " : "○  ") + "\(topic) video " + (done ? "shared" : "missing"))
                        .font(.inter(14))
                        .foregroundStyle(done ? RaahiTheme.primary : Color.secondary)
                }
                Text("Access Q&A: \(v.verification.qaDone) of \(v.verification.qaTotal) answered")
                    .font(.inter(14))
                    .foregroundStyle(v.verification.qaDone >= v.verification.qaTotal ? RaahiTheme.primary : Color.secondary)
            }
        }
    }

    private func reviewRow(_ r: VenueReview) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Text(String(r.author.prefix(1)))
                .font(.poppins(15, weight: .bold))
                .foregroundStyle(.white)
                .frame(width: 36, height: 36)
                .background(RaahiTheme.primary, in: Circle())
            VStack(alignment: .leading, spacing: 2) {
                Text("\(r.author) · \(r.need)").font(.inter(14, weight: .semibold))
                Text(String(repeating: "★", count: Int(r.rating)) + "  " + r.whenLabel)
                    .font(.inter(12, weight: .semibold)).foregroundStyle(.orange)
                Text(r.text).font(.inter(14))
            }
        }
        .accessibilityElement(children: .combine)
    }

    @ViewBuilder
    private func form(_ v: Venue) -> some View {
        Text("How were you treated?").font(.poppins(15, weight: .semibold))
        HStack(spacing: 4) {
            ForEach(1...5, id: \.self) { i in
                Button { stars = i } label: {
                    Image(systemName: i <= stars ? "star.fill" : "star")
                        .font(.system(size: 26))
                        .foregroundStyle(i <= stars ? Color.orange : Color.secondary)
                        .frame(width: 44, height: 44)
                }
                .accessibilityLabel("\(i) stars")
            }
        }
        Text("About you").font(.poppins(15, weight: .semibold))
        FlowLayout(spacing: 8) {
            ForEach(bridge.reviewerNeeds, id: \.self) { option in
                GlassChip(label: option, selected: option == need) { need = option }
            }
        }
        TextField("Were staff patient? Was the washroom usable? Did you feel safe?", text: $text, axis: .vertical)
            .lineLimit(3...6)
            .font(.inter(15))
            .padding(12)
            .background(RaahiTheme.fill, in: RoundedRectangle(cornerRadius: 14))
        Button {
            bridge.postReview(v.id, rating: stars, need: need, text: text)
            text = ""; stars = 5; writing = false
        } label: {
            Text("Post review").font(.poppins(15, weight: .semibold)).frame(maxWidth: .infinity, minHeight: 28)
        }
        .buttonStyle(.glassProminent)
        .tint(RaahiTheme.primary)
        .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
    }
}

/// Feature chips that wrap onto as many lines as they need.
private struct FeatureWrap: View {
    let features: [String]

    var body: some View {
        FlowLayout(spacing: 6) {
            ForEach(features, id: \.self) { f in
                Text(f)
                    .font(.inter(12, weight: .semibold))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(RaahiTheme.fill, in: Capsule())
            }
        }
    }
}
