import SwiftUI
import SharedCore

struct CommunityTabView: View {
    @ObservedObject var bridge: RouteViewModelBridge
    @State private var activeChatGroup: CommunityGroup? = nil
    @State private var searchQuery: String = ""
    @State private var filterIndex: Int = 0

    private var filteredGroups: [CommunityGroup] {
        bridge.communityGroups.filter { g in
            (searchQuery.isEmpty || g.name.localizedCaseInsensitiveContains(searchQuery) || g.description_.localizedCaseInsensitiveContains(searchQuery)) &&
            (filterIndex == 0 || (filterIndex == 1 && g.unreadCount >= 0) || (filterIndex == 2 && g.unreadCount == 0))
        }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                if let active = activeChatGroup {
                    GroupChatView(
                        group: active,
                        messages: bridge.communityMessages[active.id] ?? [],
                        onBack: {
                            activeChatGroup = nil
                            bridge.setChatOpen(false)
                        },
                        onSendMessage: { bridge.sendCommunityMessage($0) }
                    )
                } else {
                    CommunitiesListView(
                        groups: filteredGroups,
                        searchQuery: $searchQuery,
                        filterIndex: $filterIndex,
                        unreadAlerts: bridge.unreadCount,
                        onSelectGroup: { group in
                            bridge.selectCommunityGroup(group.id)
                            activeChatGroup = group
                        },
                        onNotificationTap: { bridge.setTab(UserTab.alerts) }
                    )
                }
            }
            .background(RaahiTheme.grouped)
        }
    }
}

private struct CommunitiesListView: View {
    let groups: [CommunityGroup]
    @Binding var searchQuery: String
    @Binding var filterIndex: Int
    let unreadAlerts: Int
    let onSelectGroup: (CommunityGroup) -> Void
    let onNotificationTap: () -> Void

    private let filters = ["All", "Joined", "Recommended"]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                // Header
                HStack {
                    Text("Communities").font(.poppins(26, weight: .bold))
                    Spacer()
                    Button(action: onNotificationTap) {
                        ZStack(alignment: .topTrailing) {
                            Image(systemName: "bell.fill")
                                .font(.system(size: 20))
                                .foregroundStyle(RaahiTheme.deep)
                                .frame(width: 38, height: 38)
                                .background(RaahiTheme.fill, in: Circle())
                            if unreadAlerts > 0 {
                                Circle().fill(.red).frame(width: 10, height: 10).offset(x: 2, y: -2)
                            }
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 10)

                // Search Bar
                HStack {
                    Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                    TextField("Search Communities...", text: $searchQuery).font(.inter(16))
                }
                .padding(.horizontal, 12)
                .frame(height: 44)
                .background(RaahiTheme.fill, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                .padding(.horizontal, 20)
                .padding(.bottom, 10)

                // Filter Tabs
                HStack(spacing: 8) {
                    ForEach(0..<filters.count, id: \.self) { i in
                        GlassChip(label: filters[i], selected: i == filterIndex) {
                            filterIndex = i
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 12)

                // Communities List (PURE WHITE BACKGROUND, FULL WIDTH, NO PADDING, 0.5 PT BOTTOM DIVIDER)
                ForEach(groups, id: \.id) { group in
                    CommunityCardItem(group: group, onTap: { onSelectGroup(group) })
                }

                // Recommended Section
                VStack(alignment: .leading, spacing: 10) {
                    Text("Recommended Communities").font(.poppins(17, weight: .semibold)).padding(.top, 14)
                    HStack(spacing: 12) {
                        GlyphBadge(glyph: "🚕", size: 48, tint: RaahiTheme.primary)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Jaipur Accessible Auto Network").font(.poppins(15, weight: .semibold))
                            Text("118 members · 12 mutual connections").font(.inter(12)).foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 0)
                        HStack(spacing: 8) {
                            Button {} label: {
                                Image(systemName: "xmark").font(.system(size: 12, weight: .bold)).foregroundStyle(.secondary)
                            }
                            .frame(width: 36, height: 36)
                            .background(RaahiTheme.fill, in: Circle())

                            Button {} label: {
                                Image(systemName: "checkmark").font(.system(size: 14, weight: .bold)).foregroundStyle(.white)
                            }
                            .frame(width: 36, height: 36)
                            .background(RaahiTheme.primary, in: Circle())
                        }
                    }
                    .padding(14)
                    .background(Color.white, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(RaahiTheme.hairline, lineWidth: 0.5))
                }
                .padding(.horizontal, 20)
            }
            .padding(.top, 8)
            .padding(.bottom, 24)
        }
        .background(RaahiTheme.grouped)
    }
}

private struct CommunityCardItem: View {
    let group: CommunityGroup
    let onTap: () -> Void

    var body: some View {
        Button(action: onTap) {
            VStack(spacing: 0) {
                HStack(spacing: 12) {
                    ZStack(alignment: .bottomTrailing) {
                        GlyphBadge(glyph: group.symbol, size: 52, tint: RaahiTheme.primary)
                        Circle().fill(Color.green).frame(width: 13, height: 13)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        HStack(spacing: 6) {
                            Text(group.name).font(.poppins(15, weight: .semibold)).foregroundStyle(.primary)
                            Image(systemName: "checkmark.seal.fill").font(.system(size: 13)).foregroundStyle(RaahiTheme.deep)
                        }
                        Text(group.lastMessage.isEmpty ? group.description_ : group.lastMessage)
                            .font(.inter(13))
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                    Spacer(minLength: 0)
                    VStack(alignment: .trailing, spacing: 4) {
                        Text("20 min ago").font(.inter(11)).foregroundStyle(.secondary)
                        if group.unreadCount > 0 {
                            Text("\(group.unreadCount)")
                                .font(.inter(12, weight: .bold))
                                .foregroundStyle(RaahiTheme.deep)
                                .frame(width: 24, height: 24)
                                .background(RaahiTheme.primary.opacity(0.2), in: Circle())
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 12)
                .background(Color.white)

                Divider().background(RaahiTheme.hairline)
            }
        }
        .buttonStyle(.plain)
    }
}

private struct GroupChatView: View {
    let group: CommunityGroup
    let messages: [ChatMessage]
    let onBack: () -> Void
    let onSendMessage: (String) -> Void

    @State private var textInput: String = ""
    @State private var showInfo: Bool = false

    var body: some View {
        ScrollViewReader { proxy in
            VStack(spacing: 0) {
                // Header (Transparent background + Round white cards for icons of same size)
                HStack {
                    Button(action: onBack) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundStyle(.primary)
                            .frame(width: 40, height: 40)
                            .background(Color.white, in: Circle())
                            .overlay(Circle().stroke(RaahiTheme.hairline, lineWidth: 0.5))
                    }
                    Spacer()
                    Text(group.name)
                        .font(.poppins(17, weight: .bold))
                        .foregroundStyle(.primary)
                    Spacer()
                    Button(action: { showInfo = true }) {
                        Text("•••")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundStyle(.primary)
                            .frame(width: 40, height: 40)
                            .background(Color.white, in: Circle())
                            .overlay(Circle().stroke(RaahiTheme.hairline, lineWidth: 0.5))
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .background(Color.clear)

                // Message Thread
                ScrollView {
                    VStack(alignment: .center, spacing: 16) {
                        Text("Today 18:00 PM")
                            .font(.inter(12))
                            .foregroundStyle(.secondary)
                            .padding(.top, 8)

                        ForEach(messages, id: \.id) { msg in
                            ChatMessageBubble(msg: msg)
                                .id(msg.id)
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                }
                .background(RaahiTheme.grouped)

                // Floating Composer Input Bar
                HStack(spacing: 10) {
                    TextField("Type a message...", text: $textInput)
                        .font(.inter(15))
                        .padding(.horizontal, 14)
                        .frame(minHeight: 44)
                        .background(Color.white, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(RaahiTheme.hairline, lineWidth: 0.5))

                    Text("📎").font(.system(size: 18))
                    Text("🎙️").font(.system(size: 18))

                    Button {
                        if !textInput.trimmingCharacters(in: .whitespaces).isEmpty {
                            onSendMessage(textInput)
                            textInput = ""
                        }
                    } label: {
                        Text("↑")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundStyle(.white)
                            .frame(width: 42, height: 42)
                            .background(RaahiTheme.deep, in: Circle())
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .background(RaahiTheme.grouped)
            }
            .onChange(of: messages.count) { _, _ in
                if let last = messages.last {
                    withAnimation { proxy.scrollTo(last.id, anchor: .bottom) }
                }
            }
            .sheet(isPresented: $showInfo) {
                GroupInfoView(group: group, onBack: { showInfo = false })
                    .presentationDetents([.large])
                    .presentationDragIndicator(.visible)
            }
        }
    }
}

private struct GroupInfoView: View {
    let group: CommunityGroup
    let onBack: () -> Void

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    // Centered App Compass Logo Header
                    VStack(spacing: 12) {
                        ZStack {
                            Circle().fill(RaahiTheme.primary.opacity(0.18)).frame(width: 88, height: 88)
                            Image(systemName: "safari.fill")
                                .font(.system(size: 40))
                                .foregroundStyle(RaahiTheme.deep)
                        }
                        Text(group.name).font(.poppins(20, weight: .bold))
                        Text(group.description_).font(.inter(14)).foregroundStyle(.secondary).multilineTextAlignment(.center).padding(.horizontal, 16)
                        Pill(text: "\(group.memberCount) Members · Verified Community", tint: RaahiTheme.primary)
                    }
                    .padding(20)
                    .frame(maxWidth: .infinity)
                    .background(Color.white)

                    // Group Members Section (WhatsApp style)
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("Group Members").font(.poppins(17, weight: .bold))
                            Spacer()
                            Text("\(group.members.count) active").font(.inter(12)).foregroundStyle(.secondary)
                        }
                        ForEach(group.members, id: \.id) { member in
                            HStack(spacing: 12) {
                                Avatar(name: member.name, size: 42)
                                VStack(alignment: .leading, spacing: 2) {
                                    HStack(spacing: 6) {
                                        Text(member.name).font(.poppins(15, weight: .semibold))
                                        if member.isVerified {
                                            Image(systemName: "checkmark.seal.fill").font(.system(size: 13)).foregroundStyle(RaahiTheme.deep)
                                        }
                                    }
                                    Text(member.role).font(.inter(12)).foregroundStyle(.secondary)
                                }
                                Spacer()
                                if member.isMe {
                                    Pill(text: "You", tint: RaahiTheme.primary)
                                }
                            }
                            .padding(.vertical, 4)
                        }
                    }
                    .padding(16)
                    .background(Color.white)
                }
                .padding(.vertical, 16)
            }
            .background(RaahiTheme.grouped)
            .navigationTitle("Group Info")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: onBack) {
                        Image(systemName: "xmark").font(.system(size: 16, weight: .bold)).foregroundStyle(.primary)
                    }
                }
            }
        }
    }
}

private struct ChatMessageBubble: View {
    let msg: ChatMessage

    var body: some View {
        HStack(alignment: .bottom, spacing: 8) {
            if msg.isMe {
                Spacer()
                // My Messages (App Theme Green Bubble on Right)
                VStack(alignment: .trailing, spacing: 2) {
                    Text(msg.text)
                        .font(.inter(15))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 10)
                        .background(RaahiTheme.primary, in: RoundedRectangle(cornerRadius: 18, style: .continuous))

                    Text(msg.timestamp + " ✓")
                        .font(.inter(11))
                        .foregroundStyle(.secondary)
                }
            } else {
                // Other Sender Messages (White Bubble on Left + Sender Avatar & Name BELOW)
                VStack(alignment: .leading, spacing: 4) {
                    Text(msg.text)
                        .font(.inter(15))
                        .foregroundStyle(Color.primary)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 10)
                        .background(Color.white, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(RaahiTheme.hairline, lineWidth: 0.5))

                    HStack(spacing: 6) {
                        Avatar(name: msg.senderName, size: 22)
                        Text(msg.senderName).font(.inter(12, weight: .semibold)).foregroundStyle(.secondary)
                        Text(msg.timestamp).font(.inter(11)).foregroundStyle(.secondary)
                    }
                }
                Spacer()
            }
        }
    }
}
