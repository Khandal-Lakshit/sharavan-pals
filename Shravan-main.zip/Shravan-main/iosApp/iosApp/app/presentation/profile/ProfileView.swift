import SwiftUI
import SharedCore

struct UserProfileSheet: View {
    let userName: String
    let city: String
    let onLogout: () -> Void
    let onDismiss: () -> Void

    private var name: String { userName.isEmpty ? "Asha" : userName }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    Text("User Profile").font(.poppins(24, weight: .bold))
                    Spacer()
                    Pill(text: "Active User", tint: RaahiTheme.primary)
                }

                FlatCard(tint: RaahiTheme.primary) {
                    HStack(spacing: 16) {
                        Avatar(name: name, size: 60)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(name).font(.poppins(18, weight: .bold))
                            Text("📍 \(city.isEmpty ? "Jaipur, Rajasthan" : city)").font(.inter(14)).foregroundStyle(RaahiTheme.deep)
                            Text("Shravan Traveler · ID #SHR-USR-2026").font(.inter(12)).foregroundStyle(.secondary)
                        }
                    }
                }

                Text("Accessibility & Handling Details").font(.poppins(17, weight: .semibold))
                FlatCard {
                    VStack(alignment: .leading, spacing: 10) {
                        detailRow("Mobility Aid", "👩‍🦽 Power Wheelchair (Heavy Battery)")
                        detailRow("Handling Instruction", "Do not lift under the arms. Speak clearly before touching or moving.")
                        detailRow("Emergency Contact", "📞 +91 98290 12345 (Family)")
                        detailRow("Hospital Preference", "🏥 EHCC Hospital, Malviya Nagar, Jaipur")
                    }
                }

                Text("Your Shravan Summary").font(.poppins(17, weight: .semibold))
                HStack(spacing: 12) {
                    statBox(number: "8", label: "Safe Trips")
                    statBox(number: "3", label: "Helpers Booked")
                    statBox(number: "2", label: "Groups Joined")
                }

                Button(action: onLogout) {
                    Text("Log out")
                        .font(.poppins(16, weight: .semibold))
                        .foregroundStyle(.red)
                        .frame(maxWidth: .infinity, minHeight: 44)
                }
                .buttonStyle(.glass)
                .padding(.top, 8)
            }
            .padding(20)
        }
        .background(RaahiTheme.surface)
    }

    private func detailRow(_ label: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label).font(.inter(12, weight: .medium)).foregroundStyle(.secondary)
            Text(value).font(.inter(15))
        }
    }

    private func statBox(number: String, label: String) -> some View {
        VStack(spacing: 2) {
            Text(number).font(.poppins(20, weight: .bold)).foregroundStyle(RaahiTheme.deep)
            Text(label).font(.inter(12)).foregroundStyle(.secondary)
        }
        .padding(12)
        .frame(maxWidth: .infinity)
        .background(RaahiTheme.fill, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

struct HelperProfileSheet: View {
    let userName: String
    let userBadge: String
    let onLogout: () -> Void
    let onDismiss: () -> Void

    private var name: String { userName.isEmpty ? "Ravi Driver" : userName }
    private var badge: String { userBadge.isEmpty ? "Verified NGO Partner Driver" : userBadge }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    Text("Helper Profile").font(.poppins(24, weight: .bold))
                    Spacer()
                    Pill(text: "✓ Verified Helper", tint: RaahiTheme.success)
                }

                FlatCard(tint: RaahiTheme.success) {
                    HStack(spacing: 16) {
                        Avatar(name: name, size: 60)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(name).font(.poppins(18, weight: .bold))
                            Text("✓ \(badge)").font(.inter(14)).foregroundStyle(RaahiTheme.deep)
                            Text("ID #SHR-HELPER-8492 · Jaipur Zone").font(.inter(12)).foregroundStyle(.secondary)
                        }
                    }
                }

                Text("Helper Verification Details").font(.poppins(17, weight: .semibold))
                FlatCard {
                    VStack(alignment: .leading, spacing: 10) {
                        detailRow("Aadhaar & Driving License", "✅ Verified & Background Checked")
                        detailRow("Rating & Reviews", "⭐ 4.9 / 5.0 (28 ratings)")
                        detailRow("Primary Speciality", "Ramp Verification, Wheelchair Transport Assistance")
                        detailRow("Operating City", "📍 Jaipur (Jawahar Circle, Malviya Nagar, C-Scheme)")
                    }
                }

                Text("Verification Stats").font(.poppins(17, weight: .semibold))
                HStack(spacing: 12) {
                    statBox(number: "18", label: "Barriers Verified")
                    statBox(number: "12", label: "Routes Checked")
                    statBox(number: "4.9 ★", label: "User Rating")
                }

                Button(action: onLogout) {
                    Text("Log out")
                        .font(.poppins(16, weight: .semibold))
                        .foregroundStyle(.red)
                        .frame(maxWidth: .infinity, minHeight: 44)
                }
                .buttonStyle(.glass)
                .padding(.top, 8)
            }
            .padding(20)
        }
        .background(RaahiTheme.surface)
    }

    private func detailRow(_ label: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label).font(.inter(12, weight: .medium)).foregroundStyle(.secondary)
            Text(value).font(.inter(15))
        }
    }

    private func statBox(number: String, label: String) -> some View {
        VStack(spacing: 2) {
            Text(number).font(.poppins(20, weight: .bold)).foregroundStyle(RaahiTheme.deep)
            Text(label).font(.inter(12)).foregroundStyle(.secondary)
        }
        .padding(12)
        .frame(maxWidth: .infinity)
        .background(RaahiTheme.fill, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}
