import SwiftUI

private struct IntroPage: Identifiable {
    let id = UUID()
    let emoji: String
    let title: String
    let body: String
    let planned: Bool
}

private let pages: [IntroPage] = [
    IntroPage(emoji: "🗺️", title: "Routes that avoid barriers", body: "Shravan finds the footpath route with no steps, missing ramps or broken surfaces, and shows it next to the normal route.", planned: false),
    IntroPage(emoji: "🤝", title: "Helping Hands keep it fresh", body: "Helping Hands walk your route, photograph problems and confirm them. You get an alert and your route updates.", planned: false),
    IntroPage(emoji: "🆘", title: "SOS with your handling notes", body: "Hold one button and your contacts and the nearest hospital get your location and instructions on how to move you safely.", planned: true),
    IntroPage(emoji: "🗣️", title: "Voice, places, friends, booking", body: "Voice control, accessible cafes and hospitals, a friends and caretaker circle, and assistance booking.", planned: true),
]

struct OnboardView: View {
    let onFinish: () -> Void
    @State private var page = 0

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Spacer()
                Button("Skip", action: onFinish)
                    .font(.inter(16, weight: .medium))
                    .buttonStyle(.glass)
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)

            TabView(selection: $page) {
                ForEach(Array(pages.enumerated()), id: \.element.id) { index, item in
                    VStack(spacing: 20) {
                        Spacer()
                        Text(item.emoji)
                            .font(.system(size: 76))
                            .frame(width: 168, height: 168)
                            .background(RaahiTheme.primary.opacity(0.10), in: Circle())
                            .accessibilityHidden(true)
                        Text(item.title)
                            .font(.poppins(28, weight: .bold))
                            .multilineTextAlignment(.center)
                        Text(item.body)
                            .font(.inter(17))
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                        if item.planned {
                            Pill(text: "Planned - not live in this prototype", tint: RaahiTheme.warn)
                        }
                        Spacer()
                    }
                    .padding(.horizontal, 32)
                    .tag(index)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .always))
            .indexViewStyle(.page(backgroundDisplayMode: .always))

            Button {
                if page == pages.count - 1 { onFinish() } else { withAnimation { page += 1 } }
            } label: {
                Text(page == pages.count - 1 ? "Get started" : "Next")
                    .font(.poppins(17, weight: .semibold))
                    .frame(maxWidth: .infinity, minHeight: 36)
            }
            .buttonStyle(.glassProminent)
            .tint(RaahiTheme.primary)
            .controlSize(.large)
            .padding(.horizontal, 24)
            .padding(.bottom, 16)
        }
        .background(RaahiTheme.grouped)
    }
}

#Preview {
    OnboardView(onFinish: {})
}
