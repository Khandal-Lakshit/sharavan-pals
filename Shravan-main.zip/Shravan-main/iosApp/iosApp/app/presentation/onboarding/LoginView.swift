import SwiftUI

struct LoginView: View {
    @ObservedObject var auth: AuthViewModelBridge
    @State private var chosen: Chosen?

    private enum Chosen { case user, helper }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                hero

                VStack(alignment: .leading, spacing: 14) {
                    Text("Who is using Shravan?")
                        .font(.poppins(22, weight: .bold))

                    roleCard(
                        glyph: "♿",
                        title: "I need a barrier-free route",
                        body: "See what is blocked nearby, plan a route around it and get alerts when it changes.",
                        badge: nil,
                        loading: auth.isLoading && chosen == .user
                    ) {
                        chosen = .user
                        auth.loginAsUser()
                    }

                    roleCard(
                        glyph: "🤝",
                        title: "I am a verified Helping Hand",
                        body: "Drivers and NGO partners report steps, broken paths and blocked ramps.",
                        badge: "Verified drivers and NGOs only",
                        loading: auth.isLoading && chosen == .helper
                    ) {
                        chosen = .helper
                        auth.loginAsHelper()
                    }

                    Text("Prototype: no password. You sign in as the demo user (Asha) or the demo Helping Hand (Shravan, a verified driver). In the real app only verified helpers can report.")
                        .font(.inter(13))
                        .foregroundStyle(.secondary)
                        .padding(.top, 4)
                }
                .padding(.horizontal, 4)
            }
            .padding(16)
        }
        .background(RaahiTheme.grouped)
    }

    /// Deep green card: brand, one line of purpose and a preview of the pins on the Home map.
    private var hero: some View {
        ZStack(alignment: .topLeading) {
            RoundedRectangle(cornerRadius: 28, style: .continuous).fill(RaahiTheme.deep)

            VStack(alignment: .leading, spacing: 10) {
                Text("🧭")
                    .font(.system(size: 26))
                    .frame(width: 56, height: 56)
                    .background(Color.white, in: Circle())
                    .accessibilityHidden(true)
                Spacer().frame(height: 56)
                Text("Shravan")
                    .font(.poppins(36, weight: .bold))
                    .foregroundStyle(.white)
                Text("Footpath routes that avoid steps, missing ramps and broken surfaces, kept up to date by people on the ground.")
                    .font(.inter(15))
                    .lineSpacing(1)
                    .foregroundStyle(.white.opacity(0.92))
                    .padding(.trailing, 40)
            }
            .padding(24)

            pinPreview("🪜", "R").frame(maxWidth: .infinity, alignment: .topTrailing).padding(.top, 20).padding(.trailing, 24)
            pinPreview("⛔", "M").frame(maxWidth: .infinity, alignment: .topTrailing).padding(.top, 76).padding(.trailing, 84)
            pinPreview("📍", "I").frame(maxWidth: .infinity, alignment: .topTrailing).padding(.top, 132).padding(.trailing, 16)
        }
        .frame(minHeight: 300)
        .accessibilityElement(children: .combine)
    }

    /// Same look as a Home-map pin: white round badge with the barrier icon and the reporter's initial.
    private func pinPreview(_ glyph: String, _ initial: String) -> some View {
        ZStack(alignment: .bottomTrailing) {
            Text(glyph)
                .font(.system(size: 22))
                .frame(width: 48, height: 48)
                .background(Color.white, in: Circle())
            Avatar(name: initial, size: 22)
                .overlay(Circle().stroke(Color.white, lineWidth: 2))
        }
        .frame(width: 56, height: 56, alignment: .topLeading)
        .accessibilityHidden(true)
    }

    private func roleCard(glyph: String, title: String, body: String, badge: String?, loading: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 14) {
                Text(glyph)
                    .font(.system(size: 26))
                    .frame(width: 56, height: 56)
                    .background(RaahiTheme.fill, in: Circle())
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 4) {
                    Text(title).font(.poppins(16, weight: .semibold)).foregroundStyle(.primary)
                    Text(body).font(.inter(13)).lineSpacing(0).foregroundStyle(.secondary)
                    if let badge { Pill(text: badge).padding(.top, 4) }
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                // The round arrow is the button: green circle, white arrow, spinner while signing in.
                ZStack {
                    Circle().fill(RaahiTheme.primary)
                    if loading {
                        ProgressView().tint(.white)
                    } else {
                        Image(systemName: "chevron.right")
                            .font(.system(size: 17, weight: .bold))
                            .foregroundStyle(.white)
                    }
                }
                .frame(width: 44, height: 44)
            }
            .padding(16)
            .frame(maxWidth: .infinity, minHeight: 88, alignment: .leading)
            .flatSurface(RoundedRectangle(cornerRadius: 24, style: .continuous))
            .contentShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        }
        .buttonStyle(.plain)
        .disabled(auth.isLoading)
        .accessibilityLabel("\(title). \(body)")
    }
}
