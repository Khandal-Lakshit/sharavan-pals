import SwiftUI

let appName = "Shravan"
let appTagline = "Together with you."

/// Opening animation: a white disc pops in, then inside it the four fingers of the Helping Hand rise one after the other, the thumb swings in, the location
/// pin drops into the palm, the hand gives a small wave, then the name and tagline fade up in white. Tap to skip. With
/// Reduce Motion on it shows the finished logo briefly.
struct SplashView: View {
    let onFinished: () -> Void
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    @State private var disc: CGFloat = 0
    @State private var fingers: [CGFloat] = [0, 0, 0, 0]
    @State private var thumb: CGFloat = 0
    @State private var pin: CGFloat = 0
    @State private var wave: Double = 0        // degrees
    @State private var nameShown = false
    @State private var taglineShown = false
    @State private var visible = true
    @State private var finished = false

    private let size: CGFloat = 240

    var body: some View {
        ZStack {
            Color("LaunchGreen").ignoresSafeArea()
            VStack(spacing: 24) {
                ZStack {
                    Circle().fill(.white)
                    ZStack {
                        ForEach(0..<4, id: \.self) { i in
                            Image("SplashF\(i)").resizable().scaledToFit()
                                .offset(y: (1 - fingers[i]) * 60)
                                .opacity(Double(min(max(fingers[i], 0), 1)))
                        }
                        Image("SplashThumb").resizable().scaledToFit()
                            .rotationEffect(.degrees(Double((1 - thumb) * 55)), anchor: UnitPoint(x: 0.38, y: 0.66))
                            .opacity(Double(min(max(thumb, 0), 1)))
                        Image("SplashPin").resizable().scaledToFit()
                            .offset(y: (pin - 1) * 100)
                            .opacity(Double(min(max(pin * 3, 0), 1)))
                    }
                    .rotationEffect(.degrees(wave), anchor: UnitPoint(x: 0.5, y: 0.8))   // the wave pivots at the wrist
                }
                .frame(width: size, height: size)
                .clipShape(Circle())
                .scaleEffect(disc)

                VStack(spacing: 6) {
                    Text(appName)
                        .font(.poppins(44, weight: .bold))
                        .foregroundStyle(.white)
                        .shadow(color: .black.opacity(0.25), radius: 5, y: 2)
                        .opacity(nameShown ? 1 : 0)
                        .offset(y: nameShown ? 0 : 24)
                    Text(appTagline)
                        .font(.poppins(18, weight: .medium))
                        .foregroundStyle(.white)
                        .shadow(color: .black.opacity(0.25), radius: 5, y: 2)
                        .opacity(taglineShown ? 1 : 0)
                        .offset(y: taglineShown ? 0 : 16)
                }
                .accessibilityHidden(true)
            }
        }
        .opacity(visible ? 1 : 0)
        .contentShape(Rectangle())
        .onTapGesture { finish() }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(appName). \(appTagline)")
        .task { await play() }
    }

    private func finish() {
        guard !finished else { return }
        finished = true
        withAnimation(.easeOut(duration: 0.3)) { visible = false }
        Task {
            try? await Task.sleep(nanoseconds: 300_000_000)
            onFinished()
        }
    }

    private func play() async {
        if reduceMotion {
            disc = 1; fingers = [1, 1, 1, 1]; thumb = 1; pin = 1; nameShown = true; taglineShown = true
            try? await Task.sleep(nanoseconds: 900_000_000)
            finish()
            return
        }
        withAnimation(.spring(response: 0.55, dampingFraction: 0.6)) { disc = 1 }
        for i in 0..<4 {
            withAnimation(.spring(response: 0.55, dampingFraction: 0.7).delay(0.25 + Double(i) * 0.09)) { fingers[i] = 1 }
        }
        withAnimation(.spring(response: 0.5, dampingFraction: 0.7).delay(0.63)) { thumb = 1 }
        withAnimation(.spring(response: 0.45, dampingFraction: 0.5).delay(0.81)) { pin = 1 }
        try? await Task.sleep(nanoseconds: 1_500_000_000)
        withAnimation(.easeOut(duration: 0.45)) { nameShown = true }
        try? await Task.sleep(nanoseconds: 200_000_000)
        withAnimation(.easeOut(duration: 0.45)) { taglineShown = true }
        withAnimation(.easeInOut(duration: 0.17)) { wave = -7 }
        try? await Task.sleep(nanoseconds: 190_000_000)
        withAnimation(.easeInOut(duration: 0.26)) { wave = 7 }
        try? await Task.sleep(nanoseconds: 280_000_000)
        withAnimation(.easeInOut(duration: 0.2)) { wave = -3.5 }
        try? await Task.sleep(nanoseconds: 220_000_000)
        withAnimation(.easeInOut(duration: 0.18)) { wave = 0 }
        try? await Task.sleep(nanoseconds: 1_100_000_000)
        finish()
    }
}
