import SwiftUI
import SharedCore

struct ContentView: View {
    @State private var showSplash = true

    var body: some View {
        ZStack {
            AppNavigation()
            if showSplash {
                SplashView { showSplash = false }
                    .transition(.opacity)
                    .zIndex(1)
            }
        }
    }
}

#Preview {
    ContentView()
}
