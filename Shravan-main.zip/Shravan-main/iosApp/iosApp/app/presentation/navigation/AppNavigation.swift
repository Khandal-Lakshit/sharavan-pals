import SwiftUI
import SharedCore

/// Onboarding -> Login -> (User | Helper) home. Logging out returns to Login.
struct AppNavigation: View {
    @StateObject private var auth = AuthViewModelBridge()

    var body: some View {
        ZStack {
            if let user = auth.user {
                if user.role == Role.helper {
                    HelperHomeView(onLogout: auth.logout)
                        .transition(.opacity)
                } else {
                    UserHomeView(onLogout: auth.logout)
                        .transition(.opacity)
                }
            } else if !auth.onboardingDone {
                OnboardView(onFinish: auth.finishOnboarding)
                    .transition(.opacity)
            } else {
                LoginView(auth: auth)
                    .transition(.opacity)
            }
        }
        .animation(.easeInOut(duration: 0.25), value: auth.user == nil)
        .animation(.easeInOut(duration: 0.25), value: auth.onboardingDone)
        .errorAlert($auth.errorMessage)
    }
}
