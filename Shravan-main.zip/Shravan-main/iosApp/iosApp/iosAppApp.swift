//
//  iosAppApp.swift
//  iosApp
//

import SwiftUI
import SharedCore

@main
struct iosAppApp: App {

    init() {
        // Round one runs on demo data (USE_FAKE_DATA = true in SharedModule). For round two, set the backend address here:
        // SharedCore.BaseUrl.shared.value = "http://localhost:8000/"
        AppModuleKt.doInitKoin()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
